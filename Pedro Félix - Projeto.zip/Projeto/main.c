#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <locale.h>
#include "funcoes.h"
#include "imagens.h"


// Estrutura us�da para o armazenamento de todas as vari�veis que t�m haver com as informa��es pessoais das pessoas
struct pessoa{

    char nome[50];
    char apelido[50];
    char data[20];
    int altura;
    char nacionalidade[30];
    int nif[1];
    char sexo[50];
    char nomecompleto[50];
}p;

// Estrutura us�da para o armazenamento de todas as vari�veis que t�m haver com as estatisticas
struct estatisticas{

    int cidadao, cidadao1;
    int passaporte, passaporte1;
    int conducao, conducao1;
    int exame, exame1;

}e;

int main()
{
    setlocale(LC_ALL,"Portuguese");
    FILE* fpIN;
    FILE*fp;
    FILE *out;
    // Vari�veis usadas no programa
    int j=0;
    int opcao=1,variavel=0,opcao2=0,opcao3=0,opcao4=0,opcao5=0,opcao6=0,lower=0, upper=9,keypressed=0,c=0,option = 0, keypressed1=0,nossa=1,d=0,ui=1,keypressed2=0,keypressed3=0,ui2=1,keypressed4=0,ui3=1,keypressed5=0,ui4=1;
    int num[9], resposta=0, pontos=0,op=0,op1=0,op2=0,op3=0,op4=0,op5=0;

    char *user = (char*)malloc(sizeof *user * MAX_LOGIN), *senha, *confirmaSenha, tmpLogin[MAX_LOGIN], tmpSenha[MAX_SENHA];
    char filename[60],nomecompleto[50],space[50]=" ",estatistica, guardar;

    do{
    op2 = 0;
    system("color 0C");

    opcao = 1;
    keypressed = 0;

    keypressed1 = 0;
    option = 0;

    while (keypressed != 13){

    system("cls");
    bemvindo();

    arrowHere(1,opcao); printf("Aceder � Loja de cidad�o\n");
    arrowHere(2,opcao); printf("Aceder � Area Administrativa\n");

    keypressed = getch();

    if(keypressed == 80 && opcao != 2){

        opcao++;
    }else if(keypressed == 72 && opcao != 1){

        opcao--;
    }else{

        opcao = opcao;
    }
    }

    fflush(stdin);

    switch(opcao)
    {
                    case 1:
                        do
                        {
                            c = 0;
                            d = 0;

                            while (keypressed1 != 13){

                            system("cls");

                            conta();
                            arrowHere(1,nossa); printf("Entrar na Conta\n");
                            arrowHere(2,nossa); printf("Criar Conta\n");
                            arrowHere(3,nossa); printf("Sair\n");

                            keypressed1 = getch();

                            if(keypressed1 == 80 && nossa != 3){

                                nossa++;
                            }else if(keypressed1 == 72 && nossa != 1){

                                nossa--;
                            }else{

                                option = nossa;
                            }
                            }

                            fflush(stdin);

                            switch( option )
                            {
                                case 1: system("cls");
                                        conta();
                                        printf("      Coloque o seu nome:\n      >");
                                        gets(user);
                                        printf("      Coloque a sua palavra-passe:\n      >");
                                        senha = CriaSenha();

                                        // verifica se o nome e a palavra-passe est�o corretos
                                        fpIN = fopen("usuarios.txt", "a+");
                                        printf("\n", Usuario(fpIN, user, senha, &j) ? j++ : "");

                                        if(j == 1)
                                        {
                                            entrarconta();
                                            getch();
                                            c++;
                                        }else
                                        {
                                            printf("      Usuario nao confirmado\n     Clique ENTER para continuar....");
                                            getch();
                                            break;
                                        }

                                        fclose(fpIN);

                                    free(senha);

                                break;

                                case 2: printf("\n      Coloque o nome que quer dar a sua conta:\n      >");
                                        gets(user);

                                        // Cria conta com o nome e palavra-passe e verifica se as palavras-passe s�o iguais
                                        do
                                        {
                                            printf("\n      Crie uma palavra-passe:\n      >");
                                            senha = CriaSenha();
                                            printf("\n      Confirme a sua palavra-passe:\n      >");
                                            confirmaSenha = CriaSenha();
                                            printf("\n");

                                            if( !strcmp(senha, confirmaSenha) )
                                            {
                                                printf("\n      Conta criada!\n      Clique ENTER para continuar....");
                                                getch();
                                                d++;
                                                c++;

                                            }else{
                                                printf("      As senhas n�o s�o iguais. Tente novamente.\n");
                                            }
                                        }while(d != 1);

                                        // Guarda o nome e a palavra-passe nu  ficheiro para poderem ser usadas mais tarde
                                        fpIN = fopen("usuarios.txt", "a+");
                                        fprintf(fpIN, "%s %s\n", user, senha);
                                        fclose(fpIN);
                                        free(senha);
                                        free(confirmaSenha);

                                break;

                                case 3: return 0;
                                break;

                                default: printf("Escolha 1, 2 ou 3...\n");break;
                            }


                        }while( c!= 1 );

                        do{

                        keypressed2 = 0;
                        op3 =0;

                while (keypressed2 != 13){

                            system("cls");
                            system("color 0A");

                            loja();
                            arrowHere(1,ui); printf("Cart�o de Cidad�o\n");
                            arrowHere(2,ui); printf("Passaporte\n");
                            arrowHere(3,ui); printf("Carta de Condu��o\n");
                            arrowHere(4,ui); printf("Perguntas frequentes\n");
                            arrowHere(5,ui); printf("Sair\n");

                            keypressed2 = getch();

                            if(keypressed2 == 80 && ui != 5){

                                ui++;
                            }else if(keypressed2 == 72 && ui != 1){

                                ui--;
                            }else{

                                opcao2 = ui;
                            }
                            }

                            fflush(stdin);

                switch(opcao2)
                {
                    case 1: while (keypressed3 != 13){

                            system("cls");

                            //Criador do cart�o de cidad�o

                            loja();
                            printf("      Ola! Seja bem-vindo ao criador automatico do Cart�o de Cidad�o.\n      Para come�ar, diga-nos o seu sexo:\n\n");

                            arrowHere(1,ui2); printf("Sexo Masculino\n");
                            arrowHere(2,ui2); printf("Sexo Feminino\n");

                            keypressed3 = getch();

                            if(keypressed3 == 80 && ui2 != 2){

                                ui2++;
                            }else if(keypressed3 == 72 && ui2 != 1){

                                ui2--;
                            }else{

                                opcao3 = ui2;
                            }
                            }

                            fflush(stdin);
                            switch(opcao3)
                            {
                                case 1: system("cls");
                                        loja();

                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite a sua altura em centimetros:\n      >");
                                        scanf("%i",&p.altura);
                                        fflush(stdin);

                                        printf("\n      Digite a sua data de nascimento (ex:23.02.2006):\n      >");
                                        gets(p.data);

                                        printf("\n      Digite a sua nacionalidade:\n      >");
                                        gets(p.nacionalidade);

                                        printf("\n      Dados Completos!!!!\n      Clique ENTER para imprimir o seu Cart�o de Cidad�o!\n");
                                        getch();

                                        system("cls");
                                        loja();
                                        imprimir();

                                        // Gerador de NIF
                                        srand(time(NULL));
                                        for(int i=0;i<9;i++)
                                        {
                                            num[i] = (rand() % (upper-lower+1))+lower;
                                        }

                                        // Junta o nome com o aplido numa so vari�vel
                                        strcat(p.nomecompleto, p.nome);
                                        strcat(p.nomecompleto, space);
                                        strcat(p.nomecompleto, p.apelido);

                                        // cria um ficheiro com o nome completo do utilizador e guarda o Cart�o de cidad�o
                                        sprintf(filename, "%s.txt", p.nomecompleto);
                                        out = fopen( filename, "a+");

                                        fprintf(out, R"EOF(
  __________________________________________________________________________________
 |                       |
 |     #############     |  Cart�o de Cidad�o                          PORTUGAL
 |     ##         ##     |  ------------------------------------------------------
 |     #  ~~   ~~  #     |  Apelido[s] %s
 |     #  ()   ()  #     |  ------------------------------------------------------
 |     (     ^     )     |  Nome[s] %s
 |      |         |      |  ------------------------------------------------------
 |      |  {===}  |      |  | Sexo | Altura | Data de Nascimento |
 |       \       /       |  |  M   | %i    |     %s     |
 |      /  -----  \      |  ------------------------------------------------------
 |   ---  |%%\ /%%|  ---   |  NIF: %i%i%i%i%i%i%i%i%i
 |  /     |%%%%%%%%%%|     \  |  ------------------------------------------------------
 |_______________________|__________________________________________________________      )EOF",p.apelido,p.nome,p.altura,p.data,num[0],num[1],num[2],num[3],num[4],num[5],num[6],num[7],num[8] );

                                        fclose(out);

                                        // Guarda no ficheiro a quantidade de vezes que ja foram criados cart�es de cidad�o
                                        fp = fopen("cidadao.txt", "r");
                                        fscanf(fp, "%i", &e.cidadao1);
                                        e.cidadao1++;
                                        fclose(fp);
                                        fp = fopen("cidadao.txt", "w");
                                        fprintf(fp,"%i",e.cidadao1);
                                        fclose(fp);

                                        return 0;
                                break;

                                case 2: system("cls");
                                        loja();

                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite a sua altura em centimetros:\n      >");
                                        scanf("%i",&p.altura);
                                        fflush(stdin);

                                        printf("\n      Digite a sua data de nascimento (ex:23.02.2006):\n      >");
                                        gets(p.data);

                                        printf("\n      Digite a sua nacionalidade:\n      >");
                                        gets(p.nacionalidade);

                                        printf("\n      Dados Completos!!!!\n      Clique ENTER para imprimir o seu Cart�o de Cidad�o!\n");
                                        getch();

                                        system("cls");
                                        loja();
                                        imprimir();

                                        srand(time(NULL));
                                        for(int i=0;i<9;i++)
                                        {
                                            num[i] = (rand() % (upper-lower+1))+lower;
                                        }

                                        strcat(p.nomecompleto, p.nome);
                                        strcat(p.nomecompleto, space);
                                        strcat(p.nomecompleto, p.apelido);

                                        sprintf(filename, "%s.txt", p.nomecompleto);
                                        out = fopen( filename, "a+");

                                        fprintf(out, R"EOF(
  __________________________________________________________________________________
 |                       |
 |   /////////////\\\\   |  Cart�o de Cidad�o                          PORTUGAL
 |  (((((((((((((( \\\\  |  ------------------------------------------------------
 |  ))) ~~      ~~  (((  |  Apelido[s] %s
 |  ((( (*)     (*) )))  |  ------------------------------------------------------
 |  )))     <       (((  |  Nome[s] %s
 |  ((( '\______/`  )))  |  ------------------------------------------------------
 |  )))\___________/(((  |  | Sexo | Altura | Data de Nascimento |
 |         _) (_         |  |  F   |   %i  |     %s     |
 |        / \_/ \        |  ------------------------------------------------------
 |       /(     )\       |  NIF: %i%i%i%i%i%i%i%i%i
 |      // )___( \\      |  ------------------------------------------------------
 |_______________________|__________________________________________________________   )EOF",p.apelido,p.nome,p.altura,p.data,num[0],num[1],num[2],num[3],num[4],num[5],num[6],num[7],num[8] );

                                        fclose(out);

                                        fp = fopen("cidadao.txt", "r");
                                        fscanf(fp, "%i", &e.cidadao1);
                                        e.cidadao1++;
                                        fclose(fp);
                                        fp = fopen("cidadao.txt", "w");
                                        fprintf(fp,"%i",e.cidadao1);
                                        fclose(fp);

                                        return 0;
                                break;

                            }
                    break;
                    case 2: while (keypressed4 != 13){

                            system("cls");

                            loja();
                            printf("      Bem-vindo ao criador automatico do passaporte!\n      Primeiro diga-nos a sua nacionalidade:\n\n");

                            arrowHere(1,ui3); printf("Portguesa\n");
                            arrowHere(2,ui3); printf("Estrangeiro\n");

                            keypressed4 = getch();

                            if(keypressed4 == 80 && ui3 != 2){

                                ui3++;
                            }else if(keypressed4 == 72 && ui3 != 1){

                                ui3--;
                            }else{

                                opcao4 = ui3;
                            }
                            }

                            fflush(stdin);

                            switch(opcao4)
                            {
                                case 1: system("cls");
                                        loja();
                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite o seu sexo (Masculino/Feminino):\n      >");
                                        gets(p.sexo);

                                        printf("\n      Dados Completos!!!!\n      Clique ENTER para imprimir o seu PassaPorte!\n");
                                        getch();

                                        system("cls");
                                        loja();
                                        imprimir();

                                        // Junta os nomes e os apelinos numa so variavel
                                        strcat(p.nomecompleto, p.nome);
                                        strcat(p.nomecompleto, space);
                                        strcat(p.nomecompleto, p.apelido);

                                        // Cria um ficheiro com o nome do utilizador
                                        sprintf(filename, "%s.txt", p.nomecompleto);
                                        out = fopen( filename, "a+");

                                        fprintf(out, R"EOF(
  _________________________________________________________.--.____________________________________________________________
 |                                       ###   ###         |  |
 |                                        ###   ###        |  |    ______                  ______          _
 |    |`-._/\_.-`|                         ###   ###       |  |    | ___ \                 | ___ \        | |
 |    |    ||    |                          ###   ###      |  |    | |_/ /_ _ ___ ___  __ _| |_/ /__  _ __| |_ ___
 |    |___o()o___|                           ###   ###     |  |    |  __/ _` / __/ __|/ _` |  __/ _ \| '__| __/ _ \
 |    |__((<>))__|                             ###   ###   |  |    | | | (_| \__ \__ \ (_| | | | (_) | |  | ||  __/
 |    \   o\/o   /                               ###   ### |  |    \_|  \__,_|___/___/\__,_\_|  \___/|_|   \__\___|
 |     \   ||   /                                  ###   ##|  |
 |      \  ||  /                                     ###   |  |    ------------------------------------------------
 |       '.||.'                                        ####|  |    Nacionalidade[] Portuguesa
 |         ``                                              |  |    ------------------------------------------------
 |    Uni�o Europeia                                       |  |    Apelido[s] %s
 |     _____          _                     _              |  |    ------------------------------------------------
 |    | ___ \        | |                   | |             |  |    Nome[s] %s
 |    | |_/ /__  _ __| |_ _   _  __ _  __ _| |             |  |    ------------------------------------------------
 |    |  __/ _ \| '__| __| | | |/ _` |/ _` | |             |  |    Sexo[] %s
 |    | | | (_) | |  | |_| |_| | (_| | (_| | |             |  |    ------------------------------------------------
 |    \_|  \___/|_|   \__|\__,_|\__, |\__,_|_|             |  |
 |                               __/ |                     |  |
 |    Passaporte                |___/                      |  |                               |
 |                                                         |  |                         --====|====--
 |                                                         |  |
 |                                                         |  |                           .-"""""-.
 |                                                         |  |                         .'_________'.
 |                                                         |  |                        /_/_|__|__|_\_\
 |                                                         |  |                       ;'-._       _.-';
 |                                                         |  |  ,--------------------|    `-. .-'    |--------------------,
 |                                                         |  |   ``""--..__    ___   ;       '       ;   ___    __..--""``
 |                                      ___________________|  |             `"-// \\.._\             /_..// \\-"`
 |                                     |                   |  |                \\_//    '._       _.'    \\_//
 |                                     |    _______________|  |                 `"`        ``---``        `"`
 |                                     |   |               |  |
 |                                     |   |    ___________|  |
 |                                     |   |   |           |  |
 |                                     |   |   |           |  |
 |                                     |   |   |           |  |
 |                                     |   |   |        1  |  |	   Portugal  Republica Portuguesa  Portuguese Republic   2
 |_____________________________________|___|___|___________|  |_____________________________________________________________
                                                           '--'                                                              )EOF",p.apelido,p.nome,p.sexo);

                                        fclose(out);

                                        // Guarda a quantidade de vezes que foram feitos passaportes
                                        fp = fopen("passaporte.txt", "r");
                                        fscanf(fp, "%i", &e.passaporte1);
                                        e.passaporte1++;
                                        fclose(fp);
                                        fp = fopen("passaporte.txt", "w");
                                        fprintf(fp,"%i",e.passaporte1);
                                        fclose(fp);

                                        return 0;
                                break;
                                case 2: system("cls");
                                        loja();
                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite o seu sexo (Masculino/Feminino):\n      >");
                                        gets(p.sexo);

                                        printf("\n      Dados Completos!!!!\n      Clique ENTER para imprimir o seu PassaPorte!\n");
                                        getch();

                                        system("cls");
                                        loja();
                                        imprimir();

                                        strcat(p.nomecompleto, p.nome);
                                        strcat(p.nomecompleto, space);
                                        strcat(p.nomecompleto, p.apelido);

                                        sprintf(filename, "%s.txt", p.nomecompleto);
                                        out = fopen( filename, "a+");

                                        fprintf(out, R"EOF(
  _________________________________________________________.--.____________________________________________________________
 |                                       ###   ###         |  |
 |                                        ###   ###        |  |    ______                  ______          _
 |    |`-._/\_.-`|                         ###   ###       |  |    | ___ \                 | ___ \        | |
 |    |    ||    |                          ###   ###      |  |    | |_/ /_ _ ___ ___  __ _| |_/ /__  _ __| |_ ___
 |    |___o()o___|                           ###   ###     |  |    |  __/ _` / __/ __|/ _` |  __/ _ \| '__| __/ _ \
 |    |__((<>))__|                             ###   ###   |  |    | | | (_| \__ \__ \ (_| | | | (_) | |  | ||  __/
 |    \   o\/o   /                               ###   ### |  |    \_|  \__,_|___/___/\__,_\_|  \___/|_|   \__\___|
 |     \   ||   /                                  ###   ##|  |
 |      \  ||  /                                     ###   |  |    ------------------------------------------------
 |       '.||.'                                        ####|  |    PassaPorte "Especial" para Estrangeiros
 |         ``                                              |  |    ------------------------------------------------
 |    Uni�o Europeia                                       |  |    Apelido[s] %s
 |     _____          _                     _              |  |    ------------------------------------------------
 |    | ___ \        | |                   | |             |  |    Nome[s] %s
 |    | |_/ /__  _ __| |_ _   _  __ _  __ _| |             |  |    ------------------------------------------------
 |    |  __/ _ \| '__| __| | | |/ _` |/ _` | |             |  |    Sexo[] %s
 |    | | | (_) | |  | |_| |_| | (_| | (_| | |             |  |    ------------------------------------------------
 |    \_|  \___/|_|   \__|\__,_|\__, |\__,_|_|             |  |
 |                               __/ |                     |  |
 |    Passaporte                |___/                      |  |                               |
 |                                                         |  |                         --====|====--
 |                                                         |  |
 |                                                         |  |                           .-"""""-.
 |                                                         |  |                         .'_________'.
 |                                                         |  |                        /_/_|__|__|_\_\
 |                                                         |  |                       ;'-._       _.-';
 |                                                         |  |  ,--------------------|    `-. .-'    |--------------------,
 |                                                         |  |   ``""--..__    ___   ;       '       ;   ___    __..--""``
 |                                      ___________________|  |             `"-// \\.._\             /_..// \\-"`
 |                                     |                   |  |                \\_//    '._       _.'    \\_//
 |                                     |    _______________|  |                 `"`        ``---``        `"`
 |                                     |   |               |  |
 |                                     |   |    ___________|  |
 |                                     |   |   |           |  |
 |                                     |   |   |           |  |
 |                                     |   |   |           |  |
 |   Estrangeiros                      |   |   |        1  |  |	   Portugal  Republica Portuguesa  Portuguese Republic   2
 |_____________________________________|___|___|___________|  |_____________________________________________________________
                                                           '--'                                                              )EOF",p.apelido,p.nome,p.sexo);

                                        fclose(out);

                                        fp = fopen("passaporte.txt", "r");
                                        fscanf(fp, "%i", &e.passaporte1);
                                        e.passaporte1++;
                                        fclose(fp);
                                        fp = fopen("passaporte.txt", "w");
                                        fprintf(fp,"%i",e.passaporte1);
                                        fclose(fp);

                                        return 0;

                                break;
                            }

                    break;

                    case 3: while (keypressed5 != 13){

                            system("cls");

                            loja();
                            printf("      Ola! Seja bem-vindo ao criador automatico da Carta de Condu��o!.\n      Para come�ar, diga-nos o seu sexo:\n\n");

                            arrowHere(1,ui4); printf("Sexo Masculino\n");
                            arrowHere(2,ui4); printf("Sexo Feminino\n");

                            keypressed5 = getch();

                            if(keypressed5 == 80 && ui4 != 2){

                                ui4++;
                            }else if(keypressed5 == 72 && ui4 != 1){

                                ui4--;
                            }else{

                                opcao5 = ui4;
                            }
                            }

                            fflush(stdin);
                            switch(opcao5)
                            {
                                case 1: system("cls");
                                        loja();
                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite a sua data de nascimento (ex:23.02.2006):\n      >");
                                        gets(p.data);

                                        system("cls");
                                        loja();
                                        printf("      Dados Preencidos com sucesso!!\n      Clique no ENTER quando estiver pronto para proseguir para o exame!\n");
                                        getch();

                                        do{

                                        // Perguntas e se estiver correta ganha 1 ponto
                                        system("cls");
                                        exame();
                                        printf("      Bem-Vindo ao Exame, responda a todas as perguntas com aten��o!\n      Boa sorte!!\n\n");

                                        printf("      Quest�o 1:\n");
                                        printf("      Quando algum ve�culo de Emerg�ncia passa perto de ti com as sirenes ligadas deves:\n");
                                        printf("      1-Acelarar, impediando a passagem.\n      2-Manter a velocidade e ceder passagem ao veiculo.\n      3-Denunciar o veiculo por excesso de velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 2:\n");
                                        printf("      Antes de mudar de via devo:\n");
                                        printf("      1-Olhar pelos retrovisores e verificar se a passagem est� livre.\n      2-Sinalizar as minhas inten��es.\n      3-Todas as respostas acima.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 3:\n");
                                        printf("      Estou a conduzir numa autoestrada com um automovel ligeiro de passageiros,\n      qual a velocidade maxima a que posso circular?\n");
                                        printf("      1-50km/h\n      2-100km/h\n      3-120km/h\n      4-80km/h\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 4:\n");
                                        printf("      Se estou a circular a 80km/h e vou entrar numa localidade devo:\n");
                                        printf("      1-Aumentar a velocidade.\n      2-Reduzir a velocidade.\n      3-Manter a Velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 5:\n");
                                        printf("      Qual a percentagem de alcool no sangue para ser consider�da condu��o sob influencia de alcool?\n");
                                        printf("      1-0.5g/l\n      2-0.8g/l\n      3-0.3g/l\n      4-1.2g/l\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==1){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 6:\n");
                                        printf("      Qual das seguintes op��es � permita durante a ultrapassagem de um veiculo:\n");
                                        printf("      1-Exceder o limite de velocidade.\n      2-Passar extremamente perto do outro ve�culo.\n      3-Conduzir fora da estrada.\n      4-Utilizar a via da esquerda para a ultrapassagem.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==4){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 7:\n");
                                        printf("      O que se deve fazer quando se encontra um sinal de STOP ?\n");
                                        printf("      1-Parar e ceder passagem a todos os ve�culos.\n      2-Apenas parar.\n      3-Apenas ceder passagem.\n      4-Ignorar o sinal.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==1){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 8:\n");
                                        printf("      O que devo fazer ao entrar numa curva de visibilidade reduzida?\n");
                                        printf("      1-Ligar os maximos.\n      2-Parar.\n      3-Moderar a velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 9:\n");
                                        printf("      Ao entrar num tunel � proibido:\n");
                                        printf("      1-Ultrapassar.\n      2-Parar e estacionar.\n      3-Ligar os m�dios.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 10:\n");
                                        printf("      Perante um sinal luminoso que esteja amarelo devo:\n");
                                        printf("      1-Acelarar e passar o mais rapido possivel.\n      2-Travar a fundo.\n      3-Fazer invers�o de marcha.\n      4-Reduzir a velocidade e parar.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==4){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        if(pontos<9){
                                            exame();
                                            printf("      Exame reprovado: Acertou %i/10\n      Deseja:\n      [1]Repetir o Exame!\n      [2]Desistir\n      >",pontos);
                                            scanf("%i",&opcao6);

                                            // Guarda num ficheiro a quantidade de vezes que as pessoas fazem exames
                                            fp = fopen("exame.txt", "r");
                                            fscanf(fp, "%i", &e.exame1);
                                            e.exame1++;
                                            fclose(fp);
                                            fp = fopen("exame.txt", "w");
                                            fprintf(fp,"%i",e.exame1);
                                            fclose(fp);

                                        }else{
                                            exame();
                                            printf("      PARABENS!!!!\n      Exame Aprovado: Acertou %i/10\n      A carta de condu��o vai ser imprimida em seu nome!!\n",pontos);
                                            printf("      Clique ENTER para sair!\n");

                                            // Guarda num ficheiro a quantidade de vezes que as pessoas fazem exames
                                            fp = fopen("exame.txt", "r");
                                            fscanf(fp, "%i", &e.exame1);
                                            e.exame1++;
                                            fclose(fp);
                                            fp = fopen("exame.txt", "w");
                                            fprintf(fp,"%i",e.exame1);
                                            fclose(fp);

                                            // Junta os nomes e os apelinos numa so variavel
                                            strcat(p.nomecompleto, p.nome);
                                            strcat(p.nomecompleto, space);
                                            strcat(p.nomecompleto, p.apelido);

                                            // Cria um ficheiro com o nome do utilizador
                                            sprintf(filename, "%s.txt", p.nomecompleto);
                                            out = fopen( filename, "a+");

                                            fprintf(out, R"EOF(
   __________________________________________________________________________________
 |  _______________________
 | |                       |
 | |          ___          |       Carta de Condu��o  |  Republica Portuguesa
 | |         | _ \         |
 | |         |  _/         |	-------------------------------------------------
 | |         |_|           |    Apelido[s] %s
 | |                       |    -------------------------------------------------
 | |_______________________|	Nome[s] %s
 |                        	-------------------------------------------------
 |       #############    	Data de Nascimento %s
 |       ##         ##        	-------------------------------------------------
 |       #  ~~   ~~  #
 |       #  ()   ()  #        	                  ______--------___
 |       (     ^     )                           /|             / |
 |        |         |                 o___________|_\__________/__|
 |        |  {===}  |                ]|___     |  |=   ||  =|___  |"
 |         \       /                 //   \\    |  |____||_///   \\|"
 |        /  -----  \                |  X  |\--------------/|  X  |\"
 |     ---  |%%\ /%%|  ---              \___/                  \___/
 |    /     |%%%%%%%%%%|     \
 |___________________________________________________________________________________ )EOF",p.apelido,p.nome,p.data);


                                            fclose(out);
                                            getch();

                                            // Guarda num ficheiro a quantidade de vezes que foram feitas cartas de condu��o
                                            fp = fopen("conducao.txt", "r");
                                            fscanf(fp, "%i", &e.conducao1);
                                            e.conducao1++;
                                            fclose(fp);
                                            fp = fopen("conducao.txt", "w");
                                            fprintf(fp,"%i",e.conducao1);
                                            fclose(fp);

                                            return 0;

                                        }

                                    }while(opcao6=!1);
                                        return 0;
                                break;


                                case 2: system("cls");
                                        loja();
                                        printf("\n      Digite os seus Apelidos:\n      >");
                                        gets(p.apelido);

                                        printf("\n      Digite os seus Nomes:\n      >");
                                        gets(p.nome);

                                        printf("\n      Digite a sua data de nascimento (ex:23.02.2006):\n      >");
                                        gets(p.data);

                                        system("cls");
                                        loja();
                                        printf("      Dados Preencidos com sucesso!!\n      Clique no ENTER quando estiver pronto para proseguir para o exame!\n");
                                        getch();

                                        do{

                                        system("cls");
                                        exame();
                                        printf("      Bem-Vindo ao Exame, responda a todas as perguntas com aten��o!\n      Boa sorte!!\n\n");

                                        printf("      Quest�o 1:\n");
                                        printf("      Quando algum ve�culo de Emerg�ncia passa perto de ti com as sirenes ligadas deves:\n");
                                        printf("      1-Acelarar, impediando a passagem.\n      2-Manter a velocidade e ceder passagem ao veiculo.\n      3-Denunciar o veiculo por excesso de velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 2:\n");
                                        printf("      Antes de mudar de via devo:\n");
                                        printf("      1-Olhar pelos retrovisores e verificar se a passagem est� livre.\n      2-Sinalizar as minhas inten��es.\n      3-Todas as respostas acima.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 3:\n");
                                        printf("      Estou a conduzir numa autoestrada com um automovel ligeiro de passageiros,\n      qual a velocidade maxima a que posso circular?\n");
                                        printf("      1-50km/h\n      2-100km/h\n      3-120km/h\n      4-80km/h\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 4:\n");
                                        printf("      Se estou a circular a 80km/h e vou entrar numa localidade devo:\n");
                                        printf("      1-Aumentar a velocidade.\n      2-Reduzir a velocidade.\n      3-Manter a Velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 5:\n");
                                        printf("      Qual a percentagem de alcool no sangue para ser consider�da condu��o sob influencia de alcool?\n");
                                        printf("      1-0.5g/l\n      2-0.8g/l\n      3-0.3g/l\n      4-1.2g/l\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==1){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 6:\n");
                                        printf("      Qual das seguintes op��es � permita durante a ultrapassagem de um veiculo:\n");
                                        printf("      1-Exceder o limite de velocidade.\n      2-Passar extremamente perto do outro ve�culo.\n      3-Conduzir fora da estrada.\n      4-Utilizar a via da esquerda para a ultrapassagem.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==4){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 7:\n");
                                        printf("      O que se deve fazer quando se encontra um sinal de STOP ?\n");
                                        printf("      1-Parar e ceder passagem a todos os ve�culos.\n      2-Apenas parar.\n      3-Apenas ceder passagem.\n      4-Ignorar o sinal.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==1){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 8:\n");
                                        printf("      O que devo fazer ao entrar numa curva de visibilidade reduzida?\n");
                                        printf("      1-Ligar os maximos.\n      2-Parar.\n      3-Moderar a velocidade.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==3){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 9:\n");
                                        printf("      Ao entrar num tunel � proibido:\n");
                                        printf("      1-Ultrapassar.\n      2-Parar e estacionar.\n      3-Ligar os m�dios.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==2){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        exame();
                                        printf("      Quest�o 10:\n");
                                        printf("      Perante um sinal luminoso que esteja amarelo devo:\n");
                                        printf("      1-Acelarar e passar o mais rapido possivel.\n      2-Travar a fundo.\n      3-Fazer invers�o de marcha.\n      4-Reduzir a velocidade e parar.\n");
                                        printf("\n      >");
                                        scanf("%i",&resposta);
                                        if(resposta==4){
                                            pontos++;
                                        }
                                        resposta = 0;
                                        system("cls");

                                        if(pontos<9){
                                            exame();
                                            printf("      Exame reprovado: Acertou %i/10\n      Deseja:\n      [1]Repetir o Exame!\n      [2]Desistir\n      >",pontos);
                                            scanf("%i",&opcao6);

                                            fp = fopen("exame.txt", "r");
                                            fscanf(fp, "%i", &e.exame1);
                                            e.exame1++;
                                            fclose(fp);
                                            fp = fopen("exame.txt", "w");
                                            fprintf(fp,"%i",e.exame1);
                                            fclose(fp);

                                        }else{
                                            exame();
                                            printf("      PARABENS!!!!\n      Exame Aprovado: Acertou %i/10\n      A carta de condu��o vai ser imprimida em seu nome!!\n",pontos);
                                            printf("      Clique ENTER para sair!\n");

                                            fp = fopen("exame.txt", "r");
                                            fscanf(fp, "%i", &e.exame1);
                                            e.exame1++;
                                            fclose(fp);
                                            fp = fopen("exame.txt", "w");
                                            fprintf(fp,"%i",e.exame1);
                                            fclose(fp);

                                            strcat(p.nomecompleto, p.nome);
                                            strcat(p.nomecompleto, space);
                                            strcat(p.nomecompleto, p.apelido);

                                            sprintf(filename, "%s.txt", p.nomecompleto);
                                            out = fopen( filename, "a+");

                                            fprintf(out, R"EOF(
  __________________________________________________________________________________
 |  _______________________
 | |                       |
 | |          ___          |       Carta de Condu��o  |  Republica Portuguesa
 | |         | _ \         |
 | |         |  _/         |	-------------------------------------------------
 | |         |_|           |    Apelido[s] %s
 | |                       |    -------------------------------------------------
 | |_______________________|	Nome[s] %s
 |                        	-------------------------------------------------
 |     /////////////\\\\    	Data de Nascimento %s
 |    (((((((((((((( \\\\   	-------------------------------------------------
 |    ))) ~~      ~~  (((
 |    ((( (*)     (*) )))   	                   ______--------___
 |    )))     <       (((                         /|             / |
 |    ((( '\______/`  )))              o___________|_\__________/__|
 |    )))\___________/(((             ]|___     |  |=   ||  =|___  |"
 |           _) (_                    //   \\    |  |____||_///   \\|"
 |          / \_/ \                   |  X  |\--------------/|  X  |\"
 |         /(     )\                   \___/                  \___/
 |        // )___( \\
 |__________________________________________________________________________________)EOF",p.apelido,p.nome,p.data);


                                            fclose(out);
                                            getch();

                                            fp = fopen("conducao.txt", "r");
                                            fscanf(fp, "%i", &e.conducao1);
                                            e.conducao1++;
                                            fclose(fp);
                                            fp = fopen("conducao.txt", "w");
                                            fprintf(fp,"%i",e.conducao1);
                                            fclose(fp);

                                            return 0;

                                        }

                                    }while(opcao6=!1);
                                        return 0;

                                break;


                            }
                    break;

                    case 4: system("cls");
                            perguntas();
                            printf("      Pergunta 1: Quantas quest�es erradas posso ter no exame de codigo?\n          �Resposta: Apenas pode errar uma quest�o!\n\n");
                            printf("      Pergunta 2: Posso repetir quantas vezes o exame de codigo?\n          �Resposta: Pode repetir as vezes necess�rias!\n\n");
                            printf("      Pergunta 3: � necess�rio pagar por algum dos documentos?\n          �Resposta: N�o, a utiliza��o do programa e os documentos s�o gratuitos!\n\n");
                            printf("      [1]Voltar\n      >");
                            scanf("%i",&op3);
                    break;

                    case 5: op2++;break;
                }
                        }while(op3 != 0);
        break;

        case 2: system("cls");
                admin();
                adminlogin();
                system("color 0A");

                do{
                variavel = 0;
                op4 = 0;
                op5 =0;
                op = 0;

                printf("  Pretende aceder a:\n\n  [1]Estatisticas\n  [2]Pesquisar Nomes\n  [3]Sair\n\n  > ");
                scanf("%i",&op);

                switch(op){

                    case 1: system("cls"); // Estatisticas: d� printf dos valores guardados
                            stats();
                            printf("    Estatisticas:\n\n      Numero de Cart�es de Cidad�o Produzidos: ");

                            fp = fopen("cidadao.txt", "r");
                            fscanf(fp, "%i", &e.cidadao);
                            printf("%i\n      ------------------------------------------\n\n",e.cidadao);
                            fclose(fp);

                            printf("      Numero de Passaportes Produzidos: ");
                            fp = fopen("passaporte.txt", "r");
                            fscanf(fp, "%i", &e.passaporte);
                            printf("%i\n      -----------------------------------\n\n",e.passaporte);
                            fclose(fp);

                            printf("      Numero de Cartas de Condu��oProduzidas: ");
                            fp = fopen("conducao.txt", "r");
                            fscanf(fp, "%i", &e.conducao);
                            printf("%i\n      -----------------------------------------\n\n",e.conducao);
                            fclose(fp);

                            printf("      Numero de Exames Realizados: ");
                            fp = fopen("exame.txt", "r");
                            fscanf(fp, "%i", &e.exame);
                            printf("%i\n      ------------------------------\n\n\n",e.exame);
                            fclose(fp);

                            printf("    [1]Voltar    [2]Sair\n    >");
                            scanf("%i",&op4);
                            if(op4 == 1){
                                fflush(stdin);
                                system("cls");
                                admin();
                                variavel++;
                            }else{
                                op2++;
                            }

                    break;

                    case 2: do{
                            // Pesquisa o nome das pessoas para ver os documentos
                            fflush(stdin);
                            system("cls");
                            pesquisar();
                            printf("    Coloque o nome completo de quem quer pesquisar:\n    >");
                            gets(p.nomecompleto);

                            sprintf(filename, "%s.txt", p.nomecompleto);
                            out = fopen( filename, "r+");

                            if (NULL == out) {
                                printf("    Nome n�o encontrado no sistema.\n    [1]Voltar    [2]Sair\n    > ");
                                scanf("%i",&op4);
                                if(op4 == 1){
                                    op5++;
                                }else{
                                    variavel++;
                                    system("cls");
                                    admin();
                                }
                            }

                            do{
                                guardar = fgetc(out);
                                putchar(guardar);
                            } while(guardar != EOF);

                            fclose(out);
                            printf("\n\n    [1]Pesquisar outro nome    [2]Sair\n    >");
                            scanf("%i",&op4);
                                if(op4 == 1){
                                    op5++;
                                }else{
                                    variavel++;
                                    system("cls");
                                    admin();
                                }
                    }while(op5 != 0);

                    break;

                    case 3: op2++;

                    default:printf("ERRO");

                }
        }while(variavel != 0);

        break;

    }

    }while(op2 != 0);

    return 0;
}

