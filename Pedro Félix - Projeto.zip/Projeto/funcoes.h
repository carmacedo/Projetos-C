#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

#define MAX_SENHA 6
#define MAX_LOGIN 50

// Fun��o us�da para verificar se o nome e a senha da conta est�o bem

int Usuario( FILE* file, char* user, char* senha, int j )
{

    char tmpLogin[MAX_LOGIN];
    char tmpSenha[MAX_SENHA];


    fscanf(file, "%s", tmpLogin);

    while( !feof(file) )
    {
        if( !strcmp(tmpLogin, user) )
        {
            fscanf(file, "%s", tmpSenha);

            if( !strcmp(tmpSenha, senha) )
            return 1;
        }else
            {
                fscanf(file, "%*s");
            }


        fscanf(file, "%s", tmpLogin);
    }

return 0;
}

// Fun��o us�da para criar a senha e substituir os caracteres por " * "
char* CriaSenha()
{
    register int i;

    char* senha = (char*)malloc(sizeof *senha * MAX_SENHA);

    for(i = 0; i < MAX_SENHA; i++)
    {
        senha[i] = getch();
        if(senha[i] == '\r')
        break;
        else
        printf("*");
    }
    senha[i] = '\0';

    return senha;
}

// Fun��o us�da para imprimir na tela do utilizador uma coisa apenas visual
entrarconta()
{
    int a,b;

    printf("\n      A verificar");
    for(int i=0;i<=6;i++)
    {
        for(int j=0;j<100000000;j++)
             a=j;
       printf(".");
    }
    system("cls");
    conta();
    printf("\n      Bem-Vindo\n      Clique enter para continuar!");
}

// Fun��o us�da para colocar as setas nos menus
void arrowHere(int realPosition, int arrowPosition){

    if(realPosition == arrowPosition){

        printf("   --> ");
    }else{

        printf("       ");
    }
}

// Fun��o us�da para a verifica��o do nome e da palavra - passe do admin ( apenas login)
adminlogin()
{
    int lol=0;
    do{

    int p=0;
    char password[20], username[20];
    lol=0;

    printf("  Coloque o nome:\n  >");
    scanf("%s",&username);

    fflush(stdin);

    printf("  Coloque a palavra-passe:\n  >");
    do{
        password[p]=getch();
        if(password[p]!='\r'){
            printf("*");
        }
        p++;
    }while(password[p-1]!='\r');
    password[p-1]='\0';

    fflush(stdin);

    if(strcmp(username,"admin")==0){
        if(strcmp(password,"123")==0){

            system("cls");
            admin();
            printf("\n  Bem-Vindo Admin!\n\n");

        }else{
                printf("\n  Palavra-Passe errada\n  Clique ENTER para tentar novamente....\n");
                getch();
                lol++;
            }
        }else{
                printf("\n  Nome n�o existente\n  Clique ENTER para tentar novamente....\n");
                getch();
                lol++;
            }

    }while(lol != 0);
}




#endif // FUNCOES_H_INCLUDED
