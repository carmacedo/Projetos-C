#ifndef FL1_H_INCLUDED
#define FL1_H_INCLUDED
#include "fl2.h"
struct utilizador{
char nome[20];
char senha[20];
};

struct utilizador u;
    login()
    {
     char bla[10],lgg[100],erro[100];
     FILE *fu;
     FILE *lg;
     FILE *er;
                                        textcolor(3);
                                       lg= fopen("login.txt","r");
                                      while(fgets(lgg,100,lg)!= NULL )
                                      printf("%s",lgg);
      fflush(stdin);
      gotoxy(20,20);
        textcolor(6);
     printf("\n \n\n\n  \t \t \t \t \t \t \t \t \t \t \t \t \t   Utilizador:");
     textcolor(3);
     gets(u.nome);
    strcpy(bla, u.nome);
     fflush(stdin);
     textcolor(6);
     printf("\n  \t \t \t \t \t \t \t \t \t \t \t \t \t     Senha:");
      textcolor(3);
       int p=0;
    do{
        u.senha[p]=getch();
        if(u.senha[p]!='\r'){
            printf("*");
        }
        p++;
    }while(u.senha[p-1]!='\r');

        u.senha[p-1]='\0';
     fflush(stdin);
    strcat(u.nome, u.senha);
    fu = fopen(u.nome,"r");
        if(fu){
        diario(bla);
        }
        else {
            system("cls");
            textcolor(12);
            er= fopen("errado.txt","r");
            while(fgets(erro,100,er)!= NULL )
            printf("%s",erro);
             Sleep(800);
            getch();
           system("cls");
 } }



    reg()
{
        FILE *fu;
     char ru[10],rp[10],regi[100];
     FILE *r;
     FILE *re;
     textcolor(3);
    re= fopen("register.txt","r");
    while(fgets(regi,100,re)!= NULL )
    printf("%s",regi);
     fflush(stdin);
      gotoxy(20,20);
      textcolor(9);
     printf("\n \n \n \n \n\n \n\n\n \n \t \t \t \t \t \t \t \t \t \t \t \t \t  Utilizador:");
     textcolor(11);
     gets(ru);
     fflush(stdin);
     textcolor(9);
     printf("\n \n \t \t \t \t \t \t \t \t \t \t \t \t \t   Senha:");
     textcolor(11);
        int p=0;
    do{
        rp[p]=getch();
        if(rp[p]!='\r'){
            printf("*");
        }
        p++;
    }while(rp[p-1]!='\r');
    rp[p-1]='\0';
     fflush(stdin);
     strcat(ru, rp);
     fu = fopen(ru,"r");
     if(fu){
        system("cls");
         printf("\nEste nome j� est� a ser utilizado\n");
         getch();
         system("cls");
         printf("\nTenta denovo daqui a 3 ...\n");
         Sleep(1000);
         system("cls");
         printf("\nTenta denovo daqui a 2 ...\n");
         Sleep(1000);
         system("cls");
         printf("\nTenta denovo daqui a 1 ...\n");
         Sleep(1000);
         system("cls");
            reg();
     }
     else{
     r=fopen(("%s",ru),"w+");
     fclose(r);
     system("cls");
     login();

     }

    }

#endif // FL1_H_INCLUDED
