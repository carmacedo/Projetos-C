#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <windows.h>
#include <string.h>
#include "fl1.h"
#include <string.h>
#include "fl2.h"



struct seta{
char m[0];
char d[0];
};
struct seta s;





int main()
{
keybd_event(VK_MENU  , 0x36, 0, 0);
keybd_event(VK_RETURN, 0x1C, 0, 0);
keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
keybd_event(VK_MENU  , 0x38, KEYEVENTF_KEYUP, 0);



                setlocale(LC_ALL,"Portuguese");
                int f,bla,i,ya,xd,p;
                p=0;
                FILE *a;
                FILE *fechar;
                FILE *abrir;
                char y[200],letra,fechando[300],abrindo[300];

                                            gotoxy(20,20);
                                            textcolor(1);
                                 printf("\t     \t    \t                \t    \t \t \tLoading.");
                                 Sleep(500);
                                  system("cls");
                                    textcolor(9);
                                  gotoxy(20,20);
                                  printf("\t     \t    \t                \t    \t \t \tLoading..");
                                  Sleep(500);
                                  system("cls");
                                  gotoxy(20,20);
                                   textcolor(3);
                                  printf("\t     \t    \t                \t    \t \t \tLoading...");
                                Sleep(500);
                                   system("cls");
                                  gotoxy(20,20);
                                  textcolor(1);
                                 printf("\t     \t    \t                \t    \t \t \tLoading.");
                                  Sleep(500);
                                   system("cls");
                                  gotoxy(20,20);
                                   textcolor(9);
                                   printf("\t     \t    \t                \t    \t \t \tLoading..");
                                  Sleep(500);
                                   system("cls");
                                  gotoxy(20,20);
                                  textcolor(3);
                                   printf("\t     \t    \t                \t    \t \t \tLoading...");
                                   Sleep(500);
                                   system("cls");


                                                    abrir= fopen("aberto.txt","r");
                                                    while(fgets(abrindo,100,abrir)!= NULL )
                                                    printf("%s",abrindo);
                                                    Sleep(500);


do{
                system("cls");
                                textcolor(1);

                                a= fopen("menu.txt","r");
                                while(fgets(y,300,a)!= NULL )
                                printf("\t %s",y);
                                textcolor(3);

                                FILE *a2;
                                char y2[100];
                                a2=fopen("menu2.txt","r");
                                while(fgets(y2,300,a2)!= NULL )
                                printf("\t %s",y2);

                                textcolor(13);
                                FILE *a3;
                                char y3[100];
                                a3= fopen("menu3.txt","r");
                                while(fgets(y3,300,a3)!= NULL )
                                printf("\t %s",y3);

                            gotoxy(1,20);
                            fflush(stdin);

                        textcolor(0);
                        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

                            s.m[p]=getch();
                            s.m[p-1]='\0';

                                if(s.m[p]=='1'){
                                    system("cls");
                                a= fopen("menu.txt","r");
                                while(fgets(y,100,a)!= NULL )
                                printf("\t %s",y);


                                        gotoxy(1,20);


                                                system("cls");
                                                 login();
                                }

                                 else if(s.m[p]=='2'){
                                        system("cls");
                                a= fopen("menu.txt","r");
                                while(fgets(y,100,a)!= NULL )
                                printf("\t %s",y);
                                        gotoxy(1,20);
                                         system("cls");
                                        reg();
                                 }

                                  else if (s.m[p]=='3')
                                  {         system("cls");
                                a= fopen("menu.txt","r");
                                while(fgets(y,100,a)!= NULL )
                                printf("\t %s",y);
                                        gotoxy(1,20);
                                                   system("cls");
                                                   textcolor(9);
                                                     fechar= fopen("fechado.txt","r");
                                                    while(fgets(fechando,100,fechar)!= NULL )
                                                    printf("\t %s",fechando);
                                                        textcolor(0);
                                                      printf("\n\n\n\n\n\n\n\n\n");
                                                exit(0);                            }
                                  else {
                                  }
                                        }while(s.m[p]!='3');
                            }























