#ifndef FL2_H_INCLUDED
#define FL2_H_INCLUDED
#include "fl1.h"
#include <time.h>

struct menu{
char d[0];
};
struct menu m;

diario(char bla[20])
{
    int d,q,i,p;
    p=0;
    FILE *md;
    FILE *mdd;
    FILE *mddd;
    FILE *mdddd;
    FILE *xx;
    FILE *entrar;
    FILE *st;
    FILE *fc;
    char ed [100],edd[100],eddd[100],edddd[100],xaulaura[100],join[100],setta[100],telogo[100];
    char nomeg[20];
    system("cls");

do{
         SYSTEMTIME t;
    GetLocalTime(&t);
system("cls");

                                textcolor(6);
                                md= fopen("grandem.txt","r");
                                while(fgets(ed,100,md)!= NULL )
                                printf("%s",ed);
                                strcpy(nomeg,bla);
                                textcolor(3);
                                gotoxy(20,18);
                                 printf("\n\n");
                                mddd= fopen("mdiario.txt","r");
                                while(fgets(eddd,100,mddd)!= NULL )
                                printf("\t\t\t\t\t%s",eddd);
                                gotoxy(20,18);
                                printf("\n\n");
                                textcolor(10);
                                 mdd= fopen("mdiarioo.txt","r");
                                while(fgets(edd,100,mdd)!= NULL)
                                    printf("\t\t\t\t\t\t\t\t\t\t\t\t\t%s",edd);
                                printf("\n\n\n\n\n\n\n");
                                    textcolor(13);
                                mdddd= fopen("definicoes.txt","r");
                                 while(fgets(edddd,100,mdddd)!= NULL )
                                 printf("\t\t\t\t%s",edddd);
                                q=strlen(nomeg);
                                textcolor(12);
                                gotoxy(20,18);
                                  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                                xx= fopen("xau.txt","r");
                                 while(fgets(xaulaura,100,xx)!= NULL )

                                 printf("\t\t\t\t\t\t\t\t\t\t\t\t\t\t   %s",xaulaura);

                            gotoxy(20,1);
                             printf("\n\n\n\n\n\n\n\n");
                            printf("\t\t\t\t\t\t\t\t\t\t\t");
                            textcolor(13);
                            printf("|%d/%d/%d| \n\n",t.wDay, t.wMonth, t.wYear);
                             textcolor(9);
                            printf("\t\t\t\t\t\t\t\t\t\t\t  |%d:%d|\n",t.wHour, t.wMinute);
                            textcolor(2);
                            printf("\n\n\t\t\t\t\t\t\t\t\t\t\t    ");


                                      m.d[p]=getch();
                                      m.d[p-1]='\0';
                                    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                                    textcolor(15);

           textcolor(15);


         if(m.d[p]=='1'){     dia(bla);}
         else if(m.d[p]=='2') {historico(bla); }
         else if(m.d[p]=='3'){ def(bla);}
         else if(m.d[p]=='4'){
                system("cls");  textcolor(6);
                 fc= fopen("fechado.txt","r");
                  while(fgets(telogo,100,fc)!= NULL )
                   printf("\t %s",telogo);
                    textcolor(0);
                      printf("\n\n\n\n\n\n\n\n\n");
                       exit(0);}

         }while(m.d[p]!='5');

}


struct linha{
char t1[90];
char t2[90];
char t3[90];
char t4[90];
char t5[90];
char t6[90];
char t7[90];
char t8[90];
char t9[90];
char t10[90];
};
struct linha l;

dia(char bla[20],char livrinho[30])
{

    SYSTEMTIME t;
    GetLocalTime(&t);
    system("cls");
    FILE *md;
    FILE *ff;
    FILE *fq;
    FILE *mf;
    FILE *gd;
    FILE *sa;
    FILE *uu;
    FILE *ddois;
    FILE *gu;
    FILE *mano;
    char ed [100],fo[200],q[200],fmm[200],nome[30],gescrita[40],ya[30],sair[100],umm[100],dois[100],guardar[100],bro[100];
    int lq,sel,p;
                char*dateStr[9];
                char*timeStr[9];
                char tempo[20];
                p=0;
                                    strcpy(ya,bla);
                                        textcolor(3);
                                       md= fopen("ldiario.txt","r");

                                      while(fgets(ed,100,md)!= NULL )
                                      printf("\t \t %s",ed);

                                      gotoxy(1,1);
                                        sa= fopen("voltar.txt","r");
                                       while(fgets(sair,200,sa)!= NULL)
                                       printf("%s",sair);


                                        textcolor(6);
                                        gotoxy(20,15);


                                          uu= fopen("um.txt","r");
                                       while(fgets(umm,200,uu)!= NULL)
                                       printf("\t\t\t\t\t%s",umm);
                                        gotoxy(20,15);
                                        textcolor(14);
                                        printf("\n\n");
                                        ddois= fopen("dois.txt","r");
                                       while(fgets(dois,200,ddois)!= NULL)
                                       printf("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t%s",dois);

                                        textcolor(15);

                                       mf= fopen("menufl.txt","r");
                                       while(fgets(fmm,200,mf)!= NULL)
                                       printf("%s",fmm);


                                      gotoxy(2,20);

                                        gotoxy(2,20);

                                         m.d[p]=getch();
                                         m.d[p-1]='\0';

                                       //scanf("%i",&lq);


                                        if(m.d[p]=='1'){
                                            system("cls");
                                            textcolor(3);
                                       md= fopen("ldiario.txt","r");

                                      while(fgets(ed,100,md)!= NULL )
                                      printf("\t \t %s",ed);

                                      gotoxy(1,1);
                                        sa= fopen("voltar.txt","r");
                                       while(fgets(sair,200,sa)!= NULL)
                                       printf("%s",sair);


                                        textcolor(6);
                                        gotoxy(20,15);
                                        textbackground(15);

uu= fopen("um.txt","r");
 while(fgets(umm,200,uu)!= NULL)
printf("\t\t\t\t\t%s",umm);
 gotoxy(20,15);
textbackground(0);
textcolor(6);
printf("\n");
ddois= fopen("dois.txt","r");
while(fgets(dois,200,ddois)!= NULL)
printf("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t%s",dois);
textcolor(15);
mf= fopen("menufl.txt","r");
while(fgets(fmm,200,mf)!= NULL)
printf("%s",fmm);
Sleep(1000);
system("cls");
textbackground(0);
textcolor(15);
textcolor(3);
md= fopen("ldiario.txt","r");
while(fgets(ed,100,md)!= NULL )
printf("\t \t%s",ed);
textcolor(7);
 printf("\n\n\n\n\n");
 ff= fopen("linhas.txt","r");
while(fgets(fo,200,ff)!= NULL)
printf("\t\t%s",fo);
                            textcolor(15);
                            fflush(stdin);
                            gotoxy(2,11);
                printf("\n\n\n\n\n\n\n\n\n\n");
                printf("\t\t\t\t\t\t\t\t     ->"); gets(l.t1);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t2);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t3);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t4);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t5);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t6);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t7);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t8);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t9);
                printf("\t\t\t\t\t\t\t\t");  gets(l.t10);
printf("\t\t\t\t\t\t\t\t\t%d/%d/%d | %d:%d ",t.wDay, t.wMonth, t.wYear , t.wHour, t.wMinute);
printf(" \t por:%s\n",ya);
textcolor(11);
mano= fopen("guardadinho.txt","r");
while(fgets(bro,200,mano)!= NULL)
printf("\t\t%s",bro);
gotoxy(20,20);
printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t\t  ");
gets(gescrita);
strcat(ya,"-");
strcat(ya,gescrita);
strcat(ya,".txt");
gd = fopen(ya,"w+");
fprintf(gd," \t\t%s\n",l.t1);
fprintf(gd," %s\n",l.t2);
fprintf(gd," %s\n",l.t3);
fprintf(gd," %s\n",l.t4);
fprintf(gd," %s\n",l.t5);
fprintf(gd," %s\n",l.t6);
fprintf(gd," %s\n",l.t7);
fprintf(gd,"%s\n",l.t8);
fprintf(gd," %s\n",l.t9);
fprintf(gd," %s\n",l.t10);
fprintf(gd,"\t\t\t\t %d/%d/%d | %d:%d",t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute);
fclose(gd);
 }

  else if(m.d[p]=='2'){
system("cls");
textcolor(3);
md= fopen("ldiario.txt","r");
while(fgets(ed,100,md)!= NULL )
 printf("\t \t %s",ed);
gotoxy(1,1);
sa= fopen("voltar.txt","r");
while(fgets(sair,200,sa)!= NULL)
printf("%s",sair);
textcolor(6);
gotoxy(20,15);
textbackground(0);
uu= fopen("um.txt","r");
while(fgets(umm,200,uu)!= NULL)
 printf("\t\t\t\t\t%s",umm);
gotoxy(20,15);
textcolor(6);
textbackground(15);
printf("\n");
ddois= fopen("dois.txt","r");
while(fgets(dois,200,ddois)!= NULL)
printf("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t%s",dois);
textbackground(0);
textcolor(15);
mf= fopen("menufl.txt","r");
while(fgets(fmm,200,mf)!= NULL)
printf("%s",fmm);
Sleep(1000);
system("cls");
textbackground(0);
textcolor(3);
md= fopen("ldiario.txt","r");
while(fgets(ed,100,md)!= NULL )
printf("\t \t  %s",ed);
textcolor(7);
ff= fopen("quadradinhos.txt","r");
while(fgets(fo,200,ff)!= NULL)
printf("\t\t%s",fo);
fflush(stdin);
gotoxy(2,11);
textcolor(15);
 printf("\n\n\n\n\n\n");
 printf("\t\t\t\t\t\t\t\t    ->");  gets(l.t1);
printf("\t\t\t\t\t\t\t\t");  gets(l.t2);
printf("\t\t\t\t\t\t\t\t");  gets(l.t3);
printf("\t\t\t\t\t\t\t\t");  gets(l.t4);
printf("\t\t\t\t\t\t\t\t");  gets(l.t5);
printf("\t\t\t\t\t\t\t\t");  gets(l.t6);
printf("\t\t\t\t\t\t\t\t");  gets(l.t7);
printf("\t\t\t\t\t\t\t\t");  gets(l.t8);
printf("\t\t\t\t\t\t\t\t");  gets(l.t9);
printf("\t\t\t\t\t\t\t\t");  gets(l.t10);
printf("\t\t\t\t\t\t\t\t\t %d/%d/%d | %d:%d ",t.wDay, t.wMonth, t.wYear , t.wHour, t.wMinute);

printf(" \t por:%s\n",ya);
 printf("\n");
textcolor(11);
gu= fopen("guardadinho.txt","r");
while(fgets(guardar,200,gu)!= NULL)
 printf("\t\t%s",guardar);
gotoxy(20,20);
printf("\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t\t  ");
gets(gescrita);
strcat(ya,"-");
strcat(ya,gescrita);
strcat(ya,".txt");
gd = fopen(ya,"w+");
fprintf(gd," \t\t%s\n",l.t1);
fprintf(gd," %s\n",l.t2);
fprintf(gd," %s\n",l.t3);
fprintf(gd," %s\n",l.t4);
fprintf(gd," %s\n",l.t5);
fprintf(gd," %s\n",l.t6);
fprintf(gd," %s\n",l.t7);
fprintf(gd,"%s\n",l.t8);
fprintf(gd," %s\n",l.t9);
fprintf(gd," %s\n",l.t10);
fprintf(gd,"\t\t\t\t %d/%d/%d | %d:%d",t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute);
fclose(gd);
 }
                                            else{}


}

    historico(char bla[50]){
        system("cls");
              FILE*hi;
              FILE*l;
              FILE*yau;
              FILE*ab;
              FILE*chekk;
              FILE*inva;
              FILE *fim;
              char his[100],la[100],p[50]="dir ",fol[50]="Folha-Do-historico-",fff[100],abertura[100],note[100],che[100],invalido[100],fya[100];
                     textcolor(6);
                hi= fopen("historico.txt","r");
                 while(fgets(his,200,hi)!= NULL)
                printf("\t\t\t\t\t\t%s",his);
                    textcolor(15);

                 //   l= fopen("lh.txt","r");
                // while(fgets(la,200,l)!= NULL)
              //  printf("\t\t\t\t\t%s",la);


                   // printf("%s\n",bla);

                    strcat(p,"*");
                    strcat(p,bla);
                    strcat(p,"*.txt>Folha-Do-historico-");
                    strcat(p,bla);
                    strcat(p,".txt");
                        system(p);

                    strcat(fol,bla);
                    strcat(fol,".txt");

                        yau=fopen(fol,"r");
                         while(fgets(fff,200,yau)!= NULL)
                            printf("\t\t\t\t\t %s",fff);
                            gotoxy(20,20);
                            textcolor(1);
                            printf("\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\tFicheiro:");
                            fflush(stdin);
                            textcolor(11);
                            gets(note);
                                chekk=fopen(note,"r");
                           if(!chekk)
                            {
                                    system("cls");
                                inva=fopen("invalido.txt","r");
                                 while(fgets(invalido,200,inva)!= NULL)
                                   printf("\t\t\t\t\t %s",invalido);
                                    fclose(inva);
                                   system("pause");
                        }
                        else {
                                system("cls");
                                textcolor(6);
                            hi= fopen("historico.txt","r");
                            while(fgets(his,900,hi)!= NULL)
                            printf("\t\t\t\t\t\t%s",his);
                            textcolor(15);
                            textcolor(1);
                            fim= fopen("fin.txt","r");
                            while(fgets(fya,200,fim)!= NULL)
                            printf("\t\t\t\t\t\t%s",fya);
                            textcolor(11);
                        gotoxy(20,10);
                        printf("\n\n\n\n\n\n");

                                chekk=fopen(note,"r+");
                               while(fgets(che,200,chekk)!= NULL)
                               printf("\t\t\t\t\t\t\t%s",che);
                                printf("\n\n\n\n");
                                getch();
                            }


    }



    def(char bla[30])
    {
        FILE *h;
        FILE *pp;
        FILE *rt;
        FILE *esqueci;
        FILE *jf;
        FILE *byyu;
        FILE *kkk;
        FILE *ej;
        FILE *ef;
        char ht[100],ha[30]="dir ",el[20],esp[100],fl[50]="Folha-Do-historico-",rb[100],seila[100],jv[100],blll[100],tl[100],win[100],fulls[100];
        int j,ms;
                        system("cls");
                                    textcolor(13);
                                h=fopen("md.txt","r");
                               while(fgets(ht,100,h)!= NULL)
                               printf("\t\t %s",ht);
                                printf("\n");
                    fclose(h);
                     textcolor(11);
                            esqueci=fopen("ripf.txt","r");
                            while(fgets(seila,100,esqueci)!= NULL)
                            printf("%s",seila);
                            fclose(esqueci);
    textcolor(6);
                            byyu=fopen("modof.txt","r");
                            while(fgets(blll,100,byyu)!= NULL)
                            printf("%s",blll);
                            fclose(byyu);
textcolor(12);
                            kkk=fopen("ghh.txt","r");
                            while(fgets(tl,100,byyu)!= NULL)
                            printf("%s",tl);
                            fclose(kkk);
                        int p;
                         p=0;
                            m.d[p]=getch();
                            m.d[p-1]='\0';




  if(m.d[p]=='1'){
            system("cls");
                                h=fopen("definicoes.txt","r");
                               while(fgets(ht,100,h)!= NULL)
                               printf("\t\t%s",ht);
                    strcat(ha,"*");
                    strcat(ha,bla);
                    strcat(ha,"*.txt>Folha-Do-historico-");
                    strcat(ha,bla);
                    strcat(ha,".txt");
                    system(ha);
                    strcat(fl,bla);
                    strcat(fl,".txt");
                textcolor(15);
                    pp=fopen(fl,"r");
                         while(fgets(esp,200,pp)!= NULL)
                            printf("\t\t\t\t\t %s",esp);
                    fflush(stdin);

                    printf("\n\nEliminar ficheiro:");
                    gets(el);
                                if (remove(el) == 0)

                                    {       system("cls");
                                            textcolor(6);
                                           jf=fopen("concluida.txt","r");
                                        while(fgets(jv,200,jf)!= NULL)
                                        printf("\t\t\t\t\t %s",jv);
                                        textcolor(1);
                                        printf("\n\n\n\n\n");
                                        system("pause");


                                    }

        else{                   textcolor(12);
                                system("cls");
                                rt=fopen("invalido.txt","r");
                                 while(fgets(rb,200,rt)!= NULL)
                                   printf("\t\t\t\t\t %s",rb);
                                    fclose(rt);
                                   system("pause");

        }
  }
   else if(m.d[p]=='2'){ system("cls");

                                textcolor(13);
                                h=fopen("md.txt","r");
                                while(fgets(ht,100,h)!= NULL)
                                printf("\t\t %s",ht);
                                printf("\n");
                                fclose(h);

 textcolor(2);
                                ej=fopen("ejanela.txt","r");
                                while(fgets(win,100,ej)!= NULL)
                                printf("\t\t %s",win);
                                printf("\n");
                                fclose(ej);
  textcolor(3);

                              ef=fopen("efull.txt","r");
                                while(fgets(fulls,100,ef)!= NULL)
                                printf("\t\t %s",fulls);
                                printf("\n");
                                fclose(ej);

                            textcolor(12);
                            kkk=fopen("ghh.txt","r");
                            while(fgets(tl,100,byyu)!= NULL)
                            printf("%s",tl);
                            fclose(kkk);

int lol;
lol=0;
                            m.d[lol]=getch();
                            m.d[lol-1]='\0';
                         if(m.d[p]=='1')
                                {
                                keybd_event(VK_MENU  , 0x36, 0, 0);
                                keybd_event(VK_RETURN, 0x1C, 0, 0);
                                keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
                                keybd_event(VK_MENU  , 0x38, KEYEVENTF_KEYUP, 0);
                                system("MODE 750");}

                             else  if(m.d[p]=='2'){ keybd_event(VK_MENU  , 0x36, 0, 0);
                                keybd_event(VK_RETURN, 0x1C, 0, 0);
                                keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
                                keybd_event(VK_MENU  , 0x38, KEYEVENTF_KEYUP, 0);}

                               else   if(m.d[p]=='3') {}
                                else{}


     }
else if(m.d[p]=='3'){}
else{}
return 0;
    }

#endif // FL2_H_INCLUDED
