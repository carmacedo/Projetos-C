#ifndef MENUPRINCIPALPT_H_INCLUDED
#define MENUPRINCIPALPT_H_INCLUDED

menuprincipalpor()
{
    printf("PT");
}

#endif // MENUPRINCIPALPT_H_INCLUDED
