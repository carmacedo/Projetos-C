#ifndef SWITCHLANG_H_INCLUDED
#define SWITCHLANG_H_INCLUDED

switchlang(char lang)
{
    switch(lang)
    {
        case P:
            PTTransportes();
        case E:
            ENTransportes();
        default:
            return;
    }
}

#endif // SWITCHLANG_H_INCLUDED
