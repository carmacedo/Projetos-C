#ifndef TRAINS_H_INCLUDED
#define TRAINS_H_INCLUDED

trains()
{
    textcolor(LIGHTBLUE);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(
          ______           _
         /_  __/________ _(_)___  _____
          / / / ___/ __ `/ / __ \/ ___/
         / / / /  / /_/ / / / / (__  )
        /_/ /_/   \__,_/_/_/ /_/____/

   Select which company you want to travel with:

    1 - Comboios de Portugal - CP
    2 - Fertagus - O Comboio da Ponte

        > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        cpen();
        break;
        case 2:
            fertagusen();
            break;
    }
    getch();

}

comboios()
{
    textcolor(LIGHTBLUE);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

           ______                __          _
          / ____/___  ____ ___  / /_  ____  (_)___  _____
         / /   / __ \/ __ `__ \/ __ \/ __ \/ / __ \/ ___/
        / /___/ /_/ / / / / / / /_/ / /_/ / / /_/ (__  )
        \____/\____/_/ /_/ /_/_.___/\____/_/\____/____/


        Seleciona a empresa com que queres viajar:

            1 - Comboios de Portugal - CP
            2 - Fertagus - O Comboio da Ponte

                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        cppt();
        break;
        case 2:
            fertaguspt();
            break;
    }
    getch();

}

fertagusen()
{
    int menu, a, i;
    char estacao[40];
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(
            ______          __
           / ____/__  _____/ /_____ _____ ___  _______
          / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/
         / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )
        /_/    \___/_/   \__/\__,_/\__, /\__,_/____/
                                  /____/

        Select the direction you want to navigate:

                1 - Lisbon to Set�bal
                2 - Set�bal to Lisbon

                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

        __    _      __                   __           _____      __    __  __          __
       / /   (_)____/ /_  ____  ____     / /_____     / ___/___  / /___/_/_/ /_  ____ _/ /
      / /   / / ___/ __ \/ __ \/ __ \   / __/ __ \    \__ \/ _ \/ __/ / / / __ \/ __ `/ /
     / /___/ (__  ) /_/ / /_/ / / / /  / /_/ /_/ /   ___/ /  __/ /_/ /_/ / /_/ / /_/ / /
    /_____/_/____/_.___/\____/_/ /_/   \__/\____/   /____/\___/\__/\__,_/_.___/\__,_/_/

        )EOF");
        printf(R"EOF(Stations:
        > Roma-Areeiro
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Type the Station you're in:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela

                     )EOF");
        gotoxy(47,15);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

        __    _      __                   __           _____      __    __  __          __
       / /   (_)____/ /_  ____  ____     / /_____     / ___/___  / /___/_/_/ /_  ____ _/ /
      / /   / / ___/ __ \/ __ \/ __ \   / __/ __ \    \__ \/ _ \/ __/ / / / __ \/ __ `/ /
     / /___/ (__  ) /_/ / /_/ / / / /  / /_/ /_/ /   ___/ /  __/ /_/ /_/ / /_/ / /_/ / /
    /_____/_/____/_.___/\____/_/ /_/   \__/\____/   /____/\___/\__/\__,_/_.___/\__,_/_/





                            Type the time you want to departure
                            Format Hour:Minutes:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Sete-Rios")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Sete-Rios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pragal")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Pragal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Corroios")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Corroios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Foros-de-Amora")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Foros-de-Amora/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Fogueteiro")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Fogueteiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Coina")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Coina/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Penalva")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Penalva/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pinhal-Novo")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Pinhal-Novo/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"V.Alcaide")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/V.Alcaide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Palmela")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Palmela/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

       _____      __    __  __          __   __           __    _      __
      / ___/___  / /___/_/_/ /_  ____ _/ /  / /_____     / /   (_)____/ /_  ____  ____
      \__ \/ _ \/ __/ / / / __ \/ __ `/ /  / __/ __ \   / /   / / ___/ __ \/ __ \/ __ \
     ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  / /_/ /_/ /  / /___/ (__  ) /_/ / /_/ / / / /
    /____/\___/\__/\__,_/_.___/\__,_/_/   \__/\____/  /_____/_/____/_.___/\____/_/ /_/

        )EOF");
        printf(R"EOF(Stations:
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Type the Station you're in:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela
        > Set�bal

                     )EOF");
        gotoxy(47,15);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

       _____      __    __  __          __   __           __    _      __
      / ___/___  / /___/_/_/ /_  ____ _/ /  / /_____     / /   (_)____/ /_  ____  ____
      \__ \/ _ \/ __/ / / / __ \/ __ `/ /  / __/ __ \   / /   / / ___/ __ \/ __ \/ __ \
     ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  / /_/ /_/ /  / /___/ (__  ) /_/ / /_/ / / / /
    /____/\___/\__/\__,_/_.___/\__,_/_/   \__/\____/  /_____/_/____/_.___/\____/_/ /_/




                            Type the time you want to departure
                            Format Hour:Minutes:

                                > )EOF");

        gotoxy(35,15);
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Setubal")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Setubal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Sete-Rios")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Sete-Rios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pragal")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Pragal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Corroios")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Corroios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Foros-de-Amora")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Foros-de-Amora/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Fogueteiro")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Fogueteiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Coina")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Coina/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Penalva")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Penalva/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pinhal-Novo")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Pinhal-Novo/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"V.Alcaide")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/V.Alcaide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Palmela")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Palmela/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    }
}


cppt()
{
    int menu, a, i;
    char estacao[40];
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                           __________
                          / ____/ __ \
                         / /   / /_/ /
                        / /___/ ____/
                        \____/_/


           Seleciona a Dire��o que queres viajar:

                1 - Azambuja para Sintra
                2 - Sintra para Azambuja (Em Breve)

                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

            ___                        __            _                                    _____ _       __
           /   |____  ____ _____ ___  / /_  __  __  (_)___ _   ____  ____ __________ _   / ___/(_)___  / /__________ _
          / /| /_  / / __ `/ __ `__ \/ __ \/ / / / / / __ `/  / __ \/ __ `/ ___/ __ `/   \__ \/ / __ \/ __/ ___/ __ `/
         / ___ |/ /_/ /_/ / / / / / / /_/ / /_/ / / / /_/ /  / /_/ / /_/ / /  / /_/ /   ___/ / / / / / /_/ /  / /_/ /
        /_/  |_/___/\__,_/_/ /_/ /_/_.___/\__,_/_/ /\__,_/  / .___/\__,_/_/   \__,_/   /____/_/_/ /_/\__/_/   \__,_/
                                              /___/        /_/

        )EOF");
        printf(R"EOF(Esta��es:
        > Alcantra-Terra       > Castanheira-do-Ribatejo     > Queluz
        > Algueirao            > Chelas                      > Reboleira
        > Alhandra             > Entrecampos                 > Rio-de-Mouro
        > Alverca              > Espadanal-da-Azambuja       > Roma-Areeiro
        > Amadora              > Marvila                     > Rossio
        > Amadora              > Massama                     > Sacavem
        > Azambuja             > Merces                      > Santa-Apolonia
        > Benfica              > Mira-Sintra                 > Santa-Iria
        > Bobadela             > Monte-Abra�o                > Sete-Rios
        > Braco-de-Prata       > Moscavide                   > Sintra
        > Cacem                > Oriente                     > Sta.Cruz
        > Campolide            > Portela                     > Vila-Franca-de-Xira
        > Carregado            > Povoa                       > Vila-Nova-da-Rainha

                            Escreve aqui a esta��o onde est�s:
                                > )EOF");
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

            ___                        __            _                                    _____ _       __
           /   |____  ____ _____ ___  / /_  __  __  (_)___ _   ____  ____ __________ _   / ___/(_)___  / /__________ _
          / /| /_  / / __ `/ __ `__ \/ __ \/ / / / / / __ `/  / __ \/ __ `/ ___/ __ `/   \__ \/ / __ \/ __/ ___/ __ `/
         / ___ |/ /_/ /_/ / / / / / / /_/ / /_/ / / / /_/ /  / /_/ / /_/ / /  / /_/ /   ___/ / / / / / /_/ /  / /_/ /
        /_/  |_/___/\__,_/_/ /_/ /_/_.___/\__,_/_/ /\__,_/  / .___/\__,_/_/   \__,_/   /____/_/_/ /_/\__/_/   \__,_/
                                              /___/        /_/


                            Escreve a que tempo � que queres apanhar o comboio.
                            Formato Horas:Minutos:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Alcantra-Terra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alcantra-Terra/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Algueirao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Algueirao/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Alhandra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alhandra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Alverca")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alverca/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Amadora")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Amadora/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Benfica")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Benfica/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Bobadela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Bobadela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Braco-de-Prata")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Braco-de-Prata/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Cacem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Cacem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Carregado")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Carregado/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Castanheira-do-Ribatejo")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Castanheira-do-Ribatejo/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Chelas")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Chelas/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Espadanal-da-Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Espadanal-da-Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Marvila")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Marvila/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Massama")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Massama/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Merces")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Merces/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Mira-Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Mira-Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Monte-Abraao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Monte-Abraao/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Moscavide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Moscavide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Oriente")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Oriente/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Portela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Portela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Povoa")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Povoa/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Queluz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Queluz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Reboleira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Reboleira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rio-de-Mouro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rio-de-Mouro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rossio")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rossio/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sacavem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sacavem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Apolonia")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Apolonia/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Iria")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Iria/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sta.Cruz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sta.Cruz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Franca-de-Xira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Franca-de-Xira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Nova-da-Rainha")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Nova-da-Rainha/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    case 2:/*
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

       _____      __    __  __          __      __    _      __
      / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
      \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
     ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
    /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/

        )EOF");
        textcolor(LIGHTCYAN);
        printf(R"EOF(Esta��es:
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Escreve a esta��o onde est�s:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela
        > Set�bal

                     )EOF");
        gotoxy(47,15);
        textcolor(LIGHTRED);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

                   _____      __    __  __          __      __    _      __
                  / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
                  \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
                 ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
                /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/





                            Escreve a que tempo � que queres apanhar o comboio.
                            Formato Horas:Minutos:

                                >

                     )EOF");

        gotoxy(35,15);
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Alcantra-Terra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alcantra-Terra/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Algueirao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Algueirao/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Alhandra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alhandra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Alverca")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alverca/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Amadora")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Amadora/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Benfica")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Benfica/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Bobadela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Bobadela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Braco-de-Prata")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Braco-de-Prata/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Cacem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Cacem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Carregado")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Carregado/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Castanheira-do-Ribatejo")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Castanheira-do-Ribatejo/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Chelas")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Chelas/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Espadanal-da-Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Espadanal-da-Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Marvila")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Marvila/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Massama")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Massama/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Merces")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Merces/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Mira-Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Mira-Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Monte-Abraao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Monte-Abraao/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Moscavide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Moscavide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Oriente")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Oriente/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Portela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Portela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Povoa")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Povoa/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Queluz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Queluz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Reboleira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Reboleira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rio-de-Mouro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rio-de-Mouro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rossio")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rossio/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sacavem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sacavem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Apolonia")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Apolonia/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Iria")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Iria/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sta.Cruz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sta.Cruz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Franca-de-Xira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Franca-de-Xira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Nova-da-Rainha")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Nova-da-Rainha/horas.txt";
            ct(hour, minutes, local);
        }*/
        system("cls");
        printf(R"EOF(
    ______             ______                 __                   /\//
   / ____/___ ___     / ____/___  ____  _____/ /________  ________//\/_____
  / __/ / __ `__ \   / /   / __ \/ __ \/ ___/ __/ ___/ / / / ___/ __ `/ __ \
 / /___/ / / / / /  / /___/ /_/ / / / (__  ) /_/ /  / /_/ / /__/ /_/ / /_/ /
/_____/_/ /_/ /_/   \____/\____/_/ /_/____/\__/_/   \__,_/\___/\__,_/\____/
                                                          /_)
)EOF");
        getch();
        break;
    }
}

cpen()
{
    int menu, a, i;
    char estacao[40];
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                           __________
                          / ____/ __ \
                         / /   / /_/ /
                        / /___/ ____/
                        \____/_/


           Select the direction you want to go to:

                1 - Azambuja to Sintra
                2 - Sintra to Azambuja (Coming soon)

                    > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

            ___                        __            _          __           _____ _       __
           /   |____  ____ _____ ___  / /_  __  __  (_)___ _   / /_____     / ___/(_)___  / /__________ _
          / /| /_  / / __ `/ __ `__ \/ __ \/ / / / / / __ `/  / __/ __ \    \__ \/ / __ \/ __/ ___/ __ `/
         / ___ |/ /_/ /_/ / / / / / / /_/ / /_/ / / / /_/ /  / /_/ /_/ /   ___/ / / / / / /_/ /  / /_/ /
        /_/  |_/___/\__,_/_/ /_/ /_/_.___/\__,_/_/ /\__,_/   \__/\____/   /____/_/_/ /_/\__/_/   \__,_/
                                              /___/

        )EOF");
        printf(R"EOF(Stations:
        > Alcantra-Terra       > Castanheira-do-Ribatejo     > Queluz
        > Algueirao            > Chelas                      > Reboleira
        > Alhandra             > Entrecampos                 > Rio-de-Mouro
        > Alverca              > Espadanal-da-Azambuja       > Roma-Areeiro
        > Amadora              > Marvila                     > Rossio
        > Amadora              > Massama                     > Sacavem
        > Azambuja             > Merces                      > Santa-Apolonia
        > Benfica              > Mira-Sintra                 > Santa-Iria
        > Bobadela             > Monte-Abra�o                > Sete-Rios
        > Braco-de-Prata       > Moscavide                   > Sintra
        > Cacem                > Oriente                     > Sta.Cruz
        > Campolide            > Portela                     > Vila-Franca-de-Xira
        > Carregado            > Povoa                       > Vila-Nova-da-Rainha

                            Type here the station you're in:
                                > )EOF");
        //gotoxy(47,16);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

            ___                        __            _                                    _____ _       __
           /   |____  ____ _____ ___  / /_  __  __  (_)___ _   ____  ____ __________ _   / ___/(_)___  / /__________ _
          / /| /_  / / __ `/ __ `__ \/ __ \/ / / / / / __ `/  / __ \/ __ `/ ___/ __ `/   \__ \/ / __ \/ __/ ___/ __ `/
         / ___ |/ /_/ /_/ / / / / / / /_/ / /_/ / / / /_/ /  / /_/ / /_/ / /  / /_/ /   ___/ / / / / / /_/ /  / /_/ /
        /_/  |_/___/\__,_/_/ /_/ /_/_.___/\__,_/_/ /\__,_/  / .___/\__,_/_/   \__,_/   /____/_/_/ /_/\__/_/   \__,_/
                                              /___/        /_/


                            Type here when you want to catch the train:
                            Format Hours:Minutes:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Alcantra-Terra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alcantra-Terra/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Algueirao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Algueirao/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Alhandra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alhandra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Alverca")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alverca/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Amadora")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Amadora/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Benfica")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Benfica/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Bobadela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Bobadela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Braco-de-Prata")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Braco-de-Prata/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Cacem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Cacem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Carregado")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Carregado/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Castanheira-do-Ribatejo")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Castanheira-do-Ribatejo/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Chelas")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Chelas/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Espadanal-da-Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Espadanal-da-Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Marvila")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Marvila/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Massama")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Massama/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Merces")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Merces/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Mira-Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Mira-Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Monte-Abraao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Monte-Abraao/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Moscavide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Moscavide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Oriente")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Oriente/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Portela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Portela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Povoa")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Povoa/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Queluz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Queluz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Reboleira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Reboleira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rio-de-Mouro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rio-de-Mouro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rossio")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rossio/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sacavem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sacavem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Apolonia")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Apolonia/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Iria")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Iria/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sta.Cruz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sta.Cruz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Franca-de-Xira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Franca-de-Xira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Nova-da-Rainha")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Nova-da-Rainha/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    case 2:/*
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

       _____      __    __  __          __      __    _      __
      / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
      \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
     ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
    /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/

        )EOF");
        printf(R"EOF(Esta��es:
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Escreve a esta��o onde est�s:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela
        > Set�bal

                     )EOF");
        gotoxy(47,15);
        textcolor(LIGHTRED);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

                   _____      __    __  __          __      __    _      __
                  / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
                  \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
                 ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
                /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/





                            Escreve a que tempo � que queres apanhar o comboio.
                            Formato Horas:Minutos:

                                >

                     )EOF");

        gotoxy(35,15);
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Alcantra-Terra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alcantra-Terra/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Algueirao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Algueirao/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Alhandra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alhandra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Alverca")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Alverca/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Amadora")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Amadora/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Benfica")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Benfica/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Bobadela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Bobadela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Braco-de-Prata")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Braco-de-Prata/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Cacem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Cacem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Carregado")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Carregado/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Castanheira-do-Ribatejo")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Castanheira-do-Ribatejo/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Chelas")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Chelas/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Espadanal-da-Azambuja")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Espadanal-da-Azambuja/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Marvila")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Marvila/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Massama")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Massama/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Merces")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Merces/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Mira-Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Mira-Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Monte-Abraao")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Monte-Abraao/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Moscavide")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Moscavide/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Oriente")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Oriente/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Portela")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Portela/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Povoa")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Povoa/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Queluz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Queluz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Reboleira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Reboleira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rio-de-Mouro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rio-de-Mouro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Rossio")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Rossio/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sacavem")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sacavem/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Apolonia")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Apolonia/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Santa-Iria")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Santa-Iria/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sintra")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sintra/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Sta.Cruz")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Sta.Cruz/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Franca-de-Xira")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Franca-de-Xira/horas.txt";
            ct(hour, minutes, local);
        }
                else if(strcasecmp(estacao,"Vila-Nova-da-Rainha")==0)
        {
            char local[500] = "./Database/CP/Azambuja-Sintra/Vila-Nova-da-Rainha/horas.txt";
            ct(hour, minutes, local);
        }*/
        system("cls");
        printf(R"EOF(
    ____         ______                 __                  __  _
   /  _/___     / ____/___  ____  _____/ /________  _______/ /_(_)___  ____
   / // __ \   / /   / __ \/ __ \/ ___/ __/ ___/ / / / ___/ __/ / __ \/ __ \
 _/ // / / /  / /___/ /_/ / / / (__  ) /_/ /  / /_/ / /__/ /_/ / /_/ / / / /
/___/_/ /_/   \____/\____/_/ /_/____/\__/_/   \__,_/\___/\__/_/\____/_/ /_/
)EOF");
        getch();
        break;
    }
}


fertaguspt()
{
    int menu, a, i;
    char estacao[40];
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(
            ______          __
           / ____/__  _____/ /_____ _____ ___  _______
          / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/
         / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )
        /_/    \___/_/   \__/\__,_/\__, /\__,_/____/
                                  /____/

           Seleciona a Dire��o que queres viajar:

                1 - Lisboa para Set�bal
                2 - Set�bal para Lisboa

                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

        __    _      __                                             _____      __        __          __
       / /   (_)____/ /_  ____  ____ _   ____  ____ __________ _   / ___/___  / /___  __/ /_  ____ _/ /
      / /   / / ___/ __ \/ __ \/ __ `/  / __ \/ __ `/ ___/ __ `/   \__ \/ _ \/ __/ / / / __ \/ __ `/ /
     / /___/ (__  ) /_/ / /_/ / /_/ /  / /_/ / /_/ / /  / /_/ /   ___/ /  __/ /_/ /_/ / /_/ / /_/ / /
    /_____/_/____/_.___/\____/\__,_/  / .___/\__,_/_/   \__,_/   /____/\___/\__/\__,_/_.___/\__,_/_/
                                     /_/

        )EOF");
        printf(R"EOF(Esta��es:
        > Roma-Areeiro
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Escreve a esta��o onde est�s:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela

                     )EOF");
        gotoxy(47,15);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

        __    _      __                                             _____      __        __          __
       / /   (_)____/ /_  ____  ____ _   ____  ____ __________ _   / ___/___  / /___  __/ /_  ____ _/ /
      / /   / / ___/ __ \/ __ \/ __ `/  / __ \/ __ `/ ___/ __ `/   \__ \/ _ \/ __/ / / / __ \/ __ `/ /
     / /___/ (__  ) /_/ / /_/ / /_/ /  / /_/ / /_/ / /  / /_/ /   ___/ /  __/ /_/ /_/ / /_/ / /_/ / /
    /_____/_/____/_.___/\____/\__,_/  / .___/\__,_/_/   \__,_/   /____/\___/\__/\__,_/_.___/\__,_/_/
                                     /_/


                            Escreve a que tempo � que queres apanhar o comboio.
                            Formato Horas:Minutos:

                                > )EOF");

        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Roma-Areeiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Sete-Rios")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Sete-Rios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pragal")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Pragal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Corroios")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Corroios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Foros-de-Amora")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Foros-de-Amora/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Fogueteiro")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Fogueteiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Coina")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Coina/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Penalva")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Penalva/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pinhal-Novo")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Pinhal-Novo/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"V.Alcaide")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/V.Alcaide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Palmela")==0)
        {
            char local[500] = "./Database/Fertagus/Lisboa-Setubal/Palmela/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

       _____      __    __  __          __      __    _      __
      / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
      \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
     ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
    /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/

        )EOF");
        printf(R"EOF(Esta��es:
        > Entrecampos
        > Sete-Rios
        > Campolide
        > Pragal
        > Corroios                      Escreve a esta��o onde est�s:
        > Foros-de-Amora                    >
        > Fogueteiro
        > Coina
        > Penalva
        > Pinhal-Novo
        > V.Alcaide
        > Palmela
        > Set�bal

                     )EOF");
        gotoxy(47,15);
        scanf("%s",&estacao);
        system("cls");
        printf(R"EOF(

                   _____      __    __  __          __      __    _      __
                  / ___/___  / /___/_/_/ /_  ____ _/ /     / /   (_)____/ /_  ____  ____ _
                  \__ \/ _ \/ __/ / / / __ \/ __ `/ /     / /   / / ___/ __ \/ __ \/ __ `/
                 ___/ /  __/ /_/ /_/ / /_/ / /_/ / /  -  / /___/ (__  ) /_/ / /_/ / /_/ /
                /____/\___/\__/\__,_/_.___/\__,_/_/     /_____/_/____/_.___/\____/\__,_/





                            Escreve a que tempo � que queres apanhar o comboio.
                            Formato Horas:Minutos:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(strcasecmp(estacao,"Roma-Areeiro")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Setubal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Entrecampos")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Entrecampos/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Sete-Rios")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Sete-Rios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Campolide")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Campolide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pragal")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Pragal/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Corroios")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Corroios/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Foros-de-Amora")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Foros-de-Amora/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Fogueteiro")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Fogueteiro/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Coina")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Coina/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Penalva")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Penalva/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Pinhal-Novo")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Pinhal-Novo/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"V.Alcaide")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/V.Alcaide/horas.txt";
            ct(hour, minutes, local);
        }
        else if(strcasecmp(estacao,"Palmela")==0)
        {
            char local[500] = "./Database/Fertagus/Setubal-Lisboa/Palmela/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    }
}

#endif // TRAINS_H_INCLUDED
