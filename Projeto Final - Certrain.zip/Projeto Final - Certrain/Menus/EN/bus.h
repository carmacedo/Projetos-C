#ifndef BUS_H_INCLUDED
#define BUS_H_INCLUDED

bus()
{
    textcolor(LIGHTMAGENTA);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(
                                        ____  __  _______
                                       / __ )/ / / / ___/
                                      / __  / / / /\__ \
                                     / /_/ / /_/ /___/ /
                                    /_____/\____//____/


                       Select which company you want to travel with:

                        1 - TST - Transportes Sul do Tejo
                        2 - Sul Fertagus - Parte da Fertagus

                                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
        case 1:
            tsten();
            break;
        case 2:
            sulfertagusen();
            break;
    }
}

autocarros()
{
    textcolor(LIGHTMAGENTA);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                    ___         __
                   /   | __  __/ /_____  _________ _______________  _____
                  / /| |/ / / / __/ __ \/ ___/ __ `/ ___/ ___/ __ \/ ___/
                 / ___ / /_/ / /_/ /_/ / /__/ /_/ / /  / /  / /_/ (__  )
                /_/  |_\__,_/\__/\____/\___/\__,_/_/  /_/   \____/____/



                        Seleciona a empresa com que queres viajar:

                            1 - TST - Transportes Sul do Tejo
                            2 - Sul Fertagus - Parte da Fertagus

                                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
        case 1:
            tstpt();
            break;
        case 2:
            sulfertaguspt();
            break;
    }
}

sulfertaguspt()
{
    int menu, a, i;
    int estacao;
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

               _____       __   ______          __
              / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______
              \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/
             ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )
            /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/
                                                      /____/



                    Seleciona o autocarro em que queres viajar:
                            (Mais autocarros em breve)

                                    1 - 1F
                                    2 - 2F

                                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

           _____       __   ______          __                                     _________
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            <  / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    / / /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / / __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /_/_/
                                                  /____/

                            Seleciona o sentido em que queres viajar:
                (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                        1 - Esta��o do Fogueteiro - Mercado
                        2 - Mercado - Esta��o do Fogueteiro

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

           _____       __   ______          __                                     _________
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            <  / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    / / /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / / __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /_/_/
                                                  /____/

                        Escreve a que horas queres apanhar o autocarro:
                        Formato Horas:Minutos:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/SulFertagus/1F/Fogueteiro-Mercado/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/SulFertagus/1F/Mercado-Fogueteiro/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

           _____       __   ______          __                                     ___   ______
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            |__ \ / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    __/ // /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / __// __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /____/_/
                                                  /____/

                        Seleciona o sentido em que queres viajar:
            (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                        1 - Esta��o do Fogueteiro - Bombeiros
                        2 - Bombeiros - Esta��o do Fogueteiro

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

           _____       __   ______          __                                     ___   ______
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            |__ \ / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    __/ // /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / __// __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /____/_/
                                                  /____/

                        Escreve a que horas queres apanhar o autocarro:
                        Formato Horas:Minutos:

                            > )EOF");
        scanf("%2d:%2d",&hour,&minutes);
        if(estacao==1)
        {
            char local[500] = "./Database/SulFertagus/2F/Fogueteiro-Bombeiros/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/SulFertagus/2F/Bombeiros-Fogueteiro/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        break;
    }
}

sulfertagusen()
{
    int menu, a, i;
    int estacao;
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

               _____       __   ______          __
              / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______
              \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/
             ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )
            /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/
                                                      /____/



                        Select which bus you want to travel in:
                            (More Buses Coming Soon)

                                    1 - 1F
                                    2 - 2F

                                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

           _____       __   ______          __                                     _________
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            <  / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    / / /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / / __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /_/_/
                                                  /____/

                            Select which line do you want to travel in:
                (The Times displayed are only of the first station in the line.)

                        1 - Fogueteiro Station - Mercado
                        2 - Mercado - Fogueteiro Station

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

           _____       __   ______          __                                     _________
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            <  / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    / / /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / / __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /_/_/
                                                  /____/

                            Type the time you want to departure
                            Format Hour:Minutes:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/SulFertagus/1F/Fogueteiro-Mercado/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/SulFertagus/1F/Mercado-Fogueteiro/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

           _____       __   ______          __                                     ___   ______
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            |__ \ / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    __/ // /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / __// __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /____/_/
                                                  /____/

                        Select which direction do you want to travel in:
            (The Times displayed are only of the first station in the line.)

                        1 - Fogueteiro Station - Bombeiros
                        2 - Bombeiros - Fogueteiro Station

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

           _____       __   ______          __                                     ___   ______
          / ___/__  __/ /  / ____/__  _____/ /_____ _____ ___  _______            |__ \ / ____/
          \__ \/ / / / /  / /_  / _ \/ ___/ __/ __ `/ __ `/ / / / ___/  ______    __/ // /_
         ___/ / /_/ / /  / __/ /  __/ /  / /_/ /_/ / /_/ / /_/ (__  )  /_____/   / __// __/
        /____/\__,_/_/  /_/    \___/_/   \__/\__,_/\__, /\__,_/____/            /____/_/
                                                  /____/

                        Type the time you want to departure
                        Format Hour:Minutes:

                            > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/SulFertagus/2F/Bombeiros-Fogueteiro/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/SulFertagus/2F/Fogueteiro-Bombeiros/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        break;
    }
}

tsten()
{
    int menu, a, i;
    int estacao;
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                                  _________________
                                 /_  __/ ___/_  __/
                                  / /  \__ \ / /
                                 / /  ___/ // /
                                /_/  /____//_/



                        Select which bus you want to travel in:
                            (More Buses Coming Soon)

                                    1 - 195
                                    2 - 197

                                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                      _________________            _______  ______
                     /_  __/ ___/_  __/           <  / __ \/ ____/
                      / /  \__ \ / /    ______    / / /_/ /___ \
                     / /  ___/ // /    /_____/   / /\__, /___/ /
                    /_/  /____//_/              /_//____/_____/


                    Select which line do you want to travel in:
            (The Times displayed are only of the first station in the line.)

                        1 - Pinhal Conde da Cunha - Seixal (TF)
                        2 - Seixal (TF) - Pinhal Conde da Cunha

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

                      _________________            _______  ______
                     /_  __/ ___/_  __/           <  / __ \/ ____/
                      / /  \__ \ / /    ______    / / /_/ /___ \
                     / /  ___/ // /    /_____/   / /\__, /___/ /
                    /_/  /____//_/              /_//____/_____/


                            Type the time you want to departure
                            Format Hour:Minutes:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TST/195/PinhalCondeCunha-SeixalTF/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TST/195/SeixalTF-PinhalCondeCunha/horas.txt";
            ct(hour, minutes, local);
            break;
        }

        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                      _________________            _______  _____
                     /_  __/ ___/_  __/           <  / __ \/__  /
                      / /  \__ \ / /    ______    / / /_/ /  / /
                     / /  ___/ // /    /_____/   / /\__, /  / /
                    /_/  /____//_/              /_//____/  /_/

                    Select which direction do you want to travel in:
            (The Times displayed are only of the first station in the line.)

                        1 - Pragal (Hospital) - Sobreda
                        2 - Sobreda - Pragal (Hospital)

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(
                      _________________            _______  _____
                     /_  __/ ___/_  __/           <  / __ \/__  /
                      / /  \__ \ / /    ______    / / /_/ /  / /
                     / /  ___/ // /    /_____/   / /\__, /  / /
                    /_/  /____//_/              /_//____/  /_/


                        Type the time you want to departure
                        Format Hour:Minutes:

                            > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TST/197/PragalHOSP-Sobreda/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TST/197/Sobreda-PragalHOSP/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        break;
    }
}


tstpt()
{
    int menu, a, i;
    int estacao;
    int hour, minutes;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                                  _________________
                                 /_  __/ ___/_  __/
                                  / /  \__ \ / /
                                 / /  ___/ // /
                                /_/  /____//_/



                    Seleciona o autocarro em que queres viajar:
                            (Mais Autocarros Em Breve)

                                    1 - 195
                                    2 - 197

                                    > )EOF");

    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                      _________________            _______  ______
                     /_  __/ ___/_  __/           <  / __ \/ ____/
                      / /  \__ \ / /    ______    / / /_/ /___ \
                     / /  ___/ // /    /_____/   / /\__, /___/ /
                    /_/  /____//_/              /_//____/_____/


                    Seleciona qual � o sentido em que queres viajar:
        (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                        1 - Pinhal Conde da Cunha - Seixal (TF)
                        2 - Seixal (TF) - Pinhal Conde da Cunha

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

                      _________________            _______  ______
                     /_  __/ ___/_  __/           <  / __ \/ ____/
                      / /  \__ \ / /    ______    / / /_/ /___ \
                     / /  ___/ // /    /_____/   / /\__, /___/ /
                    /_/  /____//_/              /_//____/_____/


                    Escreve a que horas queres apanhar o autocarro:
                    Formato Horas:Minutos:

                        > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TST/195/PinhalCondeCunha-SeixalTF/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TST/195/PinhalCondeCunha-SeixalTF/horas.txt";
            ctp(hour, minutes, local);
            break;
        }

        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                      _________________            _______  _____
                     /_  __/ ___/_  __/           <  / __ \/__  /
                      / /  \__ \ / /    ______    / / /_/ /  / /
                     / /  ___/ // /    /_____/   / /\__, /  / /
                    /_/  /____//_/              /_//____/  /_/

                    Seleciona qual � o sentido em que queres viajar:
            (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                        1 - Pragal (Hospital) - Sobreda
                        2 - Sobreda - Pragal (Hospital)

                            > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(


                      _________________            _______  _____
                     /_  __/ ___/_  __/           <  / __ \/__  /
                      / /  \__ \ / /    ______    / / /_/ /  / /
                     / /  ___/ // /    /_____/   / /\__, /  / /
                    /_/  /____//_/              /_//____/  /_/



                        Escreve a que horas queres apanhar o autocarro:
                        Formato Horas:Minutos:

                            > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TST/197/PragalHOSP-Sobreda/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TST/197/Sobreda-PragalHOSP/horas.txt";
            ctp(hour, minutes, local);
            break;
        }

        break;
    }

}

#endif // BUS_H_INCLUDED
