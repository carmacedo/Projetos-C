#ifndef BOAT_H_INCLUDED
#define BOAT_H_INCLUDED

boat()
{
    textcolor(LIGHTGREEN);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                                ____  ____  ___  ___________
                               / __ )/ __ \/   |/_  __/ ___/
                              / __  / / / / /| | / /  \__ \
                             / /_/ / /_/ / ___ |/ /  ___/ /
                            /_____/\____/_/  |_/_/  /____/


                       Select which company you want to travel with:

                            1 - TTSL - Transtejo Softlusa
                            2 - Atlantic Ferries

                                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
        case 1:
            ttsl();
            break;
        case 2:
            af();
            break;
    }
}

barcos()
{
    textcolor(LIGHTGREEN);
    int menu;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                               ____
                              / __ )____ _______________  _____
                             / __  / __ `/ ___/ ___/ __ \/ ___/
                            / /_/ / /_/ / /  / /__/ /_/ (__  )
                           /_____/\__,_/_/   \___/\____/____/


                        Seleciona a empresa com que queres viajar:

                            1 - TTSL - Transtejo Softlusa
                            2 - Atlantic Ferries

                                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
        case 1:
            ttslpt();
            break;
        case 2:
            afpt();
            break;
    }
}

ttslpt()
{
    int menu, a, i;
    int estacao;
    int hour=0, minutes=0;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                              _________________ __
                             /_  __/_  __/ ___// /
                              / /   / /  \__ \/ /
                             / /   / /  ___/ / /___
                            /_/   /_/  /____/_____/


                    Seleciona o barco em que queres viajar:
                            (Mais barcos em breve)

                                1 - Montijo
                                2 - Seixal

                                > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

              _________________ __                __  ___            __  _   _
             /_  __/_  __/ ___// /               /  |/  /___  ____  / /_(_) (_)___
              / /   / /  \__ \/ /      ______   / /|_/ / __ \/ __ \/ __/ / / / __ \
             / /   / /  ___/ / /___   /_____/  / /  / / /_/ / / / / /_/ / / / /_/ /
            /_/   /_/  /____/_____/           /_/  /_/\____/_/ /_/\__/_/_/ /\____/
                                                                      /___/

                        Seleciona o sentido em que queres viajar:
            (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                                1 - Cais do Sodr� - Montijo
                                2 - Montijo - Cais do Sodr�

                                    > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

              _________________ __                __  ___            __  _   _
             /_  __/_  __/ ___// /               /  |/  /___  ____  / /_(_) (_)___
              / /   / /  \__ \/ /      ______   / /|_/ / __ \/ __ \/ __/ / / / __ \
             / /   / /  ___/ / /___   /_____/  / /  / / /_/ / / / / /_/ / / / /_/ /
            /_/   /_/  /____/_____/           /_/  /_/\____/_/ /_/\__/_/_/ /\____/
                                                                      /___/

                        Escreve a que horas queres apanhar o barco:
                        Formato Horas:Minutos

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TTSL/Montijo/CaisdoSodre-Monitjo/horas.txt";
            ctp(hour, minutes, local);
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TTSL/Montijo/Montijo-CaisdoSodre/horas.txt";
            ctp(hour, minutes, local);
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                    _________________ __                _____      _            __
                   /_  __/_  __/ ___// /               / ___/___  (_)  ______ _/ /
                    / /   / /  \__ \/ /      ______    \__ \/ _ \/ / |/_/ __ `/ /
                   / /   / /  ___/ / /___   /_____/   ___/ /  __/ />  </ /_/ / /
                  /_/   /_/  /____/_____/            /____/\___/_/_/|_|\__,_/_/


                            Seleciona o sentido em que queres viajar:
                (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                                1 - Cais do Sodr� - Seixal
                                2 - Seixal - Cais do Sodr�

                                    > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

                    _________________ __                _____      _            __
                   /_  __/_  __/ ___// /               / ___/___  (_)  ______ _/ /
                    / /   / /  \__ \/ /      ______    \__ \/ _ \/ / |/_/ __ `/ /
                   / /   / /  ___/ / /___   /_____/   ___/ /  __/ />  </ /_/ / /
                  /_/   /_/  /____/_____/            /____/\___/_/_/|_|\__,_/_/


                            Escreve a que horas queres apanhar o barco:
                            Formato Horas:Minutos

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);
        if(estacao==1)
        {
            char local[500] = "./Database/TTSL/Seixal/CaisdoSodre-Seixal/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TTSL/Seixal/Seixal-CaisdoSodre/horas.txt";
            ctp(hour, minutes, local);
            break;
        }
        break;
    }
}

ttsl()
{
    int menu, a, i;
    int estacao;
    int hour=0, minutes=0;
    clrscr();
    gotoxy(1,1);
    printf(R"EOF(

                              _________________ __
                             /_  __/_  __/ ___// /
                              / /   / /  \__ \/ /
                             / /   / /  ___/ / /___
                            /_/   /_/  /____/_____/


                    Select which boat you want to travel in:
                            (More boats coming soon)

                                1 - Montijo
                                2 - Seixal

                                    > )EOF");
    scanf("%i",&menu);
    switch(menu)
    {
    case 1:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                  _________________ __                __  ___            __  _   _
                 /_  __/_  __/ ___// /               /  |/  /___  ____  / /_(_) (_)___
                  / /   / /  \__ \/ /      ______   / /|_/ / __ \/ __ \/ __/ / / / __ \
                 / /   / /  ___/ / /___   /_____/  / /  / / /_/ / / / / /_/ / / / /_/ /
                /_/   /_/  /____/_____/           /_/  /_/\____/_/ /_/\__/_/_/ /\____/
                                                                          /___/

                            Select which direction do you want to go:
                  (The Times displayed are only of the first station in the line.)

                                    1 - Cais do Sodr� - Montijo
                                    2 - Montijo - Cais do Sodr�

                                        > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

                  _________________ __                __  ___            __  _   _
                 /_  __/_  __/ ___// /               /  |/  /___  ____  / /_(_) (_)___
                  / /   / /  \__ \/ /      ______   / /|_/ / __ \/ __ \/ __/ / / / __ \
                 / /   / /  ___/ / /___   /_____/  / /  / / /_/ / / / / /_/ / / / /_/ /
                /_/   /_/  /____/_____/           /_/  /_/\____/_/ /_/\__/_/_/ /\____/
                                                                          /___/

                            Type the time you want to departure
                            Format Hour:Minutes:

                                    > )EOF");
        scanf("%2d:%2d",&hour,&minutes);

        if(estacao==1)
        {
            char local[500] = "./Database/TTSL/Montijo/CaisdoSodre-Monitjo/horas.txt";
            ct(hour, minutes, local);
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TTSL/Montijo/Montijo-CaisdoSodre/horas.txt";
            ct(hour, minutes, local);
        }
        break;
    case 2:
        system("cls");
        gotoxy(1,1);
        printf(R"EOF(

                    _________________ __                _____      _            __
                   /_  __/_  __/ ___// /               / ___/___  (_)  ______ _/ /
                    / /   / /  \__ \/ /      ______    \__ \/ _ \/ / |/_/ __ `/ /
                   / /   / /  ___/ / /___   /_____/   ___/ /  __/ />  </ /_/ / /
                  /_/   /_/  /____/_____/            /____/\___/_/_/|_|\__,_/_/


                            Select which direction do you want to go:
                (The Times displayed are only of the first station in the line.)

                                    1 - Cais do Sodr� - Seixal
                                    2 - Seixal - Cais do Sodr�

                                        > )EOF");
        scanf("%i",&estacao);
        system("cls");
        printf(R"EOF(

                    _________________ __                _____      _            __
                   /_  __/_  __/ ___// /               / ___/___  (_)  ______ _/ /
                    / /   / /  \__ \/ /      ______    \__ \/ _ \/ / |/_/ __ `/ /
                   / /   / /  ___/ / /___   /_____/   ___/ /  __/ />  </ /_/ / /
                  /_/   /_/  /____/_____/            /____/\___/_/_/|_|\__,_/_/


                            Type the time you want to departure
                            Format Hour:Minutes:

                                > )EOF");
        scanf("%2d:%2d",&hour,&minutes);
        if(estacao==1)
        {
            char local[500] = "./Database/TTSL/Seixal/CaisdoSodre-Seixal/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        else if(estacao==2)
        {
            char local[500] = "./Database/TTSL/Seixal/Seixal-CaisdoSodre/horas.txt";
            ct(hour, minutes, local);
            break;
        }
        break;
    }
}

af()
{
    int a, i;
    int estacao;
    int hour=0, minutes=0;
    system("cls");
    gotoxy(1,1);
    printf(R"EOF(

            ___   __  __            __  _         ______               _
           /   | / /_/ /___ _____  / /_(_)____   / ____/__  __________(_)__  _____
          / /| |/ __/ / __ `/ __ \/ __/ / ___/  / /_  / _ \/ ___/ ___/ / _ \/ ___/
         / ___ / /_/ / /_/ / / / / /_/ / /__   / __/ /  __/ /  / /  / /  __(__  )
        /_/  |_\__/_/\__,_/_/ /_/\__/_/\___/  /_/    \___/_/  /_/  /_/\___/____/


                        Select which direction do you want to go:
              (The Times displayed are only of the first station in the line.)

                                1 - Set�bal - Troia
                                2 - Troia - Set�bal

                                    > )EOF");
    scanf("%i",&estacao);
    system("cls");
    printf(R"EOF(

            ___   __  __            __  _         ______               _
           /   | / /_/ /___ _____  / /_(_)____   / ____/__  __________(_)__  _____
          / /| |/ __/ / __ `/ __ \/ __/ / ___/  / /_  / _ \/ ___/ ___/ / _ \/ ___/
         / ___ / /_/ / /_/ / / / / /_/ / /__   / __/ /  __/ /  / /  / /  __(__  )
        /_/  |_\__/_/\__,_/_/ /_/\__/_/\___/  /_/    \___/_/  /_/  /_/\___/____/


                            Type the time you want to departure:
                            Format Hour:Minutes

                                > )EOF");
    scanf("%02d:%02d",&hour,&minutes);

    if(estacao==1)
    {
        char local[500] = "./Database/AtlanticF/Setubal-Troia/horas.txt";
        ctp(hour, minutes, local);
    }
    else if(estacao==2)
    {
        char local[500] = "./Database/AtlanticF/Troia-Setubal/horas.txt";
        ctp(hour, minutes, local);
        system("cls");
    }
}


afpt()
{
    int a, i;
    int estacao;
    int hour=0, minutes=0;
    system("cls");
    gotoxy(1,1);
    printf(R"EOF(

            ___   __  __            __  _         ______               _
           /   | / /_/ /___ _____  / /_(_)____   / ____/__  __________(_)__  _____
          / /| |/ __/ / __ `/ __ \/ __/ / ___/  / /_  / _ \/ ___/ ___/ / _ \/ ___/
         / ___ / /_/ / /_/ / / / / /_/ / /__   / __/ /  __/ /  / /  / /  __(__  )
        /_/  |_\__/_/\__,_/_/ /_/\__/_/\___/  /_/    \___/_/  /_/  /_/\___/____/


                        Seleciona o sentido em que queres viajar:
            (As horas que s�o mostradas no ecr� s�o da esta��o inicial do sentido)

                                1 - Set�bal - Troia
                                2 - Troia - Set�bal

                                    > )EOF");
    scanf("%i",&estacao);
    system("cls");
    printf(R"EOF(

            ___   __  __            __  _         ______               _
           /   | / /_/ /___ _____  / /_(_)____   / ____/__  __________(_)__  _____
          / /| |/ __/ / __ `/ __ \/ __/ / ___/  / /_  / _ \/ ___/ ___/ / _ \/ ___/
         / ___ / /_/ / /_/ / / / / /_/ / /__   / __/ /  __/ /  / /  / /  __(__  )
        /_/  |_\__/_/\__,_/_/ /_/\__/_/\___/  /_/    \___/_/  /_/  /_/\___/____/


                        Escreve a que horas queres apanhar o barco:
                        Formato Horas:Minutos

                                > )EOF");
    scanf("%02d:%02d",&hour,&minutes);

    if(estacao==1)
    {
        char local[500] = "./Database/AtlanticF/Setubal-Troia/horas.txt";
        ctp(hour, minutes, local);
    }
    else if(estacao==2)
    {
        char local[500] = "./Database/AtlanticF/Troia-Setubal/horas.txt";
        ctp(hour, minutes, local);
        system("cls");
    }
}

#endif // BOAT_H_INCLUDED
