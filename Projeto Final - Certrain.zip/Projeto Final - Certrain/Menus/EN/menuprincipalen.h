#ifndef MENUPRINCIPALEN_H_INCLUDED
#define MENUPRINCIPALEN_H_INCLUDED

menuprincipaleng()
{
    int menu;
    do
    {
        system("cls");
        textcolor(LIGHTCYAN);
        printf("\n\n          Select your method of transportation\n          (Type 5 to go back)\n\n\n");

        textcolor(LIGHTBLUE);
        printf("        |===================|");

        textcolor(LIGHTMAGENTA);
        printf("|===================|\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |         1         |");

        textcolor(LIGHTMAGENTA);
        printf("|         2         |\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |       Trains      |");

        textcolor(LIGHTMAGENTA);
        printf("|        Bus        |\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |===================|");

        textcolor(LIGHTMAGENTA);
        printf("|===================|\n");

        textcolor(LIGHTGREEN);
        printf("        |===================|");

        textcolor(LIGHTRED);
        printf("|===================|\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |         3         |");

        textcolor(LIGHTRED);
        printf("|         4         |\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |       Boats       |");

        textcolor(LIGHTRED);
        printf("|       Metro       |\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |===================|");

        textcolor(LIGHTRED);
        printf("|===================|\n");

        textcolor(LIGHTCYAN);
        gotoxy(27,22);
        printf("\n> ");
        scanf("%i",&menu);
        switch(menu)
        {
            case 1:
                trains();
                break;
            case 2:
                bus();
                break;
            case 3:
                boat();
                break;
            case 4:
                metroen();
                break;
            default:
                return;
                break;
        }
    }while(menu<5);
}

menuprincipalpt()
{
    int menu;
    do
    {
        system("cls");
        textcolor(LIGHTCYAN);
        printf("\n\n          Seleciona o Teu Metodo de Transporte \n          (Escreva 5 para voltar para tr�s):\n\n\n");

        textcolor(LIGHTBLUE);
        printf("        |===================|");

        textcolor(LIGHTMAGENTA);
        printf("|===================|\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |         1         |");

        textcolor(LIGHTMAGENTA);
        printf("|         2         |\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |      Comboios     |");

        textcolor(LIGHTMAGENTA);
        printf("|     Autocarros    |\n");

        textcolor(LIGHTBLUE);
        printf("        |                   |");

        textcolor(LIGHTMAGENTA);
        printf("|                   |\n");

        textcolor(LIGHTBLUE);
        printf("        |===================|");

        textcolor(LIGHTMAGENTA);
        printf("|===================|\n");

        textcolor(LIGHTGREEN);
        printf("        |===================|");

        textcolor(LIGHTRED);
        printf("|===================|\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |         3         |");

        textcolor(LIGHTRED);
        printf("|         4         |\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |       Barcos      |");

        textcolor(LIGHTRED);
        printf("|       Metros      |\n");

        textcolor(LIGHTGREEN);
        printf("        |                   |");

        textcolor(LIGHTRED);
        printf("|                   |\n");

        textcolor(LIGHTGREEN);
        printf("        |===================|");

        textcolor(LIGHTRED);
        printf("|===================|\n");

        textcolor(LIGHTCYAN);
        gotoxy(27,22);
        printf("\n> ");
        scanf("%i",&menu);
        switch(menu)
        {
            case 1:
                comboios();
                break;
            case 2:
                autocarros();
                break;
            case 3:
                barcos();
                break;
            case 4:
                metropt();
                break;
            default:
                break;
        }
    }while(menu<5);
}


#endif // MENUPRINCIPALEN_H_INCLUDED
