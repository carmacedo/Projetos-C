#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.c>
#include <conio.h>
#include <unistd.h>
#include <ctype.h>
#include <strings.h>
#include <locale.h>

// Includes de .h's

#include "Anima��es\Introdu��o\intro.h"
#include "Anima��es\Introdu��o\linguagem.h"
#include "Menus\EN\menuprincipalen.h"
#include "Menus\EN\trains.h"
#include "closest_time.h"
#include "Menus\EN\bus.h"
#include "Menus\EN\boat.h"
#include "Menus\EN\metro.h"

// 30 DE JUNHO ENTREGA


int msleep(unsigned int tms) {
    return usleep(tms * 1000);
}

void main()
{
    system("title Certrain - Daniel Escaleira 2221202 TGPSIN");
    setlocale(LC_ALL,"portuguese");
    intro();
    ling();
    return 0;
}
