#ifndef CLOSEST_TIME_H_INCLUDED
#define CLOSEST_TIME_H_INCLUDED

struct tempo{
    int horas, minutos;
};

ct(int hour, int minutes, char local[500])
{
    char str[7];
    int i=0,o=0, lines=0, b;
    FILE * fp;

    fp = fopen(local, "r+");

    while(EOF != fscanf(fp, "%s", &str)){
        lines=lines+1;
    }

    struct tempo temp[lines];

    fclose(fp);
    fp= fopen(local, "r+");

    while(EOF != fscanf(fp, "%2d:%2d", &temp[i].horas, &temp[i].minutos)){
        i++;
    }

    fclose(fp);
    fp = fopen(local, "r+");


    while(EOF != fscanf(fp, "%2d:%2d", &temp[o].horas, &temp[o].minutos)){
        if(hour <= temp[o].horas && minutes <= temp[o].minutos){
            system("cls");
            printf(R"EOF(


                                __  __
                               / / / /___  __  ____________
                              / /_/ / __ \/ / / / ___/ ___/
                             / __  / /_/ / /_/ / /  (__  )
                            /_/ /_/\____/\__,_/_/  /____/



                      )EOF");
            textcolor(LIGHTBLUE);
            printf("\n\n\n                                       %02d:%02d\n\n                               Press ", temp[o].horas,temp[o].minutos);
            textcolor(LIGHTRED);
            printf("ENTER");
            textcolor(LIGHTBLUE);
            printf(" to continue.\n\n\n\n                                                                                                 ");
            getch();
            system("cls");
            break;
        }
        o++;
    }
    fclose(fp);
    printf(R"EOF(
                __                    ___
               / /   ____  ____ _____/ (_)___  ____ _
              / /   / __ \/ __ `/ __  / / __ \/ __ `/
             / /___/ /_/ / /_/ / /_/ / / / / / /_/ /
            /_____/\____/\__,_/\__,_/_/_/ /_/\__, /
                                            /____/
)EOF");
    msleep(1000);
    printf("\n            Press ENTER to continue.");
}

ctp(int hour, int minutes, char local[500])
{
    char str[7];
    int i=0,o=0, lines=0, b;
    FILE * fp;

    fp = fopen(local, "r+");

    while(EOF != fscanf(fp, "%s", &str)){
        lines=lines+1;
    }

    struct tempo temp[lines];

    fclose(fp);
    fp= fopen(local, "r+");

    while(EOF != fscanf(fp, "%02d:%02d", &temp[i].horas, &temp[i].minutos)){
        i++;
    }

    fclose(fp);
    fp = fopen(local, "r+");

    while(EOF != fscanf(fp, "%02d:%02d", &temp[o].horas, &temp[o].minutos)){
        if(hour <= temp[o].horas && minutes <= temp[o].minutos){
            system("cls");
            printf(R"EOF(


                                __  __
                               / / / /___  _________ ______
                              / /_/ / __ \/ ___/ __ `/ ___/
                             / __  / /_/ / /  / /_/ (__  )
                            /_/ /_/\____/_/   \__,_/____/


                      )EOF");
            textcolor(LIGHTBLUE);
            printf("\n\n\n                                       %02d:%02d\n\n                               Press ", temp[o].horas,temp[o].minutos);
            textcolor(LIGHTRED);
            printf("ENTER");
            textcolor(LIGHTBLUE);
            printf(" to continue.\n\n\n                                                                                                 ");
            getch();
            system("cls");
            break;
        }
        o++;
    }
    fclose(fp);
    printf(R"EOF(
                __                    ___
               / /   ____  ____ _____/ (_)___  ____ _
              / /   / __ \/ __ `/ __  / / __ \/ __ `/
             / /___/ /_/ / /_/ / /_/ / / / / / /_/ /
            /_____/\____/\__,_/\__,_/_/_/ /_/\__, /
                                            /____/
)EOF");
    msleep(1000);
    printf("\n            Carrega no ENTER para continuar.");
}

#endif // CLOSEST_TIME_H_INCLUDED
