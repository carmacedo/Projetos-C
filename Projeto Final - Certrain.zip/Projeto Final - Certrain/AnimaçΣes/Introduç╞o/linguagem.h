#ifndef LINGUAGEM_H_INCLUDED
#define LINGUAGEM_H_INCLUDED

ling()
{
    int lang;
    do
    {
        clrscr();
        textcolor(LIGHTCYAN);
        gotoxy(2,2);
        printf(R"EOF(

           ___          _             _
          / __\___ _ __| |_ _ __ __ _(_)_ __
         / /  / _ \ '__| __| '__/ _` | | '_ \
        / /__|  __/ |  | |_| | | (_| | | | | |
        \____/\___|_|   \__|_|  \__,_|_|_| |_|

                 Select your language:
                   1 > Portuguese
                   2 > English

                          )EOF");

        scanf("%i",&lang);
        switch(lang)
        {
        case 1:
            system("cls");
            menuprincipalpt();
            break;
        case 2:
            system("cls");
            menuprincipaleng();
            break;
        default:
            system("cls");
            textcolor(LIGHTRED);
            gotoxy(20,7);
            printf("   Try Again\n                   Tente Novamente\n            Carregue no Enter para continuar.\n               Click Enter to continue.\n\n");
            gotoxy(27,13);
            getch();
            clrscr();
            break;
        }

    }while(lang);
}

#endif // LINGUAGEM_H_INCLUDED
