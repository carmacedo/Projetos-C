#include <stdio.h>      //biblioteca base que me permite utilizar as fun��es bases da linguagem C
#include <stdlib.h>     //biblioteca, tamb�m base, que me permite utilizar fun��es como o rand
#include <time.h>       //biblioteca que me permite utilizar fun��es de tempo
#include <conio.h>      //biblioteca que me permite utilizar fun��es como "getch();" entre outras
#include <conio.c>      // ==
#include <locale.h>     //biblioteca que me permite mudar o "charset" do meu programa, neste caso eu utilizo o portugu�s
#include <windows.h>    //biblioteca que me permite a manipula��o de janela cmd
#include <strings.h>    //biblioteca que me permite fun��es de strings (strcat / strcpy / etc)

#include <tgpsi1320.h>

#define FIELD_SIZE 25                                          //utilizo um define com o nome "FIELD_SIZE" com o atributo de tamanho (25) de maneira que no resto do programa n�o tenha de estar constantemente a ver qual � o tamanho certo
#define length(array) (sizeof(array)/sizeof(array)[i])         //utilizo um define com o nome "length(array)" para detetar quantos elementos existem

int blockcolor;         //vari�vel universal que permite a utiliza��o da mesma vari�vel numa fun��o e no main, sem ser apagada
int barcolor;           // ==
int writecolor;         // ==


struct highscores{      //estrutura que guarda os valores das pontua��es mais altas (highscores), utilizei-a para evitar redund�ncia de vari�veis
       int pos;         //vari�vel que guarda os valores das pontua��es mais altas (highscores / top10)
};


struct account{         //estrutura simples para definir os usernames e passwords
  char *id;             //char com o ponteiro de id
  char *password;       //char com o ponteiro de password
};                      //fecho a estrutura

static struct account accounts[]={         //anuncio a estrutura pr�via (account) como est�tica para definir as diferentes contas, desta forma consigo "guardar" as contas de uma maneira simples e organisada
  {"admin","admin"},                       //as diferentes contas, ("id","password" , correspondente)
  {"marco","marco"},                       // ==
  {"carla","stora"},                       // ==
  {"diogo","fucho"},                        // ==
  {"tomas","thadc"}
};                                         //termino a estrutura est�tica de contas

int is_authorized(const char *uid, const char *pwd)  //anuncio a fun��o "is_authorized" (� autorizado em portugu�s) para verificar que o nome de utilizador e password s�o autorizados, ou seja t�m contas correspondentes aos dados introduzidos
{
  int i;                                   //defino uma simples vari�vel "i", para depois utilizar no "for"

      for(i=0 ; i<length(accounts) ; i++)  //come�o o "for" onde o programa ir� verificar se a password e o nome de utilizador � correspondente aos dos dados na estrutura (est�tica) "accounts"
      {     
      if(stricmp(uid, accounts[i].id)==0 && strcmp(pwd, accounts[i].password)==0) //um simples "if" para, continuamente verificar se o nome de utilizador e password s�o correspondentes aos das contas
      {
       return 1;                        //se forem, o programa ir� continuar
       }
      }

  return 0;                            //acabo aqui a minha fun��o "is_authorized"
}                                      // ==

void get_password(char *pwd, int size) //anuncio a fun��o "get_password" (obter password em portugu�s) para que o programa obter a password sem mostrar os caracteres que est�o a ser introduzidos, assim v�-se em estrelas
{
  int i = 0;                                              //anuncio, de novo, uma vari�vel "i", j� com um valor de 0
  int ch;                                                 //anuncio uma vari�vel "ch"
  
  while(i<size-1 && (ch=getch())!='\r'){                  //utilizo uma fun��o "while" para que vai, continuamente, verificar se o que eu estou a escrever � maior de -1 (maior ou igual a 0)
    if(ch==127 || ch==8){                                 //utilizo uma fun��o "if" para que quando o utilizador apagar um caract�r...          -|
      if(i!=0){                                           //verifico, de novo com uma fun��o "if" se o numero de caract�res � diferente de 0     |
        printf("\b%c\b",' ');                                     //... aparecer um espa�o em branco, ou seja, apagar a estrela que estava l� antes    <-|
        --i;                                              //retiro um valor a i (o tamanho) pois apagou-se um caract�r
      }                                                   //fecho aqui o meu "if"                                 
    }                                                     //fecho aqui o meu segundo "if"
    else{                                                 //come�o uma alternativa ("else") para o "if" anterior                     
      putchar('*');                                       //quando introduzimos um caract�r, em vez do pr�prio caracter, desta maneira d� um aspeto mais seguro ao utilizador   
      pwd[i++]=(char)ch;                                  
    }                                                     //fecho aqui a minha alternativa ("else"^) do "if"
  }                                                       //fecho aqui o "while"

  pwd[i]='\0';                                            
}                                                         //fecho aqui a fun��o "get_password"




int main(){                          //come�o aqui o meu main, onde maioria do meu programa ir� estar
    
    setlocale(LC_ALL, "portuguese");       //utilizo a fun��o de "setlocale" (da biblioteca locale.h) para mudar o charset do meu programa para portugu�s
       
    struct highscores h[10];               //anuncio que a minha estrutura (pr�viamente criada para guardar os highscores) vai ter 10 valores, as 10 melhores pontua��es
       
       
       
    int i;                          //vari�vel utilizada para a fun��o de "for" para o jogo
    int select;                     //vari�vel utilizada para mostrar a escolha atual no menu principal
    int opcescolhai;                //vari�vel utilizada para mostrar a escolha atual no menu de op��es principais
    int opccoresescolhai;           //vari�vel utilizada para mostrar a escolha atual no menu de cores (do menu de op��es)
    int opccoresjogoescolhai;       //vari�vel utilizada para mostrar a escolha atual no menu de cores de jogo(no menu de op��es)
    int pcresetescolhai;            //vari�vel utilizada para mostrar a escolha atual no menu de "reset highscores", no menu de op��es
    
    int rnd;                        //vari�vel utilizada no jogo para gerar campos randoms , ou seja diferentes
    char choice[50000];             //vari�vel para ler a tecla pressionada pelo jogador/utilizador quando est� a jogar
    char menuescolha;               //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu
    char opcescolha;                //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu de op��es
    char opccoresescolha;           //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu de cores (no menu de op��es)
    char opccoresjogoescolha;       //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu de cores do jogo (no menu de op��es)
    char corblocoescolha;           //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu da cor do bloco (no menu de cores do jogo, no menu de op��es)
    char corbarescolha;             //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu da cor da barra (no menu de cores do jogo, no menu de op��es)
    char cortextoescolha;           //vari�vel utilizada para ler a op��o escolhida pelo utilizador no menu de cor de texto
    char pcresetescolha;            //vari�vel utilizada para ler a op��o escolhida pelo utilizador na escolha de limpar (ou n�o) as pontua��es de jogo
    char updwn;                     //vari�vel utilizada para ler qual das teclas o utilizador est� pressionar para mexer de uma op��o para a outra
    int score;                      //vari�vel utilizada para ler e posteriormente mostrar ao utilizador qual a pontua��o obtida no jogo
    int j;                          //vari�vel utilizada para a fun��o de "for" para que, por defeito atribuir os valores de highscores como 0
    int ha;                         //vari�vel utilizada para a fun��o de "for" para que na p�gina dos highscores escrever as pontua��es mais altas
    int ll;                         //vari�vel utilizada para a cria��o de novos dados de pontua��es no for
    int jj;                         //vari�vel utilizada para a cria��o de novos dados de pontua��es no for
    char uid[FIELD_SIZE];           //vari�vel utilizada para a autentica��o de login, username (uid = user id), com o tamanho que foi defenido anteriormente no "define FIELD_SIZE 25"
    char pwd[6];                    //vari�vel utilizada para a autentica��o de login, password (pwd = password), com o tamanho de 6 caracteres, 5 efetivos 
    FILE *hsc;                      //ficheiro de highscores (10 melhores pontua��es obtidas)
       
    
    barcolor=8;                     //atribu� um valor inicial para as cores do programa, se n�o fizesse isto todas as cores estariam, por defeito, em 0, ou seja preta
    blockcolor=15;                  // ==
    writecolor=15;                  // ==
       
       
      
      
    do{                             //come�o aqui o "do ... while" que irei definir no final do programa
    select=0;                  //defino a escolha do menu como 0, para n�o interferir com o while
    system("cls");                  //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
    loginm();                       //chamo a fun��o "loginm()" (login menu) da minha biblioteca ("tgpsi1320.h") para mostrar as letras, em grande, "LOGIN"

    printf("\n\t\t\tID de utilizador: ");   //uso um printf para "pedir" ao utilizador o seu id de utilizador
    fflush(stdout);                         //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
    fflush(stdin);                          //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa

    if(fgets(uid, sizeof uid, stdin)!=NULL){          //utilizo uma fun��o "if" para verificar se o tamanho atual � diferente de 0 (NULL)
                  char *newline=strchr(uid,'\n');     //utilizo uma fun��o "strchr" para 'procurar' pela string no programa, neste caso, estou � espera que o utilizador carregue no ENTER
                  if(newline!=NULL)                   //se o utilizador carregar ENTER, ent�o isto indica que j� acabou de escrever o nome de utilizador
                  {
                                   *newline = '\0';                     //redefino o ponteiro da vari�vel "newline" como 0
                                   printf("\n\t\t\tPassword: ");        //utilizo um printf para "pedir" ao utilizador a sua password
                                   fflush(stdout);                      //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa                      
                                   fflush(stdin);                       //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa

                                   get_password(pwd, sizeof pwd);       //chamo a fun��o de verifica��o de password
                                   system("cls");                       //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                   if(is_authorized(uid, pwd))          //verifico ent�o (com uma fun��o "if") se os dados que foram introduzidos correspondem a alguma conta
                                   {
                                                         printf("\n\n\n\n\t\t\t\tBEMVINDO, %s!\n",strupr(uid));   //se sim, ent�o esta mensagem "BEMVINDO , <nomedeutilizador>" ir� aparecer a indicar que a autentica��o de utilizador for executada com sucesso, utilizo tamb�m uma fun��o "strupr" para que o nome do utilizador apare�a em letras maiusculas
                                                         getch();                                                 //utilizo a fun��o "getch()" para fazer uma pausa no meu programa                     
                                   }
                                   else{
                                                         printf("\n\n\n\n\t\t\t\tUTILIZADOR INV�LIDO!\n");        //se n�o, a mensagem "UTILIZADOR INV�LIDO" ir� aparecer para mostrar ao utilizador que os seus dados est�o incorretos, ou n�o existem
                                                         getch();                                                 //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                         exit(1);                                                 //utilizo a fun��o "exit(1)" para que, quando esta condi��o n�o se verificar (is_authorized) o programa terminar
                                   }                     //fecho aqui a  minha alternativa (else) de verifica��o de dados
                  }                //termino aqui o "if" pr�viamente come�ado, de verifica��o de linhas novas (ENTER)
    }             //acabo aqui o "if" pr�viamente come�ado, para verificar se os caracteres n�o s�o nulos (NULL)
  
      
       
    while(select!=4 && select!=3){          //utilizo uma fun��o "while" para que, enquanto o utilizador n�o selecionar a op��o de sair, o programa continuar a correr (da� ter utilizado uma condi��o constante), ou se escolher 4 (MUDAR DE UTILIZADOR) voltar para o ecr� de login
                    
       score=0;                        //atribui-o o valor de score (pontua��o) como 0, para que cada vez que o utilizador perde a sua pontua��o ser posta a 0 de novo
       i=0;                            //atribui-o o valor de i (a vari�vel utilizada para o jogo) como 0 para que, se o utilizador jogar muitas vezes o jogo n�o parar de correr
       
       textcolor(writecolor);          //atribui-o o valor da cor de texto (a qual pode ser mudificada no menu de op��es) para a que o utilizador escolheu, sendo a "default" branca(15)
       textbackground(0);              //atribui-o o valor da cor de fundo do programa como preto(0), como uma forma de dar "reset" �s cores
       
       fflush(stdin);                  //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
       fflush(stdout);                 //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                           
       
       system("cls");                  //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
    
       
       
       
       select=0;                       //defino a escolha do menu como 0, para n�o interferir com o while
       do{                                                                              //come�o aqui o "do ... while" que irei definir para que o switch (dentro da mesma) n�o pare at� o utilizador carregar ENTER
           
           switch(select)                                                               //crio a switch da vari�vel select, qual defeni, por defeito, como 0, desta forma come�a no primeiro case, ou seja na primeira op��o
           {
                         case 0:                                                        //come�o aqui o meu primeiro "case" da switch da vari�vel "select", este correspondente � primeira op��o, "JOGAR!"
                              system("cls");                                            //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                              menu();                                                   //chamo aqui a fun��o "menu" (a qual eu criei no meu header "tgpsi1320.h")
                              
                              textbackground(15);                                       //defino ent�o a cor de fundo do meu texto como branco (15)...
                              textcolor(0);                                             //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                              printf("\t\t\t\t\tJOGAR!\t\t\t\t\t\n");                   //anuncio a primeira op��o que o utilizador pode escolher
                              textbackground(0);                                        //defino depois a cor de fundo do meu texto como preto, de volta ao "default"
                              textcolor(writecolor);                                    //defino depois a cor de texto de volta � cor que o utilizador seleciona
                              printf("\t\t\t\t      HIGHSCORES\n\n");                   //anuncio as restantes op��es
                              printf("\t\t\t\t\tOP��ES\n\n");                           // ==
                              printf("\t\t\t\t MUDAR DE UTILIZADOR\n\n");               // ==
                              printf("\t\t\t\t\tSAIR\n\n");                             //enquanto o utilizador n�o escolher esta op��o, o programa n�o fecha
                              printf("\n\n\nCONTA ATUAL: %s",strupr(uid));              //utilizo um printf para mostrar qual a que est� uso no momento, utilizando tamb�m uma fun��o "strupr()" para mostar o meu texto da vari�vel em letras mai�sculas
                              
                              break;                                                    //fecho aqui o meu primeiro "case" da switch da vari�vel "select"
                         case 1:                                                        //come�o aqui o meu segundo "case" da switch da vari�vel "select", este correspondente � segunda op��o "HIGHSCORES"
                              system("cls");                                            //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes     
                              menu();                                                   //chamo aqui a fun��o "menu" (a qual eu criei no meu header "tgpsi1320.h")
                              
                              textbackground(0);                                        //defino a cor de fundo como a "default", preto
                              textcolor(writecolor);                                    //defino a cor de texto como a selecionada pelo utilizador
                              printf("\t\t\t\t\tJOGAR!\n\n");                           //anuncio a primeira op��o, n�o selecionada , de momento
                              textbackground(15);                                       //defino ent�o a cor de fundo do meu texto como branco (15)...
                              textcolor(0);                                             //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                              printf("\t\t\t\t      HIGHSCORES\t\t\t\t\n");             //anuncio a segunda op��o que o utilizador pode escolher, a qual est� de momento selecionada
                              textbackground(0);                                        //defino depois a cor de fundo do meu texto como preto, de volta ao "default" 
                              textcolor(writecolor);                                    //defino depois a cor de texto de volta � cor que o utilizador seleciona
                              printf("\t\t\t\t\tOP��ES\n\n");                           //anuncio as restantes op��es
                              printf("\t\t\t\t MUDAR DE UTILIZADOR\n\n");               // ==
                              printf("\t\t\t\t\tSAIR\n\n");                             //enquanto o utilizador n�o escolher esta op��o, o programa n�o fecha
                              printf("\n\n\nCONTA ATUAL: %s",strupr(uid));              //utilizo um printf para mostrar qual a que est� uso no momento, utilizando tamb�m uma fun��o "strupr()" para mostar o meu texto da vari�vel em letras mai�sculas
                              
                              break;                                                    //fecho aqui o meu segundo "case" da switch da vari�vel "select"
                         case 2:                                                        //come�o aqui o meu terceiro "case" da switch da vari�vel "select", este correspondente � terceira op��o "OP��ES"
                              system("cls");                                            //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                              menu();                                                   //chamo aqui a fun��o "menu" (a qual eu criei no meu header "tgpsi1320.h")
                              
                              textbackground(0);                                        //defino a cor de fundo como a "default", preto
                              textcolor(writecolor);                                    //defino a cor de texto como a selecionada pelo utilizador
                              printf("\t\t\t\t\tJOGAR!\n\n");                           //anuncio aqui as diferentes op��es para o utilizador escolher
                              printf("\t\t\t\t      HIGHSCORES\n\n");                   // ==
                              textbackground(15);                                       //defino ent�o a cor de fundo do meu texto como branco (15)...
                              textcolor(0);                                             //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                              printf("\t\t\t\t\tOP��ES\t\t\t\t\t\n");                   //anuncio a mihna terceira op��o, correspondente ao menu de op��es
                              textbackground(0);                                        //defino depois a cor de fundo do meu texto como preto, de volta ao "default" 
                              textcolor(writecolor);                                    //defino depois a cor de texto de volta � cor que o utilizador seleciona
                              printf("\t\t\t\t MUDAR DE UTILIZADOR\n\n");               //anuncio as restantes op��es
                              printf("\t\t\t\t\tSAIR\n\n");                             //enquanto o utilizador n�o escolher esta op��o, o programa n�o fecha
                              printf("\n\n\nCONTA ATUAL: %s",strupr(uid));              //utilizo um printf para mostrar qual a que est� uso no momento, utilizando tamb�m uma fun��o "strupr()" para mostar o meu texto da vari�vel em letras mai�sculas
                              
                              break;                                                    //fecho aqui o meu segundo "case" da switch da vari�vel "select"
                         case 3:                                                        //come�o aqui o meu quarto "case" da switch da vari�vel "select", este correspondente � terceira op��o "MUDAR DE UTILIZADOR"
                              system("cls");                                            //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                              menu();                                                   //chamo aqui a fun��o "menu" (a qual eu criei no meu header "tgpsi1320.h")
                              
                              textbackground(0);                                        //defino a cor de fundo como a "default", preto
                              textcolor(writecolor);                                    //defino a cor de texto como a selecionada pelo utilizador
                              printf("\t\t\t\t\tJOGAR!\n\n");                           //anuncio aqui as diferentes op��es para o utilizador escolher
                              printf("\t\t\t\t      HIGHSCORES\n\n");                   // ==
                              printf("\t\t\t\t\tOP��ES\n\n");                           // ==
                              textbackground(15);                                       //defino ent�o a cor de fundo do meu texto como branco (15)...
                              textcolor(0);                                             //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                              printf("\t\t\t\t MUDAR DE UTILIZADOR\t\t\t\t\n");         //anuncio a mihna terceira op��o, correspondente � mudan�a de utilizador
                              textbackground(0);                                        //defino depois a cor de fundo do meu texto como preto, de volta ao "default" 
                              textcolor(writecolor);                                    //defino depois a cor de texto de volta � cor que o utilizador seleciona
                              printf("\t\t\t\t\tSAIR\n\n");                             //enquanto o utilizador n�o escolher esta op��o, o programa n�o fecha
                              printf("\n\n\nCONTA ATUAL: %s",strupr(uid));              //utilizo um printf para mostrar qual a que est� uso no momento, utilizando tamb�m uma fun��o "strupr()" para mostar o meu texto da vari�vel em letras mai�sculas
                              
                              break;                                                    //fecho aqui o meu quarto "case" da switch da vari�vel "select"
                         case 4:                                                        //come�o aqui o meu quinto "case" da switch da vari�vel "select", este correspondente � terceira op��o "SAIR"
                              system("cls");                                            //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                              menu();                                                   //chamo aqui a fun��o "menu" (a qual eu criei no meu header "tgpsi1320.h")
                              
                              textbackground(0);                                        //defino a cor de fundo como a "default", preto
                              textcolor(writecolor);                                    //defino a cor de texto como a selecionada pelo utilizador
                              printf("\t\t\t\t\tJOGAR!\n\n");                           //anuncio aqui as diferentes op��es para o utilizador escolher
                              printf("\t\t\t\t      HIGHSCORES\n\n");                   // ==
                              printf("\t\t\t\t\tOP��ES\n\n");                           // ==
                              printf("\t\t\t\t MUDAR DE UTILIZADOR\n\n");               // ==
                              textbackground(15);                                       //defino ent�o a cor de fundo do meu texto como branco (15)...
                              textcolor(0);                                             //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                              printf("\t\t\t\t\tSAIR\t\t\t\t\t\n");                     //enquanto o utilizador n�o escolher esta op��o, o programa n�o fecha
                              textbackground(0);                                        //defino depois a cor de fundo do meu texto como preto, de volta ao "default" 
                              textcolor(writecolor);                                    //defino depois a cor de texto de volta � cor que o utilizador seleciona
                              printf("\n\n\nCONTA ATUAL: %s",strupr(uid));              //utilizo um printf para mostrar qual a que est� uso no momento, utilizando tamb�m uma fun��o "strupr()" para mostar o meu texto da vari�vel em letras mai�sculas
                              
                              break;                                                    //fecho aqui o meu quinto "case" da switch da vari�vel "select"
           }
           updwn=getch();                                         //utilizo um getch() para obter a tecla pressionada pelo utilizador
           
           if(updwn=='a' && select<4)                             //se a tecla for correspondente ao 'a' e se o select (de inicio definido como 0) for menor que 4...
           {
                         select++;                                //ir� adicionar um valor � vari�vel "select" de maneira a mostrar as diferentes op��es como selecionadas
           }
           else if(updwn=='q' && select>0)                        //se a tecla for correspondente ao 'q' e se o select (de inicio definido como 0) for maior que 0...
           {
                         select--;                                //ir� retirar um valor � vari�vel "select" de maneira a mostrar as diferentes op��es como selecionadas
           }
           
       fflush(stdin);                                             //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
       }while(updwn!=13);                                         //defino ent�o, por fim, o while que come�ei no inicio deste menu, e com a condi��o de, desde que o utilizador n�o pressione ENTER o menu mant�m-seb 
           
       
       
      
       switch(select)              //utilizo uma fun��o "switch()" para que o programa abra as diferentes escolhas do utilizador
       { 
       
       case 0:                        //o meu primeiro "case" corresponde � op��o de "JOGAR", como tal, quando selecionada abre o jogo, para que o utilizador possa jogar
            
       fflush(stdin);                   //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
       fflush(stdout);                  //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
       
       system("cls");                   //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
       
       fullblock();                     //chamo a fun��o "fullblock()" (a qual criei no meu ficheiro header (tgpsi1320.h)) para dar o primeiro "bloco" do jogo, sendo este em branco, sem furos, como os restantes
       inicio();                        //chamo a fun��o "inicio()" (a qual criei no meu ficheiro header (tgpsi1320.h)) para mostrar o segundo "bloco" do jogo, tendo este os controlos, de novo em branco
       fullblock();                     //chamo denovo a fun��o "fullblock()" (a qual criei no meu ficheiro header (tgpsi1320.h)) para dar o terceiro "bloco" do jogo, sendo este em branco, sem furos, como os restantes
       fullblock1();                    //chamo a fun��o "fullblock1()" (a qual criei no meu ficheiro header (tgpsi1320.h)) para dar o quarto "bloco" do jogo, sendo este em branco, sem furos, como os restantes. Este "bloco" tem uma diferen�a do pr�vio "fullblock()", sendo esta que, neste bloco, a parte inferior do bloco tem uma barra, nos outros n�o.
       
       fflush(stdin);                   //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
       fflush(stdout);                  //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
       srand(time(NULL));               //utilizo a fun��o "srand" com o ponteiro de tempo para que os randoms sejam mesmo random e n�o sempre a mesma seque�ncia.
       for(i=0 ; i<499999 ; i++)        //utilizo uma fun��o "for" para que o jogo seja (quase) infinito e para evitar redund�ncia no meu programa
       { 
               
               rnd=rand()%5;            //utilizo a fun��o "rand()%x" para atribuir um valor aleat�rio � vari�vel "rnd", esta sendo posteriormente utilizada na switch para compor o jogo
               fflush(stdin);           //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
               fflush(stdout);          //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
               switch(rnd)              //utilizo a fun��o "switch()" para que o programa mostre os diferentes tipos de bloco, correspondentes ao valor aleat�rio atribuido � vari�vel "rnd"
               { 
                          
                          
                          case 1:                                     //no primeiro "case", chamo a fun��o que corresponde ao bloco com o furo no primeiro "quadrado" ("firstblack()")
                               
                          fflush(stdin);                              //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
                          fflush(stdout);                             //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                           
                          firstblack();                               //chamo a fun��o "firstblack" (a qual criei no meu ficheiro header (tgpsi1320.h)), tendo esta um "furo" no primeiro quadrado, o qual o utilizador tem de escolher para avan�ar no jogo
                          choice[i]=getch();                          //utilizo a fun��o "getch()" para atribuir o valor � vari�vel "choice", de forma que assim o jogo "n�o para", ou seja n�o � necess�rio pressionar ENTER para avan�ar no jogo
                          switch(choice[i])                           //utilizo uma fun��o "switch()" 'confirmar' que o utilizador premiu a tecla correta
                          { 
                                           case 'd':                  //sendo a primeira tecla, do jogo, o 'd', este case � em fun��o de 'd', tendo o utilizador pressionado o D o jogo ir� continuar
                                                score=score+1;        //desta forma adiciono um ponto � pontua��o actual do utilizador, desta forma consigo 'contar' os pontos que o utilizador est� a obter
                                                continue;             //utilizo a fun��o de "continue" para indicar ao programa que pode continuar, esta fun��o � desnecessaria, mas prefiro utiliza-la, pois faz o programa mais f�cil de ler
                                                break;                //fecho o primeiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'f':                  //sendo a segunda tecla, do jogo, o 'f', este case � em fun��o de 'd', tendo o utilizador pressionado o F o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o segundo "case" do jogo com a fun��o "break;"
                                               
                                           case 'j':                  //sendo a terceira tecla, do jogo, o 'j', este case � em fun��o de 'd', tendo o utilizador pressionado o J o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'k':                  //sendo a quarta tecla, do jogo, o 'k', este case � em fun��o de 'd', tendo o utilizador pressionado o K o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o quarto "case" do jogo com a fun��o "break;"
                                               
                                           default:                   //utilizo a op��o "default" para que se o utilizador pressionar alguma outra tecla, para al�m do D, F, J e K fazer a mesma coisa como se fosse a tecla errada, para prevenir batota no jogo
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o "case default" do jogo com a fun��o "break;"
                          }
                          break;                //fecho o primeiro "case" do switch da vari�vel "rnd"
                          
                          //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\
                          
                          case 2:                                     //no segundo "case", chamo a fun��o que corresponde ao bloco com o furo no segundo "quadrado" ("scndblack()")
                          fflush(stdin);                              //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
                          fflush(stdout);                             //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                           
                          secndblack();                               //chamo a fun��o "scndblack" (a qual criei no meu ficheiro header (tgpsi1320.h)), tendo esta um "furo" no segundo quadrado, o qual o utilizador tem de escolher para avan�ar no jogo
                          choice[i]=getch();                          //utilizo a fun��o "getch()" para atribuir o valor � vari�vel "choice", de forma que assim o jogo "n�o para", ou seja n�o � necess�rio pressionar ENTER para avan�ar no jogo
                          switch(choice[i])                           //utilizo uma fun��o "switch()" 'confirmar' que o utilizador premiu a tecla correta
                          {
                                           case 'd':                  //sendo a primeira tecla, do jogo, o 'd', este case � em fun��o de 'f', tendo o utilizador pressionado o D o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o primeiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'f':                  //sendo a segunda tecla, do jogo, o 'f', este case � em fun��o de 'f', tendo o utilizador pressionado o F o jogo ir� continuar
                                                score=score+1;        //desta forma adiciono um ponto � pontua��o actual do utilizador, desta forma consigo 'contar' os pontos que o utilizador est� a obter
                                                continue;             //utilizo a fun��o de "continue" para indicar ao programa que pode continuar, esta fun��o � desnecessaria, mas prefiro utiliza-la, pois faz o programa mais f�cil de ler
                                                break;                //fecho o segundo "case" do jogo com a fun��o "break;"
                                               
                                           case 'j':                  //sendo a terceira tecla, do jogo, o 'j', este case � em fun��o de 'f', tendo o utilizador pressionado o J o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'k':                  //sendo a quarta tecla, do jogo, o 'k', este case � em fun��o de 'f', tendo o utilizador pressionado o K o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o quarto "case" do jogo com a fun��o "break;"
                                           
                                           default:                   //utilizo a op��o "default" para que se o utilizador pressionar alguma outra tecla, para al�m do D, F, J e K fazer a mesma coisa como se fosse a tecla errada, para prevenir batota no jogo
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o "case default" do jogo com a fun��o "break;"
                                               
                          } 
                          break;               //fecho o segundo "case" do switch da vari�vel "rnd"
                          
                          //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\
                          
                          case 3:                                     //no terceiro "case", chamo a fun��o que corresponde ao bloco com o furo no terceiro "quadrado" ("thirdblack()")
                          fflush(stdin);                              //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
                          fflush(stdout);                             //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                           
                          thirdblack();                               //chamo a fun��o "thirdblack" (a qual criei no meu ficheiro header (tgpsi1320.h)), tendo esta um "furo" no terceiro quadrado, o qual o utilizador tem de escolher para avan�ar no jogo
                          choice[i]=getch();                          //utilizo a fun��o "getch()" para atribuir o valor � vari�vel "choice", de forma que assim o jogo "n�o para", ou seja n�o � necess�rio pressionar ENTER para avan�ar no jogo
                          switch(choice[i])                           //utilizo uma fun��o "switch()" 'confirmar' que o utilizador premiu a tecla correta
                          {
                                           case 'd':                  //sendo a primeira tecla, do jogo, o 'd', este case � em fun��o de 'j', tendo o utilizador pressionado o D o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o primeiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'f':                  //sendo a primeira tecla, do jogo, o 'd', este case � em fun��o de 'j', tendo o utilizador pressionado o F o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o segundo "case" do jogo com a fun��o "break;"
                                               
                                           case 'j':                  //sendo a segunda tecla, do jogo, o 'j', este case � em fun��o de 'j', tendo o utilizador pressionado o J o jogo ir� continuar
                                                score=score+1;        //desta forma adiciono um ponto � pontua��o actual do utilizador, desta forma consigo 'contar' os pontos que o utilizador est� a obter
                                                continue;             //utilizo a fun��o de "continue" para indicar ao programa que pode continuar, esta fun��o � desnecessaria, mas prefiro utiliza-la, pois faz o programa mais f�cil de ler
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'k':                  //sendo a primeira tecla, do jogo, o 'k', este case � em fun��o de 'j', tendo o utilizador pressionado o J o jogo ir� parar          
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu 
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                           
                                           default:                   //utilizo a op��o "default" para que se o utilizador pressionar alguma outra tecla, para al�m do D, F, J e K fazer a mesma coisa como se fosse a tecla errada, para prevenir batota no jogo
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o "case default" do jogo com a fun��o "break;"
                          }
                          break;                //fecho o terceiro "case" do switch da vari�vel "rnd"
                          
                          //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\ //-------------SEPARA��O------------\\
                          
                          case 4:                                     //no quarto "case", chamo a fun��o que corresponde ao bloco com o furo no quarto "quadrado" ("fourfblack()")
                          fflush(stdin);                              //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
                          fflush(stdout);                             //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                           
                          fourfblack();                               //chamo a fun��o "fourfblack" (a qual criei no meu ficheiro header (tgpsi1320.h)), tendo esta um "furo" no quarto quadrado, o qual o utilizador tem de escolher para avan�ar no jogo
                          choice[i]=getch();                          //utilizo a fun��o "getch()" para atribuir o valor � vari�vel "choice", de forma que assim o jogo "n�o para", ou seja n�o � necess�rio pressionar ENTER para avan�ar no jogo
                          switch(choice[i])                           //utilizo uma fun��o "switch()" 'confirmar' que o utilizador premiu a tecla correta
                          {            
                                           case 'd':                  //sendo a primeira tecla, do jogo, o 'd', este case � em fun��o de 'k', tendo o utilizador pressionado o D o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o primeiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'f':                  //sendo a segunda tecla, do jogo, o 'f', este case � em fun��o de 'k', tendo o utilizador pressionado o F o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o segundo "case" do jogo com a fun��o "break;"
                                               
                                           case 'j':                  //sendo a terceira tecla, do jogo, o 'j', este case � em fun��o de 'k', tendo o utilizador pressionado o J o jogo ir� parar
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                               
                                           case 'k':                  //sendo a quarta tecla, do jogo, o 'k', este case � em fun��o de 'k', tendo o utilizador pressionado o K o jogo ir� continuar
                                                score=score+1;        //desta forma adiciono um ponto � pontua��o actual do utilizador, desta forma consigo 'contar' os pontos que o utilizador est� a obter
                                                continue;             //utilizo a fun��o de "continue" para indicar ao programa que pode continuar, esta fun��o � desnecessaria, mas prefiro utiliza-la, pois faz o programa mais f�cil de ler
                                                break;                //fecho o terceiro "case" do jogo com a fun��o "break;"
                                           
                                           default:                   //utilizo a op��o "default" para que se o utilizador pressionar alguma outra tecla, para al�m do D, F, J e K fazer a mesma coisa como se fosse a tecla errada, para prevenir batota no jogo
                                                red();                //sendo esta tecla a errada, o jogo ir� parar, para o fazer ir� chamar a fun��o "red()" a qual mostra um bloco vermelho que diz "LOSE" para mostrar que perdeu
                                                i=i+500000;           //para que o jogo parasse adicionei o valor m�ximo (500000) ao i, acabando assim o "for" do jogo, tendo o i ultrapassado o valor m�ximo
                                                getch();              //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
                                                system("cls");        //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                break;                //fecho o "case default" do jogo com a fun��o "break;"
                          }              
                          
                          break;                //fecho o quarto "case" do switch da vari�vel "rnd"
               
               } //fecho aqui o switch da vari�vel "rnd"        
               
               } //fecho aqui o for da vari�vel i
               
               fflush(stdin);                                    //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
               fflush(stdout);                                   //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
               
               
               system("cls");                                    //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
               
               printf("\n\n\t\t\t\t   SCORE: %i",score);         //mostro, no final do jogo, a pontua��o que o utilizador obteu no jogo
               
               hsc=fopen("highs.txt" , "r");                       //abro o meu ficheiro "highs.txt" onde irei ler as pontua��es mais altas
               for(ha=0 ; ha<10 ; ha++)                            //utilizo uma fun��o "for" para evitar redund�ncia de c�digo
               {
                             
                                             
                                             fscanf(hsc,"%d",&h[ha].pos);         //utilizo um fscanf para ler o ficheiro
                             
               }
               
               if(score > h[9].pos)                              //uso uma fun��o "if" para verificar se a pontua��o que o utilizador obteu no jogo est� nos highscores (10 melhores pontua��es)
               {
                        printf("\n\n\t\t\t\t!!NOVO TOP 10!!");   //se a pontua��o for das melhores 10, esta mensagem ir� aparecer para indicar que a pontua��o do jogo � uma das 10 melhores
                        fflush(stdin);                           //utilizo a fun��o "fflush(stdin)" para limpar o buffer de entrada do programa
                        fflush(stdout);                          //utilizo a fun��o "fflush(stdout)" para limpar o buffer de sa�da do programa
                        
                        
                        
                        if(score>=h[0].pos)                       //ap�s verificar que a pontua��o do jogo est� "eleita" ao top 10, come�o ent�o a verificar se � a pontua��o com a posi��o 1
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=h[4].pos;     // ==
                                          h[4].pos=h[3].pos;     // ==
                                          h[3].pos=h[2].pos;     // ==
                                          h[2].pos=h[1].pos;     // ==
                                          h[1].pos=h[0].pos;     // ==
                                          h[0].pos=score;        // ==
                        }
                        else if(score>=h[1].pos)                  //ap�s verificar que a pontua��o do jogo est� "eleita" ao top 10, come�o ent�o a verificar se � a pontua��o com a posi��o 2
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=h[4].pos;     // ==
                                          h[4].pos=h[3].pos;     // ==
                                          h[3].pos=h[2].pos;     // ==
                                          h[2].pos=h[1].pos;     // ==
                                          h[1].pos=score;        // ==
                        }
                        else if(score>=h[2].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=h[4].pos;     // ==
                                          h[4].pos=h[3].pos;     // ==
                                          h[3].pos=h[2].pos;     // ==
                                          h[2].pos=score;        // ==
                                          
                        }
                        else if(score>=h[3].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=h[4].pos;     // ==
                                          h[4].pos=h[3].pos;     // ==
                                          h[3].pos=score;        // ==
                        }
                        else if(score>=h[4].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=h[4].pos;     // ==
                                          h[4].pos=score;        // ==
                        }
                        else if(score>=h[5].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es 
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=h[5].pos;     // ==
                                          h[5].pos=score;        // ==
                        }
                        else if(score>=h[6].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=h[6].pos;     // ==
                                          h[6].pos=score;        // ==
                        }
                        else if(score>=h[7].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=h[7].pos;     // ==
                                          h[7].pos=score;        // ==
                        }
                        else if(score>=h[8].pos)
                        {
                                          h[9].pos=h[8].pos;     //tenho ent�o de mudificar todos os outros valores para "baixar" um, desta forma n�o "apaga" as pontua��es anteriores nas posi��es correspondentes, em vez disso, vai 1 por 1 mudificando os valores das posi��es
                                          h[8].pos=score;        // ==
                                                    
                        }
                        else if(score>=h[9].pos)
                        {
                                          h[9].pos=score;        //como j� foi verificado que o score � a �ltima posi��o, que pode ser eleita a top 10, neste caso vai apenas mudificar um valor, o �ltimo
                        }
                        
                        hsc=fopen("highs.txt","w");              //ap�s "redefinir" os highscores guardo-os no meu ficheiro
                        for(ll=0 ; ll<10 ; ll++)                 //utilizo uma fun��o "for" para o fazer, de maneira a evitar redund�ncia de c�digo
                        {
                                 fprintf(hsc,"%d\n",h[ll].pos);  //escrevo no meu ficheiro, com a fun��o de "fprintf"
                        }
                        fclose(hsc);                             //fecho o meu ficheiro
               
               }                          //fecho aqui o "if" que verificaria se a pontua��o do �ltimo jogo era "eleita" �s 10 melhores
               
               
               getch();                   //utilizo a fun��o "getch()" para fazer uma pausa no meu programa
               system("cls");             //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
               
               
               break;                     //finalmente fecho o primeiro "case" da switch da vari�vel "menuescolha"
               
  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-//                
               
               case 4:                  //come�o aqui o quinto "case" da switch da vari�vel "menuescolha", a qual corresponde � op��o SAIR                                                                                        
                    exit(1);              //como esta op��o � a de SAIR, executo a fun��o "exit(1)" para fechar o programa, esta � a unica maneira de fechar o programa
                    break;                //fecho aqui o quinto "case" da switch da vari�vel "menuescolha", a qual corresponde � op��o SAIR
                    
  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-//
  
               case 1:                                                //come�o aqui o segundo "case" da switch da vari�vel "menuescolha", a qual corresponde � op��o HIGHSCORES
                    system("cls");                                    //
                    highscoresmenu();                                 //chamo a fun��o "highscoresmenu()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                    hsc=fopen("highs.txt" , "r");                     //abro o meu ficheiro "highs.txt" onde irei ler as pontua��es mais altas
                    for(ha=0 ; ha<9 ; ha++)                           //utilizo uma fun��o "for" para evitar redund�ncia de c�digo
                    {
                             
                                             
                                             fscanf(hsc,"%d",&h[ha].pos);         //utilizo um fscanf para ler o ficheiro
                                             printf("\n\n\t\t\t %i. . . . . . . . . %d",ha+1,h[ha].pos);              //utilizo um printf adequado para todos as demonstra��es de pontua��es no top 10
                             
                    }
                    fscanf(hsc,"%d",&h[9].pos);
                    printf("\n\n\t\t        10. . . . . . . . . %d",h[9].pos);   //utilizo um dos printf's fora do "for" para parecer mais organizado
                    
                    fclose(hsc);                                        //fecho o meu ficheiro com "fclose"
                    getch();                                            //utilizo a fun��o "getch()" para fazer uma pausa no meu programa              
                    break;                                              //fecho aqui o segundo "case" da switch da vari�vel "menuescolha", a qual corresponde � op��o HIGHSCORES

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-// 
  
               case 2:                                       //come�o aqui o terceiro "case" da switch da vari�vel "menuescolha", a qual corresponde � op��o "OP��ES"
                                                          
                    textcolor(writecolor);   //utilizo a fun��o "textcolor" com a vari�vel de "writecolor" para aplicar imediatamente os efeitos de cor
                    opcescolhai=0;
                    
                    do{            //utilizo a fun��o "while()" para que, enquanto o utilizador n�o escolher a op��o de voltar para o menu, o menu das op��es n�o parar de correr
                    do{            //utilizo a fun��o "while" para que enquando o utilizador n�o pressionar ENTER o switch da vari�vel "opcescolhai" n�o parar
                    
                    switch(opcescolhai)
                    {
                                       case 0:                                         //come�o aqui o meu primeiro "case" da switch da vari�vel "opcescolhai"
                                            system("cls");                             //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                            opcoesmenu();                              //chamo aqui a fun��o "opcoesmenu()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                            printf("\n");                              //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                            
                                            textbackground(15);                        //defino ent�o a cor de fundo do meu texto como branco (15)...
                                            textcolor(0);                              //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                            printf("\t\t\t\t     CORES\t\t\t\t\t\n");  //anuncio ent�o a minha primeira vari�vel deste menu, "CORES"
                                            textbackground(0);                         //defino depois a minha cor de fundo como preto, de volta ao default
                                            textcolor(writecolor);                     //defino depois a minha cor de texto como a escolhida pelo utilizador
                                            printf("\t\t\t\tRESET HIGHSCORES\n\n");    //anuncio as restantes op��es deste menu
                                            printf("\t\t\t\tVOLTAR PARA MENU\n\n");    // ==
                                            
                                            break;                                     //termino aqui o meu primero "case" da switch da vari�vel "opcescolhai"
                                       case 1:                                         //come�o aqui o meu segundo "case" da switch da vari�vel "opcescolhai"
                                            system("cls");                             //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                            opcoesmenu();                              //chamo aqui a fun��o "opcoesmenu()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                            printf("\n");                              //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                            
                                            textbackground(0);                         //defino a minha cor de fundo como a "default"
                                            textcolor(writecolor);                     //defino a minha cor de texto como a escolhida pelo utilizador
                                            printf("\t\t\t\t     CORES\n\n");          //anuncio ent�o as diferentes op��es neste menu
                                            textbackground(15);                        //defino ent�o a cor de fundo do meu texto como branco (15)...
                                            textcolor(0);                              //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                            printf("\t\t\t\tRESET HIGHSCORES\t\t\t\t\n");     //anuncio ent�o a  minha segunda op��o do menu de op��es, "RESET HIGHSCORES"
                                            textbackground(0);                         //defino depois a minha cor de fundo como preto, de volta ao default
                                            textcolor(writecolor);                     //defino depois a minha cor de texto como a escolhida pelo utilizador
                                            printf("\t\t\t\tVOLTAR PARA MENU\n\n");    //defino as restantes op��es
                                            
                                            break;                                     //termino aqui o meu segundo "case" da switch da vari�vel "opcescolhai"
                                       case 2:                                         //come�o aqui o meu terceiro "case" da switch da vari�vel "opcescolhai"
                                            system("cls");                             //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                            opcoesmenu();                              //chamo aqui a fun��o "opcoesmenu()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                            printf("\n");                              //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                            
                                            textbackground(0);                         //defino a minha cor de fundo como a "default"
                                            textcolor(writecolor);                     //defino a minha cor de texto como a escolhida pelo utilizador
                                            printf("\t\t\t\t     CORES\n\n");          //anuncio ent�o as diferentes op��es neste menu
                                            printf("\t\t\t\tRESET HIGHSCORES\n\n");    // ==
                                            textbackground(15);                        //defino ent�o a cor de fundo do meu texto como branco (15)...
                                            textcolor(0);                              //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                            printf("\t\t\t\tVOLTAR PARA MENU\t\t\t\t\n");     //anuncio a minha terceira op��o "VOLTAR PARA O MENU"
                                            textbackground(0);                         //defino depois a minha cor de fundo como preto, de volta ao default
                                            textcolor(writecolor);                     //defino depois a minha cor de texto como a escolhida pelo utilizador
                                            
                                            break;                                     //termino aqui o meu terceiro "case" da switch da vari�vel "opcescolhai"
                                       
                    
                    }                       //termino aqui o switch da vari�vel "opcescolhai"
                    opcescolha=getch();     //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                    
                    if(opcescolha=='a' && opcescolhai<2)         //se a tecla for correspondente ao 'a' e se a vari�vel "opcescolhai" (de inicio definido como 0) for menor que 2...
                    {
                                       opcescolhai++;            //ir� adicionar um valor � vari�vel "opcescolhai" de maneira a mostrar as diferentes op��es como selecionadas
                    }
                    else if(opcescolha=='q' && opcescolhai>0)    //se a tecla for correspondente ao 'q' e se a vari�vel "opcescolhai" (de inicio definido como 0) for maior que 0...
                    {    
                                            opcescolhai--;       //ir� retirar um valor � vari�vel "opcescolhai" de  maneira a mostrar as diferentes op��es como selecionadas
                    }
                    }while(opcescolha!=13);                      //fecho aqui o "do while" que come�ei no inicio deste menu, com a condi��o de, enquanto o utilizador n�o pressionar ENTER n�o ir� parar de repetir
                    
                    switch(opcescolhai)                         //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                    {
                                      case 0:                                     //come�o o primeiro "case" da switch do menu de escolhas das op��es, sendo esta primeira escolha/case do menu de CORES
                                           opccoresescolhai=0;                    //defino a vari�vel "opccoresescolhai" como 0, por defeito
                                           do{                                    //come�o uma fun��o "do while" para fazer o "loop" deste menu
                                           
                                           switch(opccoresescolhai)               //come�o a switch da vari�vel "opccoresescolhai"
                                           {
                                                                   case 0:                                                 //come�o aqui o primeiro "case" da switch da vari�vel "opccoresescolhai", correspondente � primeira op��o, "COR DE JOGO"
                                                                        system("cls");                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                        opccores();                                        //chamo a fun��o "opccores()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                                                        printf("\n");                                      //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                        textbackground(15);                                //defino ent�o a cor de fundo do meu texto como branco (15)...
                                                                        textcolor(0);                                      //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                                                        printf("\t\t\t\t COR DE JOGO\t\t\t\t\t\n");        //anuncio a primeira op��o, "COR DE JOGO"
                                                                        textbackground(0);                                 //defino depois a minha cor de fundo como preto, de volta ao default
                                                                        textcolor(writecolor);                             //defino depois a minha cor de texto como a escolhida pelo utilizador
                                                                        printf("\t\t\t\t COR DE TEXTO\n\n");               //anuncio as restantes op��es
                                                                        printf("\t\t\t\tVOLTAR AO MENU\n\n");              // ==     
                                                                        
                                                                        break;                                             //termino aqui o meu primeiro "case" da switch da vari�vel "opccoresescolhai"
                                                                   case 1:                                                 //come�o aqui o primeiro "case" da switch da vari�vel "opccoresescolhai", correspondente � primeira op��o, "COR DE JOGO"
                                                                        system("cls");                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                        opccores();                                        //chamo a fun��o "opccores()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                                                        printf("\n");                                      //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                        textbackground(0);                                 //defino a minha cor de fundo como a "default"
                                                                        textcolor(writecolor);                             //defino a minha cor de texto como a escolhida pelo utilizador
                                                                        printf("\t\t\t\t COR DE JOGO\n\n");                //anuncio a minha primeira op��o "COR DE JOGO"
                                                                        textbackground(15);                                //defino ent�o a cor de fundo do meu texto como branco (15)...
                                                                        textcolor(0);                                      //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                                                        printf("\t\t\t\t COR DE TEXTO\t\t\t\t\t\n");       //anuncio a minha segunda op��o do menu, "COR DE TEXTO"
                                                                        textbackground(0);                                 //defino depois a minha cor de fundo como preto, de volta ao default
                                                                        textcolor(writecolor);                             //defino depois a minha cor de texto como a escolhida pelo utilizador
                                                                        printf("\t\t\t\tVOLTAR AO MENU\n\n");              //anuncio as restantes op��es
                                                                        
                                                                        break;                                             //termino aqui o meu segundo "case" da switch da vari�vel "opccoresescolhai"
                                                                   case 2:                                                 //come�o aqui o terceiro "case" da switch da vari�vel "opccoresescolhai", correspondente � primeira op��o, "VOLTAR PARA O MENU"
                                                                        system("cls");                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                        opccores();                                        //chamo a fun��o "opccores()" (a qual criei no meu ficheiro header (tgpsi1320.h))
                                                                        printf("\n");                                      //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                        textbackground(0);                                 //defino a minha cor de fundo como a "default"
                                                                        textcolor(writecolor);                             //defino a minha cor de texto como a escolhida pelo utilizador
                                                                        printf("\t\t\t\t COR DE JOGO\n\n");                //anuncio as op��es do menu
                                                                        printf("\t\t\t\t COR DE TEXTO\n\n");               // ==
                                                                        textbackground(15);                                //defino ent�o a cor de fundo do meu texto como branco (15)...
                                                                        textcolor(0);                                      //e a minha cor de texto como preto (0), para mostrar facilmente ao utilizador qual das op��es est� de momento selecionada
                                                                        printf("\t\t\t\tVOLTAR AO MENU\t\t\t\t\t\n");      //anuncio aqui a minha terceira op��o "VOLTAR AO MENU"
                                                                        textbackground(0);                                 //defino depois a minha cor de fundo como preto, de volta ao default
                                                                        textcolor(writecolor);                             //defino depois a minha cor de texto como a escolhida pelo utilizador
                                                                        
                                                                        break;                                             //termino aqui o meu terceiro "case" da switch da vari�vel "opccoresescolhai"            
                                                                              
                                           }
                                           opccoresescolha=getch();                 //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                           
                                           if(opccoresescolha=='a' && opccoresescolhai<2)         //se a tecla for correspondente ao 'a' e se a vari�vel "opccoresescolhai" (de inicio definido como 0) for menor que 2...
                                           {
                                                                   opccoresescolhai++;            //ir� retirar um valor � vari�vel "opccoresescolhai" de  maneira a mostrar as diferentes op��es como selecionadas
                                           }
                                           else if(opccoresescolha=='q' && opccoresescolhai>0)    //se a tecla for correspondente ao 'q' e se a vari�vel "opccoresescolhai" (de inicio definido como 0) for maior que 0...
                                           {
                                                                        opccoresescolhai--;       //ir� retirar um valor � vari�vel "opccoresescolhai" de  maneira a mostrar as diferentes op��es como selecionadas
                                           }
                                           
                                           }while(opccoresescolha!=13);                           //termino aqui o "do while" que come�ei no inicio deste menu
                                           
                                           
                                           switch(opccoresescolhai)                  //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                                           {
                                                                  case 0:                                                               //come�o o primeiro "case" da switch do menu de escolhas de cores do jogo
                                                                       opccoresjogoescolhai=0;                                          //defino a vari�ve� "opccoresjogoescolhai" como 0
                                                                       
                                                                       do{                                                              //utilizo uma fun��o "do while" para, enquanto o utilizador n�o carregar ENTER, o menu n�o avan�ar
                                                                       
                                                                       switch(opccoresjogoescolhai)
                                                                       {
                                                                                                   case 0:
                                                                                                        system("cls");                                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                        opccores();                                                        //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                        printf("\n");
                                                                                                        textbackground(15);
                                                                                                        textcolor(0);                                                      
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BLOCO          |         ACTUAL: |");textbackground(0);textcolor(blockcolor);printf("#");textbackground(15);textcolor(0);printf("|\t\t\t\t");      //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\t\t\t");
                                                                                                        printf("\n\n");
                                                                                                        textbackground(0);
                                                                                                        textcolor(writecolor);
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BARRA          |         ACTUAL: |");textbackground(0);textcolor(barcolor);printf("#");textcolor(writecolor);printf("|\t\t\t\t");        //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\t\t\t\t\t");
                                                                                                        printf("\n\n");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\t                    VOLTAR                \t\t\t\t\t");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        
                                                                                                        
                                                                                                        break;
                                                                                                   case 1:
                                                                                                        system("cls");                                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                        opccores();                                                        //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                        printf("\n");
                                                                                                        textbackground(0);
                                                                                                        textcolor(writecolor);                                                      
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BLOCO          |         ACTUAL: |");textbackground(0);textcolor(blockcolor);printf("#");textcolor(writecolor);printf("|\t\t\t\t");      //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\n");
                                                                                                        printf("\n\n");
                                                                                                        textbackground(15);
                                                                                                        textcolor(0);  
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BARRA          |         ACTUAL: |");textbackground(0);textcolor(barcolor);printf("#");textbackground(15);textcolor(0);printf("|\t\t\t\t");        //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\t\t\t");
                                                                                                        textbackground(0);
                                                                                                        textcolor(writecolor);  
                                                                                                        printf("\n\n");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\t                    VOLTAR                \t\t\t\t\t");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        
                                                                                                        break;
                                                                                                   case 2:
                                                                                                        system("cls");                                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                        opccores();                                                        //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                        printf("\n");
                                                                                                        textbackground(0);
                                                                                                        textcolor(writecolor);                                                      
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BLOCO          |         ACTUAL: |");textbackground(0);textcolor(blockcolor);printf("#");textcolor(writecolor);printf("|\t\t\t\t");      //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\n");
                                                                                                        printf("\n\n");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\tCOR DE BARRA          |         ACTUAL: |");textbackground(0);textcolor(barcolor);printf("#");;textcolor(writecolor);printf("|\t\t\t\t");        //utilizo, neste printf, uma variedade de cores, para o utilizador conseguir visionar qual a cor de bloco est� selecionada actualmente
                                                                                                        printf("\t                                         -\t\t\t");
                                                                                                        textbackground(15);
                                                                                                        textcolor(0);  
                                                                                                        printf("\n\n");
                                                                                                        printf("\t                                          \t\t\t\t\t");
                                                                                                        printf("\t                    VOLTAR                \t\t\t\t\t");
                                                                                                        printf("\t                                          \t\t");
                                                                                                        textbackground(0);
                                                                                                        textcolor(writecolor); 
                                                                                                        
                                                                                                        break;
                                                                       }
                                                                       opccoresjogoescolha=getch();     //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                       
                                                                       
                                                                       if(opccoresjogoescolha=='a' && opccoresjogoescolhai<2)          //se a tecla for correspondente ao 'a' e se a vari�vel "opccoresjogoescolhai" (de inicio definido como 0) for menor que 2...
                                                                       {
                                                                                               opccoresjogoescolhai++;                 //ir� retirar um valor � vari�vel "opccoresjogoescolhai" de  maneira a mostrar as diferentes op��es como selecionadas
                                                                       }
                                                                       else if(opccoresjogoescolha=='q' && opccoresjogoescolhai>0)     //se a tecla for correspondente ao 'q' e se a vari�vel "opccoresjogoescolhai" (de inicio definido como 0) for maior que 0...
                                                                       {
                                                                                                    opccoresjogoescolhai--;            //ir� retirar um valor � vari�vel "opccoresjogoescolhai" de  maneira a mostrar as diferentes op��es como selecionadas
                                                                       }
                                                                       
                                                                                              
                                                                       }while(opccoresjogoescolha!=13);                                //termino aqui o meu "do while" que come�ei ao inicio deste menu
                                                                       
                                                                                                             
                                                                       
                                                                       switch(opccoresjogoescolhai)                                        //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                                                                       {
                                                                                                  case 0:                                                                 //come�o o primeiro "case" da switch do menu de escolhas de cores de bloco
                                                                                                       system("cls");                                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                       opccores_escolher();                                               //chamo a fun��o "opccores()" (a qual criei no meu ficheiro de header (tgpsi1320.h))
                                                                                                       printf("\n");                                                      //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                       printf("\t\t              COR DE BLOCO\n\n");                      //dou um titulo ao menu, para o utilizador conseguir facilmente identificar o que est� a fazer
                                                                                                       printf("\t\t0: PRETO             |  8: CINZA\n");                  //anuncio as v�rias op��es de cores que o utlizador pode escolher
                                                                                                       printf("\t\t1: AZUL              |  9: AZUL CLARO\n");             // ==
                                                                                                       printf("\t\t2: VERDE             |  a: VERDE CLARO\n");            // ==
                                                                                                       printf("\t\t3: CIANO             |  b: CIANO CLARO\n");            // ==
                                                                                                       printf("\t\t4: VERMELHO          |  c: VERMELHO CLARO\n");         // ==
                                                                                                       printf("\t\t5: ROXO              |  d: ROXO CLARO\n");             // ==
                                                                                                       printf("\t\t6: AMARELO           |  e: AMARELO CLARO\n");          // ==
                                                                                                       printf("\t\t7: BRANCO            |  f: BRANCO ?CLARO?\n");         // ==
                                                                                                       printf("\n\t\t           v: Voltar para op��es\n");                // ==
                                                                                                       
                                                                                                       
                                                                                                       
                                                                                                       corblocoescolha=getch();           //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                                                       
                                                                                                       switch(corblocoescolha)            //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                                                                                                       {
                                                                                                                              case '0':                 //come�o o primeiro "case" da switch das cores de bloco
                                                                                                                                   blockcolor=0;        //define a cor de bloco (vari�vel "blockcolor") como 0, ou seja PRETO
                                                                                                                                   break;               //fecho aqui o primeiro "case" da switch das cores de bloco
                                                                                                                              case '1':                 //come�o o segundo "case" da switch das cores de bloco
                                                                                                                                   blockcolor=1;        //define a cor de bloco (vari�vel "blockcolor") como 1, ou seja AZUL
                                                                                                                                   break;               //fecho aqui o segundo "case" da switch das cores de bloco
                                                                                                                              case '2':                 //come�o o terceiro "case" da switch das cores de bloco
                                                                                                                                   blockcolor=2;        //define a cor de bloco (vari�vel "blockcolor") como 2, ou seja VERDE
                                                                                                                                   break;               //fecho aqui o terceiro "case" da switch das cores de bloco
                                                                                                                              case '3':                 //come�o o quarto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=3;        //define a cor de bloco (vari�vel "blockcolor") como 3, ou seja CIANO
                                                                                                                                   break;               //fecho aqui o quarto "case" da switch das cores de bloco
                                                                                                                              case '4':                 //come�o o quinto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=4;        //define a cor de bloco (vari�vel "blockcolor") como 4, ou seja VERMELHO
                                                                                                                                   break;               //fecho aqui o quinto "case" da switch das cores de bloco
                                                                                                                              case '5':                 //come�o o sexto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=5;        //define a cor de bloco (vari�vel "blockcolor") como 5, ou seja ROXO
                                                                                                                                   break;               //fecho aqui o sexto "case" da switch das cores de bloco
                                                                                                                              case '6':                 //come�o o s�timo "case" da switch das cores de bloco
                                                                                                                                   blockcolor=6;        //define a cor de bloco (vari�vel "blockcolor") como 6, ou seja AMARELO
                                                                                                                                   break;               //fecho aqui o s�timo "case" da switch das cores de bloco
                                                                                                                              case '7':                 //come�o o oitavo "case" da switch das cores de bloco
                                                                                                                                   blockcolor=7;        //define a cor de bloco (vari�vel "blockcolor") como 7, ou seja BRANCO
                                                                                                                                   break;               //fecho aqui o oitavo "case" da switch das cores de bloco
                                                                                                                              case '8':                 //come�o o nono "case" da switch das cores de bloco
                                                                                                                                   blockcolor=8;        //define a cor de bloco (vari�vel "blockcolor") como 8, ou seja CINZA
                                                                                                                                   break;               //fecho aqui o nono "case" da switch das cores de bloco
                                                                                                                              case '9':                 //come�o o d�cimo "case" da switch das cores de bloco
                                                                                                                                   blockcolor=9;        //define a cor de bloco (vari�vel "blockcolor") como 9, ou seja AZUL CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo "case" da switch das cores de bloco
                                                                                                                              case 'a':                 //come�o o d�cimo primeiro "case" da switch das cores de bloco
                                                                                                                                   blockcolor=10;       //define a cor de bloco (vari�vel "blockcolor") como 10, ou seja VERDE CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo primeiro "case" da switch das cores de bloco
                                                                                                                              case 'b':                 //come�o o d�cimo segundo "case" da switch das cores de bloco
                                                                                                                                   blockcolor=11;       //define a cor de bloco (vari�vel "blockcolor") como 11, ou seja CIANO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo segundo "case" da switch das cores de bloco
                                                                                                                              case 'c':                 //come�o o d�cimo terceiro "case" da switch das cores de bloco
                                                                                                                                   blockcolor=12;       //define a cor de bloco (vari�vel "blockcolor") como 12, ou seja VERMELHO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo terceiro "case" da switch das cores de bloco
                                                                                                                              case 'd':                 //come�o o d�cimo quarto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=13;       //define a cor de bloco (vari�vel "blockcolor") como 13, ou seja ROXO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quarto "case" da switch das cores de bloco
                                                                                                                              case 'e':                 //come�o o d�cimo quinto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=14;       //define a cor de bloco (vari�vel "blockcolor") como 14, ou seja AMARELO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quinto "case" da switch das cores de bloco
                                                                                                                              case 'f':                 //come�o o d�cimo sexto "case" da switch das cores de bloco
                                                                                                                                   blockcolor=15;       //define a cor de bloco (vari�vel "blockcolor") como 15, ou seja BRANCO CLARO (? TAMB�M N�O ENTENDO A L�GICA DE C?)
                                                                                                                                   break;               //fecho aqui o d�cimo sexto "case" da switch das cores de bloco
                                                                                                                              case 'v':
                                                                                                                                   continue;
                                                                                                                                   break;
                                                                                                                              default:                           //come�o o "default case" da switch das cores de bloco
                                                                                                                                   printf("ESCOLHA INV�LIDA");   //mostro uma mensagem para indicar que a escolha do utilizador � inv�lida, ou seja, n�o est� dentro das outras
                                                                                                                                   getch();                      //utilizo uma fun��o "getch()" para fazer uma pausa no programa
                                                                                                                                   break;                        //fecho aqui o "default case" da switch das cores de bloco
                                                                                                                              }                         //fecho aqui o switch do menu de cores de bloco
                                                                                                                              
                                                                                                  break;                 //fecho aqui o primeiro "case" do menu de op��es de cor de jogo
                                                                                                       
                                                                                                  case 1:              //come�o aqui o segundo "case" do menu de op��es de cor de jogo, este correspondendo �s cores da barra 
                                                                                                       system("cls");                                                     //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                       opccores_escolher();                                               //chamo a mesma fun��o "opccores()" para dar uma "ideia" de uniformidade ao programa, nos menus
                                                                                                       printf("\n");                                                      //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                       printf("\t\t              COR DE BARRA\n\n");                      //dou um titulo ao menu, para o utilizador conseguir facilmente identificar o que est� a fazer
                                                                                                       printf("\t\t0: PRETO             |  8: CINZA\n");                  //anuncio as v�rias op��es de cores que o utlizador pode escolher
                                                                                                       printf("\t\t1: AZUL              |  9: AZUL CLARO\n");             // ==
                                                                                                       printf("\t\t2: VERDE             |  a: VERDE CLARO\n");            // ==
                                                                                                       printf("\t\t3: CIANO             |  b: CIANO CLARO\n");            // ==
                                                                                                       printf("\t\t4: VERMELHO          |  c: VERMELHO CLARO\n");         // ==
                                                                                                       printf("\t\t5: ROXO              |  d: ROXO CLARO\n");             // ==
                                                                                                       printf("\t\t6: AMARELO           |  e: AMARELO CLARO\n");          // ==
                                                                                                       printf("\t\t7: BRANCO            |  f: BRANCO ?CLARO?\n");         // ==
                                                                                                       printf("\n\t\t           v: Voltar para op��es\n");
                                                                                                       
                                                                                                       
                                                                                                       corbarescolha=getch();              //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                                                       
                                                                                                       switch(corbarescolha)               //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                                                                                                       {
                                                                                                                              case '0':                 //come�o o primeiro "case" da switch das cores de barra
                                                                                                                                   barcolor=0;        //define a cor de barra (vari�vel "blockcolor") como 0, ou seja PRETO
                                                                                                                                   break;               //fecho aqui o primeiro "case" da switch das cores de barra
                                                                                                                              case '1':                 //come�o o segundo "case" da switch das cores de barra
                                                                                                                                   barcolor=1;        //define a cor de barra (vari�vel "blockcolor") como 1, ou seja AZUL
                                                                                                                                   break;               //fecho aqui o segundo "case" da switch das cores de barra
                                                                                                                              case '2':                 //come�o o terceiro "case" da switch das cores de barra
                                                                                                                                   barcolor=2;        //define a cor de barra (vari�vel "blockcolor") como 2, ou seja VERDE
                                                                                                                                   break;               //fecho aqui o terceiro "case" da switch das cores de barra
                                                                                                                              case '3':                 //come�o o quarto "case" da switch das cores de barra
                                                                                                                                   barcolor=3;        //define a cor de barra (vari�vel "blockcolor") como 3, ou seja CIANO
                                                                                                                                   break;               //fecho aqui o quarto "case" da switch das cores de barra
                                                                                                                              case '4':                 //come�o o quinto "case" da switch das cores de barra
                                                                                                                                   barcolor=4;        //define a cor de barra (vari�vel "blockcolor") como 4, ou seja VERMELHO
                                                                                                                                   break;               //fecho aqui o quinto "case" da switch das cores de barra
                                                                                                                              case '5':                 //come�o o sexto "case" da switch das cores de barra
                                                                                                                                   barcolor=5;        //define a cor de barra (vari�vel "blockcolor") como 5, ou seja ROXO
                                                                                                                                   break;               //fecho aqui o sexto "case" da switch das cores de barra
                                                                                                                              case '6':                 //come�o o s�timo "case" da switch das cores de barra
                                                                                                                                   barcolor=6;        //define a cor de barra (vari�vel "blockcolor") como 6, ou seja AMARELO
                                                                                                                                   break;               //fecho aqui o s�timo "case" da switch das cores de barra
                                                                                                                              case '7':                 //come�o o oitavo "case" da switch das cores de barra
                                                                                                                                   barcolor=7;        //define a cor de barra (vari�vel "blockcolor") como 7, ou seja BRANCO
                                                                                                                                   break;               //fecho aqui o oitavo "case" da switch das cores de barra
                                                                                                                              case '8':                 //come�o o nono "case" da switch das cores de barra
                                                                                                                                   barcolor=8;        //define a cor de barra (vari�vel "blockcolor") como 8, ou seja CINZA
                                                                                                                                   break;               //fecho aqui o nono "case" da switch das cores de barra
                                                                                                                              case '9':                 //come�o o d�cimo "case" da switch das cores de barra
                                                                                                                                   barcolor=9;        //define a cor de barra (vari�vel "blockcolor") como 9, ou seja AZUL CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo "case" da switch das cores de barra
                                                                                                                              case 'a':                 //come�o o d�cimo primeiro "case" da switch das cores de barra
                                                                                                                                   barcolor=10;       //define a cor de barra (vari�vel "blockcolor") como 10, ou seja VERDE CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo primeiro "case" da switch das cores de barra
                                                                                                                              case 'b':                 //come�o o d�cimo segundo "case" da switch das cores de barra
                                                                                                                                   barcolor=11;       //define a cor de barra (vari�vel "blockcolor") como 11, ou seja CIANO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo segundo "case" da switch das cores de barra
                                                                                                                              case 'c':                 //come�o o d�cimo terceiro "case" da switch das cores de barra
                                                                                                                                   barcolor=12;       //define a cor de barra (vari�vel "blockcolor") como 12, ou seja VERMELHO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo terceiro "case" da switch das cores de barra
                                                                                                                              case 'd':                 //come�o o d�cimo quarto "case" da switch das cores de barra
                                                                                                                                   barcolor=13;       //define a cor de barra (vari�vel "blockcolor") como 13, ou seja ROXO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quarto "case" da switch das cores de barra
                                                                                                                              case 'e':                 //come�o o d�cimo quinto "case" da switch das cores de barra
                                                                                                                                   barcolor=14;       //define a cor de barra (vari�vel "blockcolor") como 14, ou seja AMARELO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quinto "case" da switch das cores de barra
                                                                                                                              case 'f':                 //come�o o d�cimo sexto "case" da switch das cores de barra
                                                                                                                                   barcolor=15;       //define a cor de barra (vari�vel "blockcolor") como 15, ou seja BRANCO CLARO (? TAMB�M N�O ENTENDO A L�GICA DE C?)
                                                                                                                                   break;               //fecho aqui o d�cimo sexto "case" da switch das cores de barra
                                                                                                                              case 'v':
                                                                                                                                   continue;
                                                                                                                                   break;
                                                                                                                              default:                           //come�o o "default case" da switch das cores de barra
                                                                                                                                   printf("ESCOLHA INV�LIDA");   //mostro uma mensagem para indicar que a escolha do utilizador � inv�lida, ou seja, n�o est� dentro das outras
                                                                                                                                   getch();                      //utilizo uma fun��o "getch()" para fazer uma pausa no programa
                                                                                                                                   break;                        //fecho aqui o "default case" da switch das cores de barra
                                                                                                                              }                         //fecho aqui o switch do menu de cores de barra
                                                                                                       
                                                                                                                 break;       //fecho aqui segundo "case" do menu de cores de jogo
                                                                                                                 }            //fecho aqui a switch do menu de cores de jogo (barra + bloco)
                                                                                                       break;    //fecho aqui o primeiro "case" da switch do menu de op��es
                                                                                                       
                                                                                                       
                                                                                                       case 1:                                                  //come�o aqui o segundo "case" do menu de op��es, este correspondendo �s cores de texto
                                                                                                       system("cls");                                             //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                       opccores_escolher();                                       //chamo a mesma fun��o "opccores()" para dar uma "ideia" de uniformidade ao programa, nos menus                             
                                                                                                       printf("\n");                                              //utilizo um simples printf para fazer um espa�o no c�digo, desta forma os restantes (printf's) ficam mais f�ceis de ler
                                                                                                       printf("\t\t              COR DE TEXTO\n\n");              //dou um titulo ao menu, para o utilizador conseguir facilmente identificar o que est� a fazer
                                                                                                       printf("\t\t0: PRETO             |  8: CINZA\n");          //anuncio as v�rias op��es das quais o utilizador pode escolher
                                                                                                       printf("\t\t1: AZUL              |  9: AZUL CLARO\n");     // ==
                                                                                                       printf("\t\t2: VERDE             |  a: VERDE CLARO\n");    // ==
                                                                                                       printf("\t\t3: CIANO             |  b: CIANO CLARO\n");    // ==
                                                                                                       printf("\t\t4: VERMELHO          |  c: VERMELHO CLARO\n"); // ==
                                                                                                       printf("\t\t5: ROXO              |  d: ROXO CLARO\n");     // ==
                                                                                                       printf("\t\t6: AMARELO           |  e: AMARELO CLARO\n");  // ==
                                                                                                       printf("\t\t7: BRANCO            |  f: BRANCO ?CLARO?\n"); // ==
                                                                                                       printf("\n\t\t           v: Voltar para op��es\n");
                                                                                                       
                                                                                                       cortextoescolha=getch();              //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                                                       
                                                                                                       switch(cortextoescolha)               //utilizo uma fun��o "switch()" para conseguir alternar entre as diferentes escolhas do menu anterior
                                                                                                       {
                                                                                                                              case '0':                                         //come�o o primeiro "case" da switch de cores de texto
                                                                                                                                   printf("\n\nESCOLHA INV�LIDA!!!!");          //como o nosso fundo de janela � preto decidi que n�o deveria ser uma escolha v�lida para cor de texto
                                                                                                                                   getch();                                     //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                                                                                   break;                                       //fecho aqui o primeiro "case" da switch das cores de texto
                                                                                                                              case '1':                 //come�o o segundo "case" da switch das cores de texto
                                                                                                                                   writecolor=1;        //define a cor de texto (vari�vel "blockcolor") como 1, ou seja AZUL
                                                                                                                                   break;               //fecho aqui o segundo "case" da switch das cores de texto
                                                                                                                              case '2':                 //come�o o terceiro "case" da switch das cores de texto
                                                                                                                                   writecolor=2;        //define a cor de texto (vari�vel "blockcolor") como 2, ou seja VERDE
                                                                                                                                   break;               //fecho aqui o terceiro "case" da switch das cores de texto
                                                                                                                              case '3':                 //come�o o quarto "case" da switch das cores de texto
                                                                                                                                   writecolor=3;        //define a cor de texto (vari�vel "blockcolor") como 3, ou seja CIANO
                                                                                                                                   break;               //fecho aqui o quarto "case" da switch das cores de texto
                                                                                                                              case '4':                 //come�o o quinto "case" da switch das cores de texto
                                                                                                                                   writecolor=4;        //define a cor de texto (vari�vel "blockcolor") como 4, ou seja VERMELHO
                                                                                                                                   break;               //fecho aqui o quinto "case" da switch das cores de texto
                                                                                                                              case '5':                 //come�o o sexto "case" da switch das cores de texto
                                                                                                                                   writecolor=5;        //define a cor de texto (vari�vel "blockcolor") como 5, ou seja ROXO
                                                                                                                                   break;               //fecho aqui o sexto "case" da switch das cores de texto
                                                                                                                              case '6':                 //come�o o s�timo "case" da switch das cores de texto
                                                                                                                                   writecolor=6;        //define a cor de texto (vari�vel "blockcolor") como 6, ou seja AMARELO
                                                                                                                                   break;               //fecho aqui o s�timo "case" da switch das cores de texto
                                                                                                                              case '7':                 //come�o o oitavo "case" da switch das cores de texto
                                                                                                                                   writecolor=7;        //define a cor de texto (vari�vel "blockcolor") como 7, ou seja BRANCO
                                                                                                                                   break;               //fecho aqui o oitavo "case" da switch das cores de texto
                                                                                                                              case '8':                 //come�o o nono "case" da switch das cores de texto
                                                                                                                                   writecolor=8;        //define a cor de texto (vari�vel "blockcolor") como 8, ou seja CINZA
                                                                                                                                   break;               //fecho aqui o nono "case" da switch das cores de texto
                                                                                                                              case '9':                 //come�o o d�cimo "case" da switch das cores de texto
                                                                                                                                   writecolor=9;        //define a cor de texto (vari�vel "blockcolor") como 9, ou seja AZUL CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo "case" da switch das cores de texto
                                                                                                                              case 'a':                 //come�o o d�cimo primeiro "case" da switch das cores de texto
                                                                                                                                   writecolor=10;       //define a cor de texto (vari�vel "blockcolor") como 10, ou seja VERDE CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo primeiro "case" da switch das cores de texto
                                                                                                                              case 'b':                 //come�o o d�cimo segundo "case" da switch das cores de texto
                                                                                                                                   writecolor=11;       //define a cor de texto (vari�vel "blockcolor") como 11, ou seja CIANO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo segundo "case" da switch das cores de texto
                                                                                                                              case 'c':                 //come�o o d�cimo terceiro "case" da switch das cores de texto
                                                                                                                                   writecolor=12;       //define a cor de texto (vari�vel "blockcolor") como 12, ou seja VERMELHO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo terceiro "case" da switch das cores de texto
                                                                                                                              case 'd':                 //come�o o d�cimo quarto "case" da switch das cores de texto
                                                                                                                                   writecolor=13;       //define a cor de texto (vari�vel "blockcolor") como 13, ou seja ROXO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quarto "case" da switch das cores de texto
                                                                                                                              case 'e':                 //come�o o d�cimo quinto "case" da switch das cores de texto
                                                                                                                                   writecolor=14;       //define a cor de texto (vari�vel "blockcolor") como 14, ou seja AMARELO CLARO
                                                                                                                                   break;               //fecho aqui o d�cimo quinto "case" da switch das cores de texto
                                                                                                                              case 'f':                 //come�o o d�cimo sexto "case" da switch das cores de texto
                                                                                                                                   writecolor=15;       //define a cor de texto (vari�vel "blockcolor") como 15, ou seja BRANCO CLARO (? TAMB�M N�O ENTENDO A L�GICA DE C?)
                                                                                                                                   break;               //fecho aqui o d�cimo sexto "case" da switch das cores de texto
                                                                                                                              case 'v':
                                                                                                                                   continue;
                                                                                                                                   break;
                                                                                                                              default:                               //come�o aqui o "default case" da switch de cores de texto
                                                                                                                                   printf("\n\nESCOLHA INV�LIDA");   //anuncio, quando o utilizador n�o escolhe uma das op��es anunciadas, que fez uma escolha inv�lida
                                                                                                                                   getch();                          //utilizo uma fun��o "getch()" para fazer uma pausa no programa
                                                                                                                                   break;                            //fecho aqui o "default case" da switch de cores de texto
                                                                                                                                   }                                 //fecho aqui a switch de cores de texto
                                                                                                       break;                       //fecho aqui o primeiro "case" da switch de op��es, respetivamente a op��o de CORES                               
                                                                                                       }                            //fecho aqui o switch de op��es de cor
                                                                                                       break;                       //fecho aqui o primeiro "case" relativamente ao switch de op��es
                                                                                                       case 1:                    //come�o aqui o terceiro "case" da minha switch de op��es, correspondente � op��o de "RESET HIGHSCORES"
                                                                                                            pcresetescolhai=0;
                                                                                                            
                                                                                                            do{
                                                                                                            
                                                                                                            switch(pcresetescolhai)
                                                                                                            {
                                                                                                                                   case 0:
                                                                                                                                        system("cls");          //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes 
                                                                                                            
                                                                                                                                        printf("\n\n\n\t\t           TEM A CERTEZA QUE QUER LIMPAR\n\t\t     TODOS OS REGISTOS DE PONTU��ES ATUAIS?");        //fa�o uma "verifica��o de inten��o" ao utilizador para evitar que, por acidente, o utilizador limpe as suas pontua��es
                                                                                                                                        textbackground(15);
                                                                                                                                        textcolor(0);
                                                                                                                                        printf("\n\n\n\t\t\t\t     SIM\t\t\t\t\t");                                                                        //utilizo simples printf's para mostrar ao utilizador as suas op��es                                                                                                  
                                                                                                                                        textbackground(0);
                                                                                                                                        textcolor(writecolor);
                                                                                                                                        printf("\n\t\t\t\t     N�O");                                                                             //==
                                                                                                                                        
                                                                                                                                        break;
                                                                                                                                    
                                                                                                                                    case 1:
                                                                                                                                        system("cls");          //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes 
                                                                                                            
                                                                                                                                        printf("\n\n\n\t\t           TEM A CERTEZA QUE QUER LIMPAR\n\t\t     TODOS OS REGISTOS DE PONTU��ES ATUAIS?");        //fa�o uma "verifica��o de inten��o" ao utilizador para evitar que, por acidente, o utilizador limpe as suas pontua��es
                                                                                                                                        textbackground(0);
                                                                                                                                        textcolor(writecolor);
                                                                                                                                        printf("\n\n\n\t\t\t\t     SIM\n");                                                                        //utilizo simples printf's para mostrar ao utilizador as suas op��es                                                                                                  
                                                                                                                                        textbackground(15);
                                                                                                                                        textcolor(0);
                                                                                                                                        printf("\n\t\t\t\t     N�O\t\t\t\t\t");   
                                                                                                                                        textbackground(0);
                                                                                                                                        textcolor(writecolor);                                                                          //==
                                                                                                                                        
                                                                                                                                        break;
                                                                                                            }
                                                                                                            pcresetescolha=getch();                                                                              //utilizo uma fun��o "getch()" como uma forma de evitar que o utilizador tenha de pressionar ENTER para que a sua escolha seja efectuada
                                                                                                            
                                                                                                            if(pcresetescolha=='a' && pcresetescolhai<1)
                                                                                                            {
                                                                                                                                        pcresetescolhai++;
                                                                                                            }
                                                                                                            else if(pcresetescolha=='q' && pcresetescolhai>0)
                                                                                                            {
                                                                                                                                             pcresetescolhai--;
                                                                                                            }
                                                                       
                                                                                              
                                                                                                            }while(pcresetescolha!=13);
                                                                                                                
                                                                                                       
                                                                                                            if(pcresetescolhai==0)                                                                              //utilizo uma fun��o "if" em vez de "switch" pois, neste caso, exitem apenas 2 op��es, logo seria desnecess�rio o uso de uma "switch"
                                                                                                            {
                                                                                                            
                                                                                                            hsc=fopen("highs.txt" , "w");
                                                                                                            for(jj=0 ; jj<10 ; jj++)//utilizo a fun��o de "for" com a vari�vel "jj", pr�viamente anunciada, no inicio do c�gigo
                                                                                                            {
                                                                                                                     h[jj].pos=0;   //com esta fun��o(for) limpo os registos de pontua��es que haviam anteriormente.
                                                                                                                     fprintf(hsc,"%d\n",h[jj].pos);
                                                                                                                     
                                                                                                            }
                                                                                                            fclose(hsc);
                                                                             
                                                                                                            
                                                                                                            
                                                                                                            printf("\n\n\n\t\t         OS SEUS HIGHSCORES FORAM LIMPOS!");       //ap�s os dados de pontua��es serem limpos, anuncio ao utilizador que o seu pedido foi executado com sucesso
                                                                                                            getch();               //utilizo uma fun��o "getch()" para fazer uma pausa no programa
                                                                                                            }                      //termino aqui a minha fun��o de "for"
                                                                                                            
                                                                                                            
                                                                                                       break; 
                                                                                                       }                            //fecho aqui o switch de op��es
                                                                                                       
                                                                                                       
                                                                                                  
                                                                                                       system("cls");               //utilizo a fun��o "system("cls")" para 'limpar' o ecr�, o seja, dar "reset", para dar uma 'ideia' de janelas diferentes
                                                                                                       }while(opcescolhai!=2);     //fecho aqui a fun��o "while" do menu de op��es        
                                                                                                       break;                       //fecho aqui o terceiro "case" da switch de escolhas do menu pricipal, correspondente � op��o de op��es 
                                                                                                       }                            //fecho aqui o switch do menu inicial/principal
                                                                                                       
                                                                                                                        
                                                                                                       
                                                                       
                    
                    
                    
                    
                   
                    
               
               
               fflush(stdin);
               fflush(stdout);
               
               } //fecho aqui o while que come�ei no inicio de programa, para o programa n�o fechar
               }while(select==3); //fecho aqui o while que come�ei no inicio do programa, para mudar de utilizador
}
