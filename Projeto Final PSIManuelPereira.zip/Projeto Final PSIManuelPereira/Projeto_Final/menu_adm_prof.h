#ifndef MENU_ADM_PROF_H_INCLUDED
#define MENU_ADM_PROF_H_INCLUDED
//Headers
#include "menu_adm.h"

//Vari�veis para o professor
struct professor
{
    int telemovel;
    char nome[100], nascimento[10], morada[80], local[40], email[60];
};
struct professor prof;

//Registrador de professores
void add2()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * profins;
    struct professor prof;
    char outro = 's';

    profins=fopen("professores.txt","ab+");
    //Ficheiro n�o encontrado
    if(profins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    fflush(stdin);

    //Ciclo de repeti��o se no final for premida a tecla 's'
    while(outro == 's')
    {
        //Logo
        system("cls");
        textcolor(LIGHTBLUE);
        printf(R"EOF(
  ______ _      _                 _        _____                     _      /\/|
 |  ____(_)    | |               | |      |_   _|                   (_)    |/\/
 | |__   _  ___| |__   __ _    __| | ___    | |  _ __  ___  ___ _ __ _  ___ __ _  ___
 |  __| | |/ __| '_ \ / _` |  / _` |/ _ \   | | | '_ \/ __|/ __| '__| |/ __/ _` |/ _ \
 | |    | | (__| | | | (_| | | (_| |  __/  _| |_| | | \__ \ (__| |  | | (_| (_| | (_) |
 |_|    |_|\___|_| |_|\__,_|  \__,_|\___| |_____|_| |_|___/\___|_|  |_|\___\__,_|\___/
                                                                        )_)
        )EOF");
        textcolor(LIGHTGRAY);

        //Input de informa��es
        printf("\n Nome do professor:\n >");
        gets(prof.nome);

        printf("\n Data de nascimento do professor:\n Ex.:(12.09.1979)\n >");
        gets(prof.nascimento);

        printf("\n Morada:\n >");
        gets(prof.morada);

        printf("\n Localidade e C�digo postal:\n Ex.:(Lisboa - 2790-226)\n >");
        gets(prof.local);

        printf("\n N�mero de telem�vel do professor:\n >");
        scanf("%i",&prof.telemovel);
        fflush(stdin);

        printf("\n Email do professor:\n >");
        gets(prof.email);

        //Guardar as informa��es dadas pelo utilizador num file
        fwrite(&prof,sizeof(prof),1,profins);

        //Adicionar outra pessoa
        textcolor(YELLOW);
        printf("\n Adicionar outra pessoa? 's' para sim, 'n' para n�o.");
        textcolor(LIGHTGRAY);
        outro = getch();
        system("cls");
    }
    fclose(profins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Ver professores
void verprof()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * profins;
    struct professor prof;

    //logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
 __      __         _____            __
 \ \    / /        |  __ \          / _|
  \ \  / /__ _ __  | |__) | __ ___ | |_ ___  ___ ___  ___  _ __ ___  ___
   \ \/ / _ \ '__| |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__/ _ \/ __|
    \  /  __/ |    | |   | | | (_) | ||  __/\__ \__ \ (_) | | |  __/\__ \
     \/ \___|_|    |_|   |_|  \___/|_| \___||___/___/\___/|_|  \___||___/

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n  Professor \t\t\t\t\t Telem�vel ");
    printf("\n--------------------------------------------------------------------\n");

    profins = fopen("professores.txt","rb+");
    //Ficheiro n�o encontrado
    if(profins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output dos Professores
    while(fread(&prof,sizeof(prof),1,profins) == 1)
    {
        printf("\n  %s \t\t\t\t\t %i", prof.nome, prof.telemovel);
    }
    fclose(profins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Procurar professores
void procurar2()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * profins;
    struct professor prof;
    char nome2[100];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _____                                       _____            __
 |  __ \                                     |  __ \          / _|
 | |__) | __ ___   ___ _   _ _ __ __ _ _ __  | |__) | __ ___ | |_ ___  ___ ___  ___  _ __
 |  ___/ '__/ _ \ / __| | | | '__/ _` | '__| |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__|
 | |   | | | (_) | (__| |_| | | | (_| | |    | |   | | | (_) | ||  __/\__ \__ \ (_) | |
 |_|   |_|  \___/ \___|\__,_|_|  \__,_|_|    |_|   |_|  \___/|_| \___||___/___/\___/|_|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Nome do procurado: ");
    gets(nome2);

    profins = fopen("professores.txt","rb+");
    //Ficheiro n�o escontrado
    if(profins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Procurar professor
    while(fread(&prof,sizeof(prof),1,profins) == 1)
    {
        if(strcmp(nome2,prof.nome) == 0)
        {
            //Logo
            system("cls");
            textcolor(LIGHTBLUE);
            printf(R"EOF(
  _____            __                           ______                       _                 _
 |  __ \          / _|                         |  ____|                     | |               | |
 | |__) | __ ___ | |_ ___  ___ ___  ___  _ __  | |__   _ __   ___ ___  _ __ | |_ _ __ __ _  __| | ___
 |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__| |  __| | '_ \ / __/ _ \| '_ \| __| '__/ _` |/ _` |/ _ \
 | |   | | | (_) | ||  __/\__ \__ \ (_) | |    | |____| | | | (_| (_) | | | | |_| | | (_| | (_| | (_) |
 |_|   |_|  \___/|_| \___||___/___/\___/|_|    |______|_| |_|\___\___/|_| |_|\__|_|  \__,_|\__,_|\___/

            )EOF");
            textcolor(LIGHTGRAY);

            //Output do professor encontrado
            printf("\n\n Nome do professor: %s \n", prof.nome);
            printf(" Data de nascimento do professor: %s \n", prof.nascimento);
            printf(" Morada: %s \n", prof.morada);
            printf(" Localidade e C�digo postal: %s \n", prof.local);
            printf(" N�mero de telem�vel do professor: %i \n", prof.telemovel);
            printf(" Email do professor: %s \n\n\n", prof.email);
        }
    }
    fclose(profins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Modificar as informa��es do professor
void modificar2()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * profins;
    struct professor prof;
    char nome2[100];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  __  __           _ _  __ _                  _____            __
 |  \/  |         | (_)/ _(_)                |  __ \          / _|
 | \  / | ___   __| |_| |_ _  ___ __ _ _ __  | |__) | __ ___ | |_ ___  ___ ___  ___  _ __
 | |\/| |/ _ \ / _` | |  _| |/ __/ _` | '__| |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__|
 | |  | | (_) | (_| | | | | | (_| (_| | |    | |   | | | (_) | ||  __/\__ \__ \ (_) | |
 |_|  |_|\___/ \__,_|_|_| |_|\___\__,_|_|    |_|   |_|  \___/|_| \___||___/___/\___/|_|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira o nome do professor que vai modificar: ");
    gets(nome2);

    profins = fopen("professores.txt","rb+");
    //Ficheiro n�o encontrado
    if(profins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    rewind(profins);
    fflush(stdin);

    //Perguntas de modifica��o
    while(fread(&prof,sizeof(prof),1,profins) == 1)
    {
        if(strcmp(nome2,prof.nome) == 0)
        {
            printf("\n Nome do professor:\n >");
            gets(prof.nome);

            printf("\n Data de nascimento do professor:\n Ex.:(03.03.2006)\n >");
            gets(prof.nascimento);

            printf("\n Morada:\n >");
            gets(prof.morada);

            printf("\n Localidade e C�digo postal:\n Ex.:(Lisboa - 2790-226)\n >");
            gets(prof.local);

            printf("\n N�mero de telem�vel do professor:\n >");
            scanf("%i",&prof.telemovel);
            fflush(stdin);

            printf("\n Email do professor:\n >");
            gets(prof.email);

            //Guardar as informa��es dadas pelo utilizador num file
            fseek(profins ,-sizeof(prof),SEEK_CUR);
            fwrite(&prof,sizeof(prof),1,profins);
            break;
        }
    }
    fclose(profins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Eleminar professores registrados na escola
void eleminar2()
{
    setlocale(LC_ALL,"Portuguese");
    char nome2[100];
    FILE * profins;
    FILE * fg;
    struct professor prof;

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  ______ _                _                    _____            __
 |  ____| |              (_)                  |  __ \          / _|
 | |__  | | ___ _ __ ___  _ _ __   __ _ _ __  | |__) | __ ___ | |_ ___  ___ ___  ___  _ __
 |  __| | |/ _ \ '_ ` _ \| | '_ \ / _` | '__| |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__|
 | |____| |  __/ | | | | | | | | | (_| | |    | |   | | | (_) | ||  __/\__ \__ \ (_) | |
 |______|_|\___|_| |_| |_|_|_| |_|\__,_|_|    |_|   |_|  \___/|_| \___||___/___/\___/|_|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira o nome do professor que vai eleminar: ");
    gets(nome2);

    profins = fopen("professores.txt","rb+");
    //Ficheiro n�o encontrado
    if(profins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    fg = fopen("temp2.txt","wb+");
    //Ficheiro n�o encontrado
    if(fg == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Processo de elemina��o de aluno
    while(fread(&prof,sizeof(prof),1,profins) == 1)
    {
        if(strcmp(nome2,prof.nome)!=0)
            fwrite(&prof,sizeof(prof),1,fg);
    }
    fclose(profins);
    fclose(fg);
    remove("professores.txt");
    rename("temp2.txt","professores.txt");

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

#endif // MENU_ADM_PROF_H_INCLUDED
