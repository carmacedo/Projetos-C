#ifndef MENU_ADM_H_INCLUDED
#define MENU_ADM_H_INCLUDED
//Headers
#include "menu_adm_prof.h"
#include "menu_aluno.h"
#include "menu_turmas.h"

//Vari�veis para o aluno e encarregado de educa��o
struct alunoo
{
    int telaluno, telee, id;
    char turma[5], nomealuno[100], nascimento[12], morada[80], local[40], emailaluno[60], nomeee[100], emailee[60];
};
struct alunoo aluno;

//Menu Administrador
void menu()
{
    int opcao;
    setlocale(LC_ALL,"Portuguese");

    //Logo
    textcolor(LIGHTBLUE);
    artt();
    textcolor(LIGHTGRAY);

    //Escolha de funcionalidade
    textcolor(YELLOW);
    printf("\n\t    [ ALUNOS ] \t\t\t [ PROFESSORES ] \t\t [ TURMAS ]\n");
    textcolor(LIGHTGRAY);
    printf("\n\t    [01] Adicionar aluno \t [06] Adicionar professor \t [11] Adicionar turma");
    printf("\n\t    [02] Procurar aluno  \t [07] Procurar professor  \t [12] Ver turmas");
    printf("\n\t    [03] Modificar aluno \t [08] Modificar professor \t [13] Modificar turmas");
    printf("\n\t    [04] Eleminar aluno  \t [09] Eleminar professor  \t [14] Eleminar turma");
    printf("\n\t    [05] Ver alunos      \t [10] Ver professores");
    textcolor(LIGHTRED);
    printf("\n\n\t    [0] Sair de Administrador \t\t\t\t\t [99] Fechar\n");
    textcolor(LIGHTGRAY);
    printf("\t    >");

    scanf("%i", &opcao);
    fflush(stdin);

    switch(opcao)
    {
        case 1:
        //Adicionar aluno
        add();
        break;

        case 2:
        //Procurar aluno
        procurar();
        break;

        case 3:
        //Modificar aluno
        modificar();
        break;

        case 4:
        //Eleminar aluno
        eleminar();
        break;

        case 5:
        //Ver alunos
        veraluno();
        break;

        case 6:
        //Adicionar professor
        add2();
        break;

        case 7:
        //Procurar professor
        procurar2();
        break;

        case 8:
        //Modificar professor
        modificar2();
        break;

        case 9:
        //Eleminar professor
        eleminar2();
        break;

        case 10:
        //Ver professores
        verprof();
        break;

        case 11:
        //Adicionar turma
        add3();
        break;

        case 12:
        //Ver turmas
        ver();
        break;

        case 13:
        //Modificar turmas
        modificar3();
        break;

        case 14:
        //Eleminar turmas
        eleminar3();
        break;

        case 0:
        //Voltar ao menu principal
        system("cls");
        main();
        break;

        case 99:
        //Sair
        exit(1);
        break;

        default:
        //Op��o Inv�lida
        textcolor(RED);
        printf("\n\n [ERRO]\n Op��o Inv�lida!");
        textcolor(YELLOW);
        printf("\n\n Prime qualquer tecla para continuar. \n\n");
        textcolor(LIGHTGRAY);
        getch();
        system("cls");
        menu();
        break;
        }
    }

//Registrador de alunos
void add()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * alunoins;
    struct alunoo aluno;
    char outro = 's';

    alunoins=fopen("alunos.txt","ab+");
    //Ficheiro n�o encontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    fflush(stdin);

    //Ciclo de repeti��o se no final for premida a tecla 's'
    while(outro == 's')
    {
        //Logo
        system("cls");
        textcolor(LIGHTBLUE);
        printf(R"EOF(
  ______ _      _                 _        _____                     _      /\/|
 |  ____(_)    | |               | |      |_   _|                   (_)    |/\/
 | |__   _  ___| |__   __ _    __| | ___    | |  _ __  ___  ___ _ __ _  ___ __ _  ___
 |  __| | |/ __| '_ \ / _` |  / _` |/ _ \   | | | '_ \/ __|/ __| '__| |/ __/ _` |/ _ \
 | |    | | (__| | | | (_| | | (_| |  __/  _| |_| | | \__ \ (__| |  | | (_| (_| | (_) |
 |_|    |_|\___|_| |_|\__,_|  \__,_|\___| |_____|_| |_|___/\___|_|  |_|\___\__,_|\___/
                                                                        )_)
        )EOF");
        textcolor(LIGHTGRAY);

        //Input de informa��es
        printf("\n Nome do aluno:\n >");
        gets(aluno.nomealuno);

        printf("\n Data de nascimento do aluno:\n Ex.:(03.03.2006)\n >");
        gets(aluno.nascimento);

        printf("\n Morada:\n >");
        gets(aluno.morada);

        printf("\n Localidade e C�digo postal:\n Ex.:(Lisboa - 2790-226)\n >");
        gets(aluno.local);

        printf("\n N�mero de telem�vel do aluno:\n >");
        scanf("%i",&aluno.telaluno);
        fflush(stdin);

        printf("\n Email do aluno:\n >");
        gets(aluno.emailaluno);

        printf("\n Nome do Encarregado de Educa��o:\n >");
        gets(aluno.nomeee);

        printf("\n N�mero de telem�vel do Encarregado de Educa��o:\n >");
        scanf("%i",&aluno.telee);
        fflush(stdin);

        printf("\n Email do Encarregado de Educa��o:\n >");
        gets(aluno.emailee);

        printf("\n Insira um n�mero de identifica��o para o aluno:\n >");
        scanf("%i", &aluno.id);
        fflush(stdin);

        printf("\n Insira a turma do aluno:\n >");
        gets(aluno.turma);

        //Guardar as informa��es dadas pelo utilizador num file
        fwrite(&aluno,sizeof(aluno),1,alunoins);

        //Adicionar outra pessoa
        textcolor(CYAN);
        printf("\n Adicionar outra pessoa? 's' para sim, 'n' para n�o.");
        textcolor(LIGHTGRAY);
        outro = getch();
        system("cls");
    }
    fclose(alunoins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Procurar alunos na base de dados
void procurar()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * alunoins;
    struct alunoo aluno;
    char nome2[100];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _____                                                _
 |  __ \                                         /\   | |
 | |__) | __ ___   ___ _   _ _ __ __ _ _ __     /  \  | |_   _ _ __   ___
 |  ___/ '__/ _ \ / __| | | | '__/ _` | '__|   / /\ \ | | | | | '_ \ / _ \
 | |   | | | (_) | (__| |_| | | | (_| | |     / ____ \| | |_| | | | | (_) |
 |_|   |_|  \___/ \___|\__,_|_|  \__,_|_|    /_/    \_\_|\__,_|_| |_|\___/
    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Nome do procurado: ");
    gets(nome2);

    alunoins = fopen("alunos.txt","rb+");
    //Ficheiro n�o encontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Escrita na consola das informa��es do aluno encontrado
    while(fread(&aluno,sizeof(aluno),1,alunoins ) == 1)
    {
        if(strcmp(nome2,aluno.nomealuno) == 0)
        {
            //Logo
            system("cls");
            textcolor(CYAN);
            printf(R"EOF(
           _                     ______                       _                 _
     /\   | |                   |  ____|                     | |               | |
    /  \  | |_   _ _ __   ___   | |__   _ __   ___ ___  _ __ | |_ _ __ __ _  __| | ___
   / /\ \ | | | | | '_ \ / _ \  |  __| | '_ \ / __/ _ \| '_ \| __| '__/ _` |/ _` |/ _ \
  / ____ \| | |_| | | | | (_) | | |____| | | | (_| (_) | | | | |_| | | (_| | (_| | (_) |
 /_/    \_\_|\__,_|_| |_|\___/  |______|_| |_|\___\___/|_| |_|\__|_|  \__,_|\__,_|\___/
            )EOF");
            textcolor(LIGHTGRAY);

            //Output das informa��es do aluno encontrado
            printf("\n\n Nome do aluno: %s\n", aluno.nomealuno);
            printf(" Data de nascimento do aluno: %s\n", aluno.nascimento);
            printf(" Morada: %s\n", aluno.morada);
            printf(" Localidade e C�digo postal: %s\n", aluno.local);
            printf(" N�mero de telem�vel do aluno: %i\n", aluno.telaluno);
            printf(" Email do aluno: %s\n\n\n", aluno.emailaluno);
            printf(" N�mero: %i\n", aluno.id);
            printf(" Turma: %s\n\n\n", aluno.turma);
            printf(" Nome do Encarregado de Educa��o: %s\n", aluno.nomeee);
            printf(" N�mero de telem�vel do Encarregado de Educa��o: %i\n", aluno.telee);
            printf(" Email do Encarregado de Educa��o: %s\n\n", aluno.emailee);
        }
    }
    fclose(alunoins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Ver alunos
void veraluno()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * alunoins;
    struct alunoo aluno;

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
 __      __                  _
 \ \    / /            /\   | |
  \ \  / /__ _ __     /  \  | |_   _ _ __   ___  ___
   \ \/ / _ \ '__|   / /\ \ | | | | | '_ \ / _ \/ __|
    \  /  __/ |     / ____ \| | |_| | | | | (_) \__ \
     \/ \___|_|    /_/    \_\_|\__,_|_| |_|\___/|___/

    )EOF");
    textcolor(LIGHTGRAY);

    //Output de "Tabela"
    printf("\n\n Aluno\t\t\tTurma\t\t\t\t\tN�mero");
    printf("\n--------------------------------------------------------------------\n");

    alunoins = fopen("alunos.txt","rb+");
    //Ficheiro n�o encontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output dos Alunos
    while(fread(&aluno,sizeof(aluno),1,alunoins) == 1)
    {
        printf("\n %s\t\t\t%s\t\t\t\t\t%i", aluno.nomealuno, aluno.turma, aluno.id);
    }
    fclose(alunoins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Modificar as informa��es de um aluno inscrito
void modificar()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * alunoins;
    struct alunoo aluno;
    char nome2[100];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  __  __           _ _  __ _                           _
 |  \/  |         | (_)/ _(_)                    /\   | |
 | \  / | ___   __| |_| |_ _  ___ __ _ _ __     /  \  | |_   _ _ __   ___
 | |\/| |/ _ \ / _` | |  _| |/ __/ _` | '__|   / /\ \ | | | | | '_ \ / _ \
 | |  | | (_) | (_| | | | | | (_| (_| | |     / ____ \| | |_| | | | | (_) |
 |_|  |_|\___/ \__,_|_|_| |_|\___\__,_|_|    /_/    \_\_|\__,_|_| |_|\___/

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira o nome do aluno que vai modificar: ");
    gets(nome2);

    alunoins = fopen("alunos.txt","rb+");
    //Ficheiro n�o encontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    rewind(alunoins);
    fflush(stdin);

    //Repeti��o de perguntas de inscri��o de aluno
    while(fread(&aluno,sizeof(aluno),1,alunoins) == 1)
    {
        if(strcmp(nome2,aluno.nomealuno) == 0)
        {
            printf("\n Nome do aluno:\n >");
            gets(aluno.nomealuno);

            printf("\n Data de nascimento do aluno:\n Ex.:(03.03.2006)\n >");
            gets(aluno.nascimento);

            printf("\n Morada:\n >");
            gets(aluno.morada);

            printf("\n Localidade e C�digo postal:\n Ex.:(Lisboa - 2790-226)\n >");
            gets(aluno.local);

            printf("\n N�mero de telem�vel do aluno:\n >");
            scanf("%i",&aluno.telaluno);
            fflush(stdin);

            printf("\n Email do aluno:\n >");
            gets(aluno.emailaluno);

            printf("\n Nome do Encarregado de Educa��o:\n >");
            gets(aluno.nomeee);

            printf("\n N�mero de telem�vel do Encarregado de Educa��o:\n >");
            scanf("%i",&aluno.telee);
            fflush(stdin);

            printf("\n Email do Encarregado de Educa��o:\n >");
            gets(aluno.emailee);

            printf("\n Insira um n�mero de identifica��o para o aluno:\n >");
            scanf("%i", &aluno.id);
            fflush(stdin);

            printf("\n Insira a turma do aluno:\n >");
            gets(aluno.turma);

            //Guardar as informa��es dadas pelo utilizador num file
            fseek(alunoins ,-sizeof(aluno),SEEK_CUR);
            fwrite(&aluno,sizeof(aluno),1,alunoins);
            break;
        }
    }
    fclose(alunoins);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Eleminar alunos registrados na escola
void eleminar()
{
    setlocale(LC_ALL,"Portuguese");
    char nome2[100];
    FILE * alunoins;
    FILE * ft;
    struct alunoo aluno;

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  ______ _                _                             _
 |  ____| |              (_)                      /\   | |
 | |__  | | ___ _ __ ___  _ _ __   __ _ _ __     /  \  | |_   _ _ __   ___
 |  __| | |/ _ \ '_ ` _ \| | '_ \ / _` | '__|   / /\ \ | | | | | '_ \ / _ \
 | |____| |  __/ | | | | | | | | | (_| | |     / ____ \| | |_| | | | | (_) |
 |______|_|\___|_| |_| |_|_|_| |_|\__,_|_|    /_/    \_\_|\__,_|_| |_|\___/

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira o nome do aluno que vai eleminar: ");
    gets(nome2);

    alunoins = fopen("alunos.txt","rb+");
    //Ficheiro n�o encontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    ft = fopen("temp.txt","wb+");
    //Ficheiro n�o encontrado
    if(ft == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Processo de elemina��o do aluno da base de dados
    while(fread(&aluno,sizeof(aluno),1,alunoins) == 1)
    {
        if(strcmp(nome2,aluno.nomealuno)!=0)
            fwrite(&aluno,sizeof(aluno),1,ft);
    }
    fclose(alunoins);
    fclose(ft);
    remove("alunos.txt");
    rename("temp.txt","alunos.txt");

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//SCHOOL ASSISTENT
void artt()
{
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _____   __  __ __   ___    ___   _           ____  _____ _____ ____ _____ ______    ___  ____   ______
 / ___/  /  ]|  |  | /   \  /   \ | |         /    |/ ___// ___/|    / ___/|      |  /  _]|    \ |      |
(   \_  /  / |  |  ||     ||     || |        |  o  (   \_(   \_  |  (   \_ |      | /  [_ |  _  ||      |
 \__  |/  /  |  _  ||  O  ||  O  || |___     |     |\__  |\__  | |  |\__  ||_|  |_||    _]|  |  ||_|  |_|
 /  \ /   \_ |  |  ||     ||     ||     |    |  _  |/  \ |/  \ | |  |/  \ |  |  |  |   [_ |  |  |  |  |
 \    \     ||  |  ||     ||     ||     |    |  |  |\    |\    | |  |\    |  |  |  |     ||  |  |  |  |
  \___|\____||__|__| \___/  \___/ |_____|    |__|__| \___| \___||____|\___|  |__|  |_____||__|__|  |__|

 ------------------------------------------ [ adminstrador ] --------------------------------------------
    )EOF");
    textcolor(LIGHTGRAY);
}

//Faltas
void xfaltas()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * alunoins;
    struct alunoo aluno;
    char nome2[100];
    int opcao;

    printf("\n\n Insira o nome de um aluno:\n >");
    gets(nome2);

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  ______    _ _
 |  ____|  | | |
 | |__ __ _| | |_ __ _ ___
 |  __/ _` | | __/ _` / __|
 | | | (_| | | || (_| \__ \
 |_|  \__,_|_|\__\__,_|___/

    )EOF");
    textcolor(LIGHTGRAY);

    alunoins = fopen("alunos.txt","rb+");
    //Ficheiro n�o escontrado
    if(alunoins == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Procurar se existe algum aluno com o devido nome
    while(fread(&aluno,sizeof(aluno),1,alunoins) == 1)
    {
        if(strcmp(nome2,aluno.nomealuno) == 0)
        {
            textcolor(LIGHTGREEN);
            printf("\n\n Aluno %s encontrado!", aluno.nomealuno);
            textcolor(LIGHTGRAY);
            printf("\n N�mero: %i\n", aluno.id);
            printf("\n [1] Marcar falta de atraso\n [2] Marcar falta de material\n [3] Marcar falta de presen�a\n [4] Marcar falta disciplinar\n >");
            scanf("%i", &opcao);
            fflush(stdin);

            switch(opcao)
            {
                case 1:
                textcolor(LIGHTGREEN);
                printf("\n\n [SUCESSO]\n Falta de atraso marcada!\n");
                textcolor(LIGHTGRAY);
                break;

                case 2:
                textcolor(LIGHTGREEN);
                printf("\n\n [SUCESSO]\n Falta de material marcada!\n");
                textcolor(LIGHTGRAY);
                break;

                case 3:
                textcolor(LIGHTGREEN);
                printf("\n\n [SUCESSO]\n Falta de presen�a marcada!\n");
                textcolor(LIGHTGRAY);
                break;

                case 4:
                textcolor(LIGHTGREEN);
                printf("\n\n [SUCESSO]\n Falta disciplinar marcada!\n");
                textcolor(LIGHTGRAY);
                break;

                default:
                //Op��o Inv�lida
                textcolor(RED);
                printf("\n\n [ERRO]\n Op��o Inv�lida!");
                textcolor(YELLOW);
                printf("\n\n Prime qualquer tecla para continuar. \n\n");
                textcolor(LIGHTGRAY);
                getch();
                system("cls");
                mainprof();
                break;
            }

            //Continuar
            textcolor(YELLOW);
            printf("\n Pressiona uma tecla para continuar. \n\n");
            textcolor(LIGHTGRAY);
            getch();
            system("cls");
            mainprof();
        }
    }
}
#endif // MENU_ADM_H_INCLUDED
