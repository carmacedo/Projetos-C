//Bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <conio.c>
#include <windows.h>
//Headers
#include "menu_adm.h"
#include "menu_aluno.h"
#include "menu_prof.h"

//Vari�veis para o menu principal
struct mainmenu
{
    int opcao1, opcaoadm;
    char adm_user[5], adm_senha[3];
};

//Menu principal
void main()
{
    setlocale(LC_ALL,"Portuguese");
    struct mainmenu menup;

    //Logo
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _____   __  __ __   ___    ___   _           ____  _____ _____ ____ _____ ______    ___  ____   ______
 / ___/  /  ]|  |  | /   \  /   \ | |         /    |/ ___// ___/|    / ___/|      |  /  _]|    \ |      |
(   \_  /  / |  |  ||     ||     || |        |  o  (   \_(   \_  |  (   \_ |      | /  [_ |  _  ||      |
 \__  |/  /  |  _  ||  O  ||  O  || |___     |     |\__  |\__  | |  |\__  ||_|  |_||    _]|  |  ||_|  |_|
 /  \ /   \_ |  |  ||     ||     ||     |    |  _  |/  \ |/  \ | |  |/  \ |  |  |  |   [_ |  |  |  |  |
 \    \     ||  |  ||     ||     ||     |    |  |  |\    |\    | |  |\    |  |  |  |     ||  |  |  |  |
  \___|\____||__|__| \___/  \___/ |_____|    |__|__| \___| \___||____|\___|  |__|  |_____||__|__|  |__|
    )EOF");
    textcolor(LIGHTGRAY);

    //Escolha de utilizador
    printf("\n [1] Entrar como Professor\n [2] Entrar como Administrador\n");
    textcolor(LIGHTRED);
    printf(" [0] Fechar\n");
    textcolor(LIGHTGRAY);
    printf(" >");

    scanf("%i",&menup.opcao1);
    fflush(stdin);
    system("cls");

    switch(menup.opcao1)
    {
        case 0:
        //Sair
        exit(1);
        break;

        case 1:
        //Entrar como professor
        loginprof();
        break;

        case 2:
        //Entrar como administrador
        loginadm();
        break;

        default:
        //Op��o Inv�lida
        textcolor(RED);
        printf("\n\n [ERRO]\n Op��o Inv�lida!");
        textcolor(YELLOW);
        printf("\n\n Prime qualquer tecla para continuar. \n\n");
        textcolor(LIGHTGRAY);
        getch();
        system("cls");
        main();
        break;
    }
}

//Login como administrador
void loginadm()
{
        struct mainmenu menup;
        char id[10], pass[10];

        //Logo
        textcolor(LIGHTBLUE);
        printf(R"EOF(
  _                 _                  _____  __  __
 | |               (_)           /\   |  __ \|  \/  |
 | |     ___   __ _ _ _ __      /  \  | |  | | \  / |
 | |    / _ \ / _` | | '_ \    / /\ \ | |  | | |\/| |
 | |___| (_) | (_| | | | | |  / ____ \| |__| | |  | |
 |______\___/ \__, |_|_| |_| /_/    \_\_____/|_|  |_|
               __/ |
              |___/
        )EOF");
        textcolor(LIGHTGRAY);

        //Input de informa��es
        rept:
        printf("\n Insira o nome de utilizador:\n >");
        gets(id);
        printf(" Insira a palavra-pass:\n >");

        //Esconder senha inserida
        int p=0;
        do
        {
            pass[p]=getch();
            if(pass[p]!='\r')
            {
                printf("*");
            }
            p++;
        }while(pass[p-1]!='\r');
        pass[p-1]='\0';

        //Sistema login com user e senha pre-definidos
        if (strcmp(id,"admin")==0)
        {
            if(strcmp(pass,"123")==0)
            {
                system("cls");
                menu();
            }
            //Senha errada
            else
            {
                system("cls");
                textcolor(RED);
                printf("\n\n [ERRO]\n Senha ou User incorretos!\n");
                textcolor(LIGHTGRAY);
                goto rept;
            }
        }
        //User errado
        else
        {
            system("cls");
            textcolor(RED);
            printf("\n\n [ERRO]\n Senha ou User incorretos!\n");
            textcolor(LIGHTGRAY);
            goto rept;
        }
}
