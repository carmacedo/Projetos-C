#ifndef MENU_ALUNO_H_INCLUDED
#define MENU_ALUNO_H_INCLUDED

void mainaluno()
{
    int opcao;
    printf("\n [1] Notas\n [2] Testes\n [3] Faltas\n [4] Eventos\n [5] Pagar mensalidade\n [6] Informa��es pessoais\n >");
    scanf("%i", &opcao);
    switch(opcao)
    {
        case 1:
        break;
        case 2:
        break;
        case 3:
        break;
        case 4:
        break;
        case 5:
        break;
        case 6:
        break;
        default:printf("\n\n [ERRO]\n Op��o Inv�lida!\n");break;
    }
}



#endif // MENU_ALUNO_H_INCLUDED
