#ifndef MENU_TURMAS_H_INCLUDED
#define MENU_TURMAS_H_INCLUDED

//Vari�veis das turmas
struct turmas
{
    char nome[20], ano[5], curso[10];
};
struct turmas turma;

//Adicionar turma
void add3()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * turmains;
    struct turmas turma;
    char outro = 's';

    turmains=fopen("turmas.txt","ab+");
    //Ficheiro n�o encontrado
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    fflush(stdin);

    //Ciclo de repeti��o se no final for premida a tecla 's'
    while(outro == 's')
    {
        system("cls");
        textcolor(LIGHTBLUE);
        printf(R"EOF(
              _ _      _                          _______
     /\      | (_)    (_)                        |__   __|
    /  \   __| |_  ___ _  ___  _ __   __ _ _ __     | |_   _ _ __ _ __ ___   __ _
   / /\ \ / _` | |/ __| |/ _ \| '_ \ / _` | '__|    | | | | | '__| '_ ` _ \ / _` |
  / ____ \ (_| | | (__| | (_) | | | | (_| | |       | | |_| | |  | | | | | | (_| |
 /_/    \_\__,_|_|\___|_|\___/|_| |_|\__,_|_|       |_|\__,_|_|  |_| |_| |_|\__,_|

        )EOF");
        textcolor(LIGHTGRAY);

        //Input de informa��es
        printf("\n D� um nome � turma:\n >");
        gets(turma.nome);

        printf("\n Insira o ano escolar da turma:\n >");
        gets(turma.ano);

        printf("\n Curso da turma:\n >");
        gets(turma.curso);

        //Guardar as informa��es dadas pelo utilizador num file
        fwrite(&turma,sizeof(turma),1,turmains);

        //Adicionar outra turma
        textcolor(CYAN);
        printf("\n Adicionar outra turma? 's' para sim, 'n' para n�o.");
        textcolor(LIGHTGRAY);
        outro = getch();
        system("cls");
    }
    fclose(turmains);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Ver turmas
void ver()
{
    FILE * turmains;
    struct turmas turma;
    setlocale(LC_ALL,"Portuguese");

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
 __      __         _______
 \ \    / /        |__   __|
  \ \  / /__ _ __     | |_   _ _ __ _ __ ___   __ _
   \ \/ / _ \ '__|    | | | | | '__| '_ ` _ \ / _` |
    \  /  __/ |       | | |_| | |  | | | | | | (_| |
     \/ \___|_|       |_|\__,_|_|  |_| |_| |_|\__,_|

    )EOF");
    textcolor(LIGHTGRAY);

    //"Tabela" das turmas registradas na escola
    printf("\n\n Turma \t\t\t Curso  \t\t    Ano escolar");
    printf("\n--------------------------------------------------------------------\n");

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o encontrado (n�o h� turmas)
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ainda n�o h� turmas registradas!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output das turmas registradas na escola
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        printf("\n  %s \t\t\t %s \t\t\t    %s", turma.nome, turma.curso, turma.ano);
    }
    fclose(turmains);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Modificar turmas
void modificar3()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * turmains;
    struct turmas turma;
    char nome2[100];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  __  __           _ _  __ _                  _______
 |  \/  |         | (_)/ _(_)                |__   __|
 | \  / | ___   __| |_| |_ _  ___ __ _ _ __     | |_   _ _ __ _ __ ___   __ _
 | |\/| |/ _ \ / _` | |  _| |/ __/ _` | '__|    | | | | | '__| '_ ` _ \ / _` |
 | |  | | (_) | (_| | | | | | (_| (_| | |       | | |_| | |  | | | | | | (_| |
 |_|  |_|\___/ \__,_|_|_| |_|\___\__,_|_|       |_|\__,_|_|  |_| |_| |_|\__,_|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira a turma que vai modificar: ");
    gets(nome2);

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o encontrado
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    rewind(turmains);
    fflush(stdin);

    //Repeti��o de perguntas de inscri��o de aluno
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        if(strcmp(nome2,turma.nome) == 0)
        {
            //Input de informa��es
            printf("\n D� um nome � turma:\n >");
            gets(turma.nome);

            printf("\n Insira o ano escolar da turma:\n >");
            gets(turma.ano);

            printf("\n Curso da turma:\n >");
            gets(turma.curso);

            //Guardar as informa��es dadas pelo utilizador num file
            fseek(turmains ,-sizeof(turma),SEEK_CUR);
            fwrite(&turma,sizeof(turma),1,turmains);
            break;
        }
    }
    fclose(turmains);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

//Eleminar turmas
void eleminar3()
{
    setlocale(LC_ALL,"Portuguese");
    char nome2[100];
    FILE * turmains;
    FILE * fu;
    struct turmas turma;
    system("cls");

    //Logo
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  ______ _                _                    _______
 |  ____| |              (_)                  |__   __|
 | |__  | | ___ _ __ ___  _ _ __   __ _ _ __     | |_   _ _ __ _ __ ___   __ _
 |  __| | |/ _ \ '_ ` _ \| | '_ \ / _` | '__|    | | | | | '__| '_ ` _ \ / _` |
 | |____| |  __/ | | | | | | | | | (_| | |       | | |_| | |  | | | | | | (_| |
 |______|_|\___|_| |_| |_|_|_| |_|\__,_|_|       |_|\__,_|_|  |_| |_| |_|\__,_|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira o nome da turma que vai eleminar: ");
    gets(nome2);

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o encontrado
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    fu = fopen("temp3.txt","wb+");
    //Ficheiro n�o encontrado
    if(fu == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    //Eleminar aluno
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        if(strcmp(nome2,turma.nome)!=0)
            fwrite(&turma,sizeof(turma),1,fu);
    }
    fclose(turmains);
    fclose(fu);
    remove("turmas.txt");
    rename("temp3.txt","turmas.txt");

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    menu();
}

#endif // MENU_TURMAS_H_INCLUDED
