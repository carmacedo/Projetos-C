#ifndef MENU_PROF_H_INCLUDED
#define MENU_PROF_H_INCLUDED
//Headers
#include "menu_turmas.h"
#include "menu_adm.h"

//Vari�veis do professor
struct professorr
{
    int opcao;
};
struct professorr proff;

//Vari�veis de testes
struct testess
{
    char data[12], disciplina[20], nome[20], id[5], turma[15];
    int nota;
};
struct testess teste;


//Main prof
mainprof()
{
        //Logo
        textcolor(LIGHTBLUE);
        printf(R"EOF(
  _____   __  __ __   ___    ___   _           ____  _____ _____ ____ _____ ______    ___  ____   ______
 / ___/  /  ]|  |  | /   \  /   \ | |         /    |/ ___// ___/|    / ___/|      |  /  _]|    \ |      |
(   \_  /  / |  |  ||     ||     || |        |  o  (   \_(   \_  |  (   \_ |      | /  [_ |  _  ||      |
 \__  |/  /  |  _  ||  O  ||  O  || |___     |     |\__  |\__  | |  |\__  ||_|  |_||    _]|  |  ||_|  |_|
 /  \ /   \_ |  |  ||     ||     ||     |    |  _  |/  \ |/  \ | |  |/  \ |  |  |  |   [_ |  |  |  |  |
 \    \     ||  |  ||     ||     ||     |    |  |  |\    |\    | |  |\    |  |  |  |     ||  |  |  |  |
  \___|\____||__|__| \___/  \___/ |_____|    |__|__| \___| \___||____|\___|  |__|  |_____||__|__|  |__|

------------------------------------ [ professor ] ------------------------------------------------------
        )EOF");
        textcolor(LIGHTGRAY);

        //Output de funcionalidades
        printf("\n [1] Turmas\n [2] Faltas de alunos\n [3] Testes\n [4] Notas\n");
        textcolor(YELLOW);
        printf("\n [5] Estacinamento");
        textcolor(LIGHTRED);
        printf("\n\n [0] Sair de Professor \t\t\t\t\t [99] Fechar\n");
        textcolor(LIGHTGRAY);
        printf(" >");

        scanf("%i", &proff.opcao);
        fflush(stdin);

        switch(proff.opcao)
        {
            case 1:
            //Funcionalidades de turmas
            ver2();
            break;

            case 2:
            //Ver e marcar faltas de alunos
            turmas();
            break;

            case 3:
            //Ver, marcar e eleminar testes
            dectest();
            break;

            case 4:
            //Notas
            system("cls");
            notas();
            break;

            case 5:
            //Estacionamento
            estacionamento();
            break;

            case 0:
            //Voltar ao menu principal
            system("cls");
            main();
            break;

            case 99:
            //Sair
            exit(1);
            break;

            default:
            //Op��o Inv�lida
            textcolor(RED);
            printf("\n\n [ERRO]\n Op��o Inv�lida!");
            textcolor(YELLOW);
            printf("\n\n Prime qualquer tecla para continuar. \n\n");
            textcolor(LIGHTGRAY);
            getch();
            system("cls");
            mainprof();
            break;
        }
}

//Ver turmas
void ver2()
{
    FILE * turmains;
    struct turmas turma;
    setlocale(LC_ALL,"Portuguese");

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
 __      __         _______
 \ \    / /        |__   __|
  \ \  / /__ _ __     | |_   _ _ __ _ __ ___   __ _
   \ \/ / _ \ '__|    | | | | | '__| '_ ` _ \ / _` |
    \  /  __/ |       | | |_| | |  | | | | | | (_| |
     \/ \___|_|       |_|\__,_|_|  |_| |_| |_|\__,_|

    )EOF");
    textcolor(LIGHTGRAY);

    //"Tabela" das turmas registradas na escola
    printf("\n\n Turma \t\t\t Curso  \t\t    Ano escolar");
    printf("\n--------------------------------------------------------------------\n");

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o encontrado (n�o h� turmas)
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ainda n�o h� turmas registradas!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output das turmas registradas na escola
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        printf("\n  %s \t\t\t %s \t\t\t    %s", turma.nome, turma.curso, turma.ano);
    }
    fclose(turmains);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}


//Estacionamento para professores com fatura
void estacionamento()
{
    FILE * estaci;
    int est, preco=0, mes=0;
    char estmail[30];
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  ______     _             _                                        _
 |  ____|   | |           (_)                                      | |
 | |__   ___| |_ __ _  ___ _  ___  _ __   __ _ _ __ ___   ___ _ __ | |_ ___
 |  __| / __| __/ _` |/ __| |/ _ \| '_ \ / _` | '_ ` _ \ / _ \ '_ \| __/ _ \
 | |____\__ \ || (_| | (__| | (_) | | | | (_| | | | | | |  __/ | | | || (_) |
 |______|___/\__\__,_|\___|_|\___/|_| |_|\__,_|_| |_| |_|\___|_| |_|\__\___/

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n\t Adquira o seu passe de estacionamento na garagem da escola:\n");
    printf("\n\t [1] 1 m�s == 10e \t [3] 6 meses == 45e");
    printf("\n\t [2] 3 meses == 25e\t [4] 12 meses == 70e");
    textcolor(LIGHTRED);
    printf("\n\n\t [0] Voltar\n");
    textcolor(LIGHTGRAY);
    printf("\t >");
    scanf("%i",&est);
    fflush(stdin);
    switch(est)
    {
        case 1:
        preco=preco+10;
        mes=mes+1;
        break;
        case 2:
        preco=preco+25;
        mes=mes+3;
        break;
        case 3:
        preco=preco+45;
        mes=mes+6;
        break;
        case 4:
        preco=preco+70;
        mes=mes+12;
        break;
        case 0:
        break;
        default:
        //Op��o Inv�lida
        textcolor(RED);
        printf("\n\n [ERRO]\n Op��o Inv�lida!");
        textcolor(YELLOW);
        printf("\n\n Prime qualquer tecla para continuar. \n\n");
        textcolor(LIGHTGRAY);
        getch();
        system("cls");
        mainprof();
        break;
    }
    printf("\n\n Insira o seu email:\n >");
    gets(estmail);

    estaci = fopen("fatura.txt", "w+");
    fprintf(estaci, "+-------------------------------+\n");
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "|        SCHOOL ASSISTENT       |\n");
    fprintf(estaci, "|         Estacionamento        |\n");
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "|   Plano Ativo         Total   |\n");
    fprintf(estaci, "|   -------------------------   |\n");
    fprintf(estaci, "|    %i meses            %ie     |\n", mes, preco);
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "|          ------------         |\n");
    fprintf(estaci, "|     Foi lhe enviado para o    |\n");
    fprintf(estaci, "|     email um comprovativo.    |\n");
    fprintf(estaci, "        %s                       \n", estmail);
    fprintf(estaci, "|          ------------         |\n");
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "|   Obrigado pela sua compra!   |\n");
    fprintf(estaci, "|                               |\n");
    fprintf(estaci, "+-------------------------------+\n");
    fprintf(estaci, "\n\n");
    fclose(estaci);

    textcolor(LIGHTGREEN);
    printf("\n\n Obrigado pela sua compra, foi imprimida uma fatura\n");
    textcolor(YELLOW);
    printf("\t\t Prima Enter para continuar...");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}

//Ordena��o de notas usando vetores
void notas()
{
    int vetor[100], nalunos, c, d, posicao, t;

    textcolor(LIGHTBLUE);
    printf(R"EOF(
   ____          _                       /\/|         _____         _   _       _
  / __ \        | |                     |/\/         |  __ \       | \ | |     | |
 | |  | |_ __ __| | ___ _ __   __ _  ___ __ _  ___   | |  | | ___  |  \| | ___ | |_ __ _ ___
 | |  | | '__/ _` |/ _ \ '_ \ / _` |/ __/ _` |/ _ \  | |  | |/ _ \ | . ` |/ _ \| __/ _` / __|
 | |__| | | | (_| |  __/ | | | (_| | (_| (_| | (_) | | |__| |  __/ | |\  | (_) | || (_| \__ \
  \____/|_|  \__,_|\___|_| |_|\__,_|\___\__,_|\___/  |_____/ \___| |_| \_|\___/ \__\__,_|___/
                                     )_)
    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n Quantos alunos vai ordenar?\n >");
    scanf("%i", &nalunos);
    fflush(stdin);

    printf("\n Insira uma nota para cada um dos %i alunos\n", nalunos);

    for (c = 0; c < nalunos; c++)
        scanf("%i", &vetor[c]);

        //Encontra o elemento m�nimo
        for (c = 0; c < (nalunos - 1); c++)
        {
            posicao = c;

            for (d = c + 1; d < nalunos; d++)
            {
            if (vetor[posicao] > vetor[d])
                posicao = d;
            }
            if (posicao != c)
            {
                t = vetor[c];
                vetor[c] = vetor[posicao];
                vetor[posicao] = t;
            }
        }

        textcolor(LIGHTGREEN);
        printf("\n\n [SUCESSO]\n Notas ordenadas!\n");
        textcolor(LIGHTGRAY);

        for (c = 0; c < nalunos; c++)
            printf(" � %i\n", vetor[c]);

        textcolor(YELLOW);
        printf("\n\n Prime qualquer tecla para continuar. \n\n");
        textcolor(LIGHTGRAY);
        getch();
        system("cls");
        mainprof();
}

//Decis�o Testes
void dectest()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * turmains;
    FILE * alunoins;
    struct turmas turma;
    struct alunoo aluno;
    int opcao;
    char nome3[100];

    printf("\n Insira uma turma registrada da escola:\n >");
    gets(nome3);

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o escontrado
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Procura se a turma inserida pelo utilizador � v�lida
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        if(strcmp(nome3,turma.nome) == 0)
        {
            printf("\n [1] Marcar Teste\n [2] Desmarcar Teste\n [3] Ver Testes\n");
            textcolor(LIGHTRED);
            printf(" [0] Voltar\n");
            textcolor(LIGHTGRAY);
            printf(" >");

            scanf("%i", &opcao);
            fflush(stdin);

            switch(opcao)
            {
                case 1:
                //Marcar teste
                mteste();
                break;

                case 2:
                //Desmarcar teste
                dteste();
                break;

                case 3:
                //Ver testes
                vertestes();
                break;

                case 0:
                //Voltar
                system("cls");
                mainprof();
                break;

                default:
                textcolor(RED);
                printf("\n\n [ERRO]\n Op��o Inv�lida!");
                textcolor(YELLOW);
                printf("\n\n Prime qualquer tecla para continuar. \n\n");
                textcolor(LIGHTGRAY);
                getch();
                system("cls");
                mainprof();
                break;
            }
        }
    }
    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}

//Aba turmas
void turmas()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * turmains;
    FILE * alunoins;
    struct turmas turma;
    struct alunoo aluno;
    char nome2[15], nome3[50];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _______
 |__   __|
    | |_   _ _ __ _ __ ___   __ _ ___
    | | | | | '__| '_ ` _ \ / _` / __|
    | | |_| | |  | | | | | | (_| \__ \
    |_|\__,_|_|  |_| |_| |_|\__,_|___/
    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Turma\t\t\tCurso\t\t\tAno escolar");
    printf("\n--------------------------------------------------------------------\n");

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o encontrado (n�o h� turmas)
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ainda n�o h� turmas registradas!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output das turmas registradas na escola
    while(fread(&turma,sizeof(turma),1,turmains) == 1)
    {
        printf("\n %s\t\t\t%s\t\t\t%s", turma.nome, turma.curso, turma.ano);
    }

    printf("\n\n Insira o nome de uma turma:\n >");
    gets(nome2);

    turmains = fopen("turmas.txt","rb+");
    //Ficheiro n�o escontrado
    if(turmains == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Procurar uma turma pelo nome
    while(fread(&turma,sizeof(turma),1,turmains ) == 1)
    {
        if(strcmp(nome2,turma.nome) == 0)
        {
            //Logo
            system("cls");
            textcolor(LIGHTBLUE);
            printf(R"EOF(
  _______
 |__   __|
    | |_   _ _ __ _ __ ___   __ _
    | | | | | '__| '_ ` _ \ / _` |
    | | |_| | |  | | | | | | (_| |
    |_|\__,_|_|  |_| |_| |_|\__,_|
            )EOF");
            textcolor(LIGHTGRAY);

            //Informa��o sobre a turma inserida
            printf("\n\n Nome: %s\t\tCurso: %s\t\tAno: %s", turma.nome, turma.curso, turma.ano);
            printf("\n\n Lista de alunos:\n");

            alunoins = fopen("alunos.txt","rb+");
            //Ficheiro n�o escontrado
            if(alunoins == NULL)
            {
                textcolor(RED);
                printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
                textcolor(LIGHTGRAY);
            }
            //Ver alunos na turma
            while(fread(&aluno,sizeof(aluno),1,alunoins) == 1)
            {
                if(strcmp(turma.nome,aluno.turma) == 0)
                {
                    //Output das informa��es dos alunos na turma
                    printf(" Nome: %s \t\t N�mero: %i\n", aluno.nomealuno, aluno.id);
                }
            }
            xfaltas();
            fclose(alunoins);
        }
    }
    fclose(turmains);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}

//Desmarcar testes
dteste()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * mteste;
    FILE * mtestev2;
    struct testess teste;
    char data2[12];

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  _____                                                 _______        _
 |  __ \                                               |__   __|      | |
 | |  | | ___  ___ _ __ ___   __ _ _ __ ___ __ _ _ __     | | ___  ___| |_ ___
 | |  | |/ _ \/ __| '_ ` _ \ / _` | '__/ __/ _` | '__|    | |/ _ \/ __| __/ _ \
 | |__| |  __/\__ \ | | | | | (_| | | | (_| (_| | |       | |  __/\__ \ ||  __/
 |_____/ \___||___/_| |_| |_|\__,_|_|  \___\__,_|_|       |_|\___||___/\__\___|

    )EOF");
    textcolor(LIGHTGRAY);

    printf("\n\n Insira a data do teste que vai desmarcar:\n >");
    gets(data2);

    mteste = fopen("testes.txt","rb+");
    //Ficheiro n�o encontrado
    if(mteste == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    mtestev2 = fopen("tempteste.txt","wb+");
    //Ficheiro n�o encontrado
    if(mtestev2 == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Desmarcar teste
    while(fread(&teste,sizeof(teste),1,mteste) == 1)
    {
        if(strcmp(data2,teste.data)!=0)
            fwrite(&teste,sizeof(teste),1,mtestev2);
    }
    fclose(mteste);
    fclose(mtestev2);
    remove("testes.txt");
    rename("tempteste.txt","testes.txt");

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Prime qualquer tecla para continuar. \n\n");
    getch();
    system("cls");
    mainprof();
}

//Ver testes
vertestes()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * mteste;
    struct testess teste;

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
 __      __         _______        _
 \ \    / /        |__   __|      | |
  \ \  / /__ _ __     | | ___  ___| |_ ___  ___
   \ \/ / _ \ '__|    | |/ _ \/ __| __/ _ \/ __|
    \  /  __/ |       | |  __/\__ \ ||  __/\__ \
     \/ \___|_|       |_|\___||___/\__\___||___/

    )EOF");
    textcolor(LIGHTGRAY);

    //"Tabela" de testes marcados
    printf("\n\n Dia\t\tDisciplina\t\tProfessor\t\tTurma ");
    printf("\n-------------------------------------------------------------------------\n");

    mteste = fopen("testes.txt","rb+");
    //Ficheiro n�o encontrado
    if(mteste == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }

    //Output dos Professores
    while(fread(&teste,sizeof(teste),1,mteste) == 1)
    {
        printf("\n %s\t%s\t\t%s\t\t\t%s", teste.data, teste.disciplina, teste.nome, teste.turma);
    }
    fclose(mteste);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}

//Testes
mteste()
{
    setlocale(LC_ALL,"Portuguese");
    FILE * mteste;
    struct testess teste;
    char outro = 's';

    //Logo
    system("cls");
    textcolor(LIGHTBLUE);
    printf(R"EOF(
  __  __                            _______        _
 |  \/  |                          |__   __|      | |
 | \  / | __ _ _ __ ___ __ _ _ __     | | ___  ___| |_ ___
 | |\/| |/ _` | '__/ __/ _` | '__|    | |/ _ \/ __| __/ _ \
 | |  | | (_| | | | (_| (_| | |       | |  __/\__ \ ||  __/
 |_|  |_|\__,_|_|  \___\__,_|_|       |_|\___||___/\__\___|

    )EOF");
    textcolor(LIGHTGRAY);

    mteste=fopen("testes.txt","ab+");
    //Ficheiro n�o encontrado
    if(mteste == NULL)
    {
        textcolor(RED);
        printf("\n\n [ERRO]\n Ficheiro n�o encontrado!\n\n");
        textcolor(LIGHTGRAY);
    }
    fflush(stdin);

    //Ciclo de repeti��o se no final for premida a tecla 's'
    while(outro == 's')
    {
        //Input de informa��es
        printf("\n Insira a turma:\n >");
        gets(teste.turma);
        printf("\n Insira a data do teste:\n >");
        gets(teste.data);
        printf("\n Insira a disciplina:\n >");
        gets(teste.disciplina);
        printf("\n Insira o seu nome:\n >");
        gets(teste.nome);

        //Guardar as informa��es dadas pelo utilizador num file
        fwrite(&teste,sizeof(teste),1,mteste);

        //Marcar outro teste
        textcolor(CYAN);
        printf("\n Marcar outro teste? 's' para sim, 'n' para n�o.");
        textcolor(LIGHTGRAY);
        outro = getch();
        system("cls");
    }
    fclose(mteste);

    //Continuar
    textcolor(YELLOW);
    printf("\n\n Pressiona uma tecla para continuar. \n\n");
    textcolor(LIGHTGRAY);
    getch();
    system("cls");
    mainprof();
}

//Login do professor
loginprof()
{
        char userr[15], senhaa[10];

        //Logo
        textcolor(LIGHTBLUE);
        printf(R"EOF(
  _                 _         _____            __
 | |               (_)       |  __ \          / _|
 | |     ___   __ _ _ _ __   | |__) | __ ___ | |_ ___  ___ ___  ___  _ __
 | |    / _ \ / _` | | '_ \  |  ___/ '__/ _ \|  _/ _ \/ __/ __|/ _ \| '__|
 | |___| (_) | (_| | | | | | | |   | | | (_) | ||  __/\__ \__ \ (_) | |
 |______\___/ \__, |_|_| |_| |_|   |_|  \___/|_| \___||___/___/\___/|_|
               __/ |
              |___/
        )EOF");
        textcolor(LIGHTGRAY);

        //Input de informa��es
        user:
        printf("\n Insira o nome de utilizador:\n >");
        gets(userr);
        printf(" Insira a palavra-pass:\n >");

        //Esconder senha inserida
        int p=0;
        do
        {
            senhaa[p]=getch();
            if(senhaa[p]!='\r')
            {
                printf("*");
            }
            p++;
        }while(senhaa[p-1]!='\r');
            senhaa[p-1]='\0';

            //Sistema login com user e senha pre-definidos
            if (strcmp(userr,"professor")==0)
            {
                if(strcmp(senhaa,"123")==0)
                {
                    system("cls");
                    mainprof();
                }
                //Senha errada
                else
                {
                    system("cls");
                    textcolor(RED);
                    printf("\n\n [ERRO]\n Senha ou User incorretos!\n");
                    textcolor(LIGHTGRAY);
                    goto user;
                }
            }
            //User errado
            else
            {
            system("cls");
            textcolor(RED);
            printf("\n\n [ERRO]\n Senha ou User incorretos!\n");
            textcolor(LIGHTGRAY);
            goto user;
            }
}
#endif // MENU_PROF_H_INCLUDED
