#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>
#include "conio.c"
#include <windows.h>
#include "ingles.h"

struct user{
    char nome[20];
    char senha[20];
    char SN;
    char letra[0];
    char pesquisa[5];
    char prof[3];
    int menu;
};
struct user u;
animacao(){
    system("cls");
    int i;
    int a=33;
    for(i=0; i<10; i++){
        textcolor(LIGHTBLUE);
        gotoxy(30,i);
        printf(" .----------------.  .----------------. \n");
        gotoxy(30,i+1);
        printf("| .--------------. || .--------------. |\n");
        gotoxy(30,i+2);
        printf("| |  _________   | || |   ______     | |\n");
        gotoxy(30,i+3);
        printf("| | |  _   _  |  | || |  |_   __ '   | |\n");
        gotoxy(30,i+4);
        printf("| | |_/ | | '_|  | || |    | |__) |  | |\n");
        gotoxy(30,i+5);
        printf("| |     | |      | || |    |  ___/   | |\n");
        gotoxy(30,i+6);
        printf("| |    _| |_     | || |   _| |_      | |\n");
        gotoxy(30,i+7);
        printf("| |   |_____|    | || |  |_____|     | |\n");
        gotoxy(30,i+8);
        printf("| |              | || |              | |\n");
        gotoxy(30,i+9);
        printf("| '--------------' || '--------------' |\n");
        gotoxy(30,i+10);
        printf(" '----------------'  '----------------' \n");
        textcolor(WHITE);
        if(i>7){
            gotoxy(30,a-2);
            printf("Tabela peri�dica moderna");
            gotoxy(30,a-1);
            printf("A carregar ...");
        }
        Sleep(0.5);
        if(i!=9){
            system("cls");
        }
        a--;
    }
    Sleep(5000);
}
menu(){
    int i;
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Tabela peri�dica\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("J� tem uma conta?\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("|   1   |  Sim  |");
    gotoxy(30,16);
    printf("|   2   |  N�o  |");
    gotoxy(30,17);
    printf("| (...) |  Sair |");
    textcolor(WHITE);
    gotoxy(30,18);
    scanf("%i%*C",&i);
    switch(i){
        case 1: login(); break;
        case 2: registar(); break;
        default: exit(0); break;
    }
}
login(){
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Tabela peri�dica\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("Fa�a login na sua conta\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("Nome: ");
    textcolor(WHITE);
    gets(u.nome);
    textcolor(YELLOW);
    gotoxy(30,16);
    printf("Senha: ");
    textcolor(WHITE);
    gets(u.senha);
    if(strcmpi(u.nome,"professor")==0 && strcmpi(u.senha,"quimica123")==0){
        strcat(u.prof, "sim");
        opcoes();
    }else{
        FILE*aq;
        strcat(u.nome, u.senha);
        aq = fopen(u.nome,"r");
        system("cls");
        if(!aq){
            textbackground(WHITE);
            textcolor(RED);
            gotoxy(30,20);
            printf("Senha incorreta. Prima Enter para tentar novamente...\n\n");
            textbackground(BLACK);
            textcolor(BLACK);
            system("pause");
            system("cls");
            system("COLOR 0F");
            login();
        }else{
            opcoes();
        }
    }
}
registar(){
    int i;
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Tabela peri�dica\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("Criar conta\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("O seu nome: ");
    textcolor(WHITE);
    gets(u.nome);
    textcolor(YELLOW);
    gotoxy(30,16);
    printf("Nova senha: ");
    textcolor(WHITE);
    gets(u.senha);
    FILE*aq;
    strcat(u.nome, u.senha);
    aq = fopen(u.nome,"w");
    fprintf(aq,"Conta criada.\n");
    fclose(aq);
    login();
}
opcoes(){
    system("cls");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Tabela peri�dica\n");
    textcolor(WHITE);
    gotoxy(40,12);
    printf("Escolha um item do menu:");
    textcolor(YELLOW);
    gotoxy(35,16);
    printf(" | 1 | Ver elementos           |");
    gotoxy(35,17);
    printf(" | 2 | Ver os meus favoritos   |");
    gotoxy(35,18);
    printf(" | 3 | Ver hist�rico           |");
    if(strcmpi(u.prof,"sim")==0){
        gotoxy(35,19);
        printf(" | 4 | Elementos do professor  |");
        gotoxy(35,20);
        printf(" | 0 | Fechar                  |");
        gotoxy(35,22);
    }else{
        gotoxy(35,19);
        printf(" | 0 | Fechar                  |");
        gotoxy(35,21);
    }
    textcolor(WHITE);
    scanf("%i%*C",&u.menu);
    if(strcmpi(u.prof,"sim")==0){
        switch(u.menu){
            case 0: system("cls");
                    gotoxy(30,15);
                    printf("Prima Enter para encerrar o programa corretamente ...");
                    textcolor(BLACK);
                    exit(0);
                    break;
            case 1: system("cls");
                    pesquisa();
                    break;
            case 2: system("cls");
                    favoritos();
                    break;
            case 3: system("cls");
                    historico();
                    break;
            case 4: system("cls");
                    adicionar();
                    break;
            default: gotoxy(30,25);
                    printf("Essa op��o n�o � v�lida. Prima Enter para tentar novamente");
                    textcolor(BLACK);
                    system("pause");
                    opcoes();
                    break;
        }
    }else{
        switch(u.menu){
            case 0: system("cls");
                    gotoxy(30,15);
                    printf("Prima Enter para encerrar o programa corretamente ...");
                    textcolor(BLACK);
                    exit(0);
                    break;
            case 1: system("cls");
                    pesquisa();
                    break;
            case 2: system("cls");
                    favoritos();
                    break;
            case 3: system("cls");
                    historico();
                    break;
            default: gotoxy(30,25);
                    printf("Essa op��o n�o � v�lida. Prima Enter para tentar novamente");
                    textcolor(BLACK);
                    system("pause");
                    opcoes();
                    break;
        }
    }
}
pesquisa(){
    char txt[50];
    char fav[50];
    printf("\n\n");
    printf("\t\t ____________________________________________________________________________\n");
    printf("\t\t|  G| 1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18 |\n");
    printf("\t\t|_P_|________________________________________________________________________|\n");
    printf("\t\t| 1 | H                                                                   He |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 2 | Li  Be                                          B   C   N   O   F   Ne |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 3 | Na  Mg                                          Al  Si  P   S   Cl  Ar |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 4 | K   Ca  Sc  Ti  V   Cr  Mn  Fe  Co  Ni  Cu  Zn  Ga  Ge  As  Se  Br  Kr |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 5 | Rb  Sr  Y   Zr  Nb  Mo  Tc  Ru  Rh  Pd  Ag  Cd  In  Sn  Sb  Te  I   Xe |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 6 | Cs  Ba  *   Hf  Ta  W   Re  Os  Ir  Pt  Au  Hg  Tl  Pb  Bi  Po  At  Rn |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 7 | Fr  Ra  **  Rf  Db  Sg  Bh  Hs  Mt  Ds  Rg  Cn  Nh  Fl  Mc  Lv  Ts  Og |\n");
    printf("\t\t|___|________________________________________________________________________|\n");
    gotoxy(35,22);
    printf("Que elemento gostaria de pesquisar?\n");
    textcolor(YELLOW);
    gotoxy(33,25);
    printf("Insira a sua pesquisa: ");
    textcolor(WHITE);
    gets(u.pesquisa);
    if(strcmpi(u.pesquisa,"sair")==0){
        system("cls");
        opcoes();
    }else{
        animacao();
        system("cls");
        gotoxy(30,15);
        printf("Por favor, aguarde...");
        FILE*aq;
        strncpy(txt, u.pesquisa, 5);
        strncpy(fav, u.pesquisa, 5);
        strcat(txt, ".txt");
        aq = fopen(txt,"r");
        system("cls");
        if(!aq){
            fclose(aq);
            gotoxy(30,15);
            system("COLOR F4");
            printf("Esse elemento n�o existe!");
            Sleep(3000);
            system("cls");
            system("COLOR 0F");
            pesquisa();
        }else{
            u.SN = fgetc(aq);
            printf("\n\n");
            while(!feof(aq)){
                if(u.SN== '\0'){
                    printf("\t\t");
                }
                putchar(u.SN);
                u.SN = fgetc(aq);
            }
            fclose(aq);
            FILE*aq;
            strncpy(txt, u.nome, 20);
            strcat(txt, "-historico.txt");
            aq = fopen(txt,"a");
            time_t t = time(NULL);
            struct tm tm = *localtime(&t);
            fprintf(aq,"\t\tNo dia %d �s %d:%d, pesquisou o elemento: %s\n", tm.tm_mday, tm.tm_hour, tm.tm_min, u.pesquisa);
            fclose(aq);
            printf("\n\n\n\tPrima a tecla Enter para retroceder e a tecla 'f' para adicionar aos favoritos...\n");
            gets(u.letra);
            if(strcmpi(u.letra,"f")==0){
                FILE*aq;
                strncpy(txt, u.nome, 20);
                strcat(txt, "-favoritos.txt");
                aq = fopen(txt,"a");
                fprintf(aq,"\t\t-> %s\n", fav);
                fclose(aq);
                printf("\n\n\n\tAdicionado! Prima Enter para continuar... %s\n",fav);
                textcolor(BLACK);
                system("pause");
                system("cls");
                opcoes();
            }else{
                system("cls");
                pesquisa();
            }
        }
    }
}
historico(){
    char txt[50];
    FILE*aq;
    strncpy(txt, u.nome, 20);
    strcat(txt, "-historico.txt");
    aq = fopen(txt,"r");
    if(!aq){
        fclose(aq);
        gotoxy(30,15);
        system("COLOR F4");
        printf("N�o existe hist�rico ainda...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoes();
    }else{
        textcolor(YELLOW);
        printf("\n\n");
        printf("\t\t _______________ \n");
        printf("\t\t|               |\n");
        printf("\t\t|   Hist�rico   |\n");
        printf("\t\t|_______________|\n\n");
        textcolor(WHITE);
        u.SN = fgetc(aq);
        printf("\n\n");
        while(!feof(aq)){
            putchar(u.SN);
            u.SN = fgetc(aq);
        }
        fclose(aq);
        printf("\n\n\n\tPrima a tecla Enter\n");
        textcolor(BLACK);
        system("pause");
        textcolor(WHITE);
        system("cls");
        opcoes();
    }
}
favoritos(){
    char txt[50];
    FILE*aq;
    strncpy(txt, u.nome, 20);
    strcat(txt, "-favoritos.txt");
    aq = fopen(txt,"r");
    if(!aq){
        fclose(aq);
        gotoxy(30,15);
        system("COLOR F4");
        printf("Sem favoritos...");
        gotoxy(30,20);
        printf("Prima qualquer tecla para fazer uma pesquisa... \n");
        textcolor(WHITE);
        system("pause");
        system("cls");
        system("COLOR 0F");
        pesquisa();
    }else{
        textcolor(YELLOW);
        printf("\n\n");
        printf("\t\t _______________ \n");
        printf("\t\t|               |\n");
        printf("\t\t|   Favoritos   |\n");
        printf("\t\t|_______________|\n\n");
        textcolor(WHITE);
        u.SN = fgetc(aq);
        printf("\n\n");
        while(!feof(aq)){
            putchar(u.SN);
            u.SN = fgetc(aq);
        }
        fclose(aq);
        printf("\n\n\n\tPrima a tecla Enter\n");
        textcolor(BLACK);
        system("pause");
        textcolor(WHITE);
        system("cls");
        opcoes();
    }
}
adicionar(){
    char nome[50];
    char descricao[500];
    printf("\n\n");
    printf("\t\t ____________________________________________________________________________\n");
    printf("\t\t|  G| 1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18 |\n");
    printf("\t\t|_P_|________________________________________________________________________|\n");
    printf("\t\t| 1 | H                                                                   He |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 2 | Li  Be                                          B   C   N   O   F   Ne |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 3 | Na  Mg                                          Al  Si  P   S   Cl  Ar |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 4 | K   Ca  Sc  Ti  V   Cr  Mn  Fe  Co  Ni  Cu  Zn  Ga  Ge  As  Se  Br  Kr |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 5 | Rb  Sr  Y   Zr  Nb  Mo  Tc  Ru  Rh  Pd  Ag  Cd  In  Sn  Sb  Te  I   Xe |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 6 | Cs  Ba  *   Hf  Ta  W   Re  Os  Ir  Pt  Au  Hg  Tl  Pb  Bi  Po  At  Rn |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 7 | Fr  Ra  **  Rf  Db  Sg  Bh  Hs  Mt  Ds  Rg  Cn  Nh  Fl  Mc  Lv  Ts  Og |\n");
    printf("\t\t|___|________________________________________________________________________|\n\n");
    gotoxy(0,22);
    printf("\t\tIndique o nome e a descri��o do elemento que gostaria de adicionar\n");
    textcolor(YELLOW);
    gotoxy(33,25);
    printf("Nome: ");
    textcolor(WHITE);
    gets(nome);
    FILE*aq;
    strlwr(nome);
    strcat(nome, ".txt");
    aq = fopen(nome,"r");
    if(aq){
        fclose(aq);
        system("cls");
        gotoxy(30,15);
        system("COLOR F4");
        printf("Esse elemento j� existe! Aguarde 3s...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoes();
    }else{
        fclose(aq);
        aq = fopen(nome,"w");
        textcolor(YELLOW);
        gotoxy(33,26);
        printf("Descri��o: ");
        textcolor(WHITE);
        gets(descricao);
        fprintf(aq,"%s",descricao);
        fclose(aq);
        system("cls");
        gotoxy(30,15);
        system("COLOR F1");
        printf("Elemento adicionado! Aguarde 3s...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoes();
    }
}
int main()
{
    setlocale(LC_ALL,"portuguese");
    int lang;
    printf("\n\n\t\t\t\t1 - Portugu�s\n");
    printf("\t\t\t\t2 - English\n\n");
    scanf("%i",&lang);
    switch(lang){
        case 2: animacaoing();menuing();break;
        case 1: animacao();menu();break;
        default: system("cls");printf("\n\n\t\t\t\tInv�lido / Invalid\n");main();break;
    }
    return 0;
}
