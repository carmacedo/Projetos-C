struct userIng{
    char nome[20];
    char senha[20];
    char SN;
    char letra[0];
    char pesquisa[5];
    char prof[3];
    int menu;
};
struct userIng uI;
animacaoing(){
    system("cls");
    int i;
    int a=33;
    for(i=0; i<10; i++){
        textcolor(LIGHTBLUE);
        gotoxy(30,i);
        printf(" .----------------.  .----------------. \n");
        gotoxy(30,i+1);
        printf("| .--------------. || .--------------. |\n");
        gotoxy(30,i+2);
        printf("| |  _________   | || |   ______     | |\n");
        gotoxy(30,i+3);
        printf("| | |  _   _  |  | || |  |_   __ '   | |\n");
        gotoxy(30,i+4);
        printf("| | |_/ | | '_|  | || |    | |__) |  | |\n");
        gotoxy(30,i+5);
        printf("| |     | |      | || |    |  ___/   | |\n");
        gotoxy(30,i+6);
        printf("| |    _| |_     | || |   _| |_      | |\n");
        gotoxy(30,i+7);
        printf("| |   |_____|    | || |  |_____|     | |\n");
        gotoxy(30,i+8);
        printf("| |              | || |              | |\n");
        gotoxy(30,i+9);
        printf("| '--------------' || '--------------' |\n");
        gotoxy(30,i+10);
        printf(" '----------------'  '----------------' \n");
        textcolor(WHITE);
        if(i>7){
            gotoxy(30,a-2);
            printf("Modern periodic table");
            gotoxy(30,a-1);
            printf("Loading ...");
        }
        Sleep(0.5);
        if(i!=9){
            system("cls");
        }
        a--;
    }
    Sleep(5000);
}
menuing(){
    int i;
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Periodic table\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("Do you have an account?\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("|   1   |  Yes  |");
    gotoxy(30,16);
    printf("|   2   |   No  |");
    gotoxy(30,17);
    printf("| (...) |  Exit |");
    textcolor(WHITE);
    gotoxy(30,18);
    scanf("%i%*C",&i);
    switch(i){
        case 1: logining(); break;
        case 2: registaring(); break;
        default: exit(0); break;
    }
}
logining(){
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Periodic table\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("Log in\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("Name: ");
    textcolor(WHITE);
    gets(uI.nome);
    textcolor(YELLOW);
    gotoxy(30,16);
    printf("Password: ");
    textcolor(WHITE);
    gets(uI.senha);
    if(strcmpi(uI.nome,"teacher")==0 && strcmpi(uI.senha,"chemistry123")==0){
        strcat(uI.prof, "sim");
        opcoesing();
    }else{
        FILE*aq;
        strcat(uI.nome, uI.senha);
        aq = fopen(uI.nome,"r");
        system("cls");
        if(!aq){
            textbackground(WHITE);
            textcolor(RED);
            gotoxy(30,20);
            printf("Incorrect password. Press Enter to try again ...\n\n");
            textbackground(BLACK);
            textcolor(BLACK);
            system("pause");
            system("cls");
            system("COLOR 0F");
            logining();
        }else{
            opcoesing();
        }
    }
}
registaring(){
    int i;
    system("cls");
    system("COLOR 0F");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Periodic table\n");
    textcolor(WHITE);
    gotoxy(33,11);
    printf("Create account\n");
    gotoxy(30,15);
    textcolor(YELLOW);
    printf("Your name: ");
    textcolor(WHITE);
    gets(uI.nome);
    textcolor(YELLOW);
    gotoxy(30,16);
    printf("New password: ");
    textcolor(WHITE);
    gets(uI.senha);
    FILE*aq;
    strcat(uI.nome, uI.senha);
    aq = fopen(uI.nome,"w");
    fprintf(aq,"Account created.\n");
    fclose(aq);
    logining();
}
opcoesing(){
    system("cls");
    gotoxy(45,10);
    textcolor(LIGHTBLUE);
    printf("Periodic table\n");
    textcolor(WHITE);
    gotoxy(40,12);
    printf("Choose a menu item:");
    textcolor(YELLOW);
    gotoxy(35,16);
    printf(" | 1 | View elements           |");
    gotoxy(35,17);
    printf(" | 2 | My favorites            |");
    gotoxy(35,18);
    printf(" | 3 | History                 |");
    if(strcmpi(uI.prof,"sim")==0){
        gotoxy(35,19);
        printf(" | 4 | Add elements            |");
        gotoxy(35,20);
        printf(" | 0 | Close                   |");
        gotoxy(35,22);
    }else{
        gotoxy(35,19);
        printf(" | 0 | Close                   |");
        gotoxy(35,21);
    }
    textcolor(WHITE);
    scanf("%i%*C",&uI.menu);
    if(strcmpi(uI.prof,"sim")==0){
        switch(uI.menu){
            case 0: system("cls");
                    gotoxy(30,15);
                    printf("Press Enter to quit the program correctly ...");
                    textcolor(BLACK);
                    exit(0);
                    break;
            case 1: system("cls");
                    pesquisaing();
                    break;
            case 2: system("cls");
                    favoritosing();
                    break;
            case 3: system("cls");
                    historicoing();
                    break;
            case 4: system("cls");
                    adicionaring();
                    break;
            default: gotoxy(30,25);
                    printf("This option is not valid. Press Enter to try again");
                    textcolor(BLACK);
                    system("pause");
                    opcoesing();
                    break;
        }
    }else{
        switch(uI.menu){
            case 0: system("cls");
                    gotoxy(30,15);
                    printf("Press Enter to quit the program correctly ...");
                    textcolor(BLACK);
                    exit(0);
                    break;
            case 1: system("cls");
                    pesquisaing();
                    break;
            case 2: system("cls");
                    favoritosing();
                    break;
            case 3: system("cls");
                    historicoing();
                    break;
            default: gotoxy(30,25);
                    printf("This option is not valid. Press Enter to try again");
                    textcolor(BLACK);
                    system("pause");
                    opcoesing();
                    break;
        }
    }
}
pesquisaing(){
    char txt[50];
    char fav[50];
    printf("\n\n");
    printf("\t\t ____________________________________________________________________________\n");
    printf("\t\t|  G| 1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18 |\n");
    printf("\t\t|_P_|________________________________________________________________________|\n");
    printf("\t\t| 1 | H                                                                   He |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 2 | Li  Be                                          B   C   N   O   F   Ne |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 3 | Na  Mg                                          Al  Si  P   S   Cl  Ar |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 4 | K   Ca  Sc  Ti  V   Cr  Mn  Fe  Co  Ni  Cu  Zn  Ga  Ge  As  Se  Br  Kr |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 5 | Rb  Sr  Y   Zr  Nb  Mo  Tc  Ru  Rh  Pd  Ag  Cd  In  Sn  Sb  Te  I   Xe |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 6 | Cs  Ba  *   Hf  Ta  W   Re  Os  Ir  Pt  Au  Hg  Tl  Pb  Bi  Po  At  Rn |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 7 | Fr  Ra  **  Rf  Db  Sg  Bh  Hs  Mt  Ds  Rg  Cn  Nh  Fl  Mc  Lv  Ts  Og |\n");
    printf("\t\t|___|________________________________________________________________________|\n");
    gotoxy(35,22);
    printf("Which element would you like to search?\n");
    textcolor(YELLOW);
    gotoxy(33,25);
    printf("Make your search: ");
    textcolor(WHITE);
    gets(uI.pesquisa);
    if(strcmpi(uI.pesquisa,"exit")==0){
        system("cls");
        opcoesing();
    }else{
        animacaoing();
        system("cls");
        gotoxy(30,15);
        printf("Please wait...");
        FILE*aq;
        strncpy(txt, uI.pesquisa, 5);
        strncpy(fav, uI.pesquisa, 5);
        strcat(txt, "-ing.txt");
        aq = fopen(txt,"r");
        system("cls");
        if(!aq){
            fclose(aq);
            gotoxy(30,15);
            system("COLOR F4");
            printf("This element does not exist!");
            Sleep(3000);
            system("cls");
            system("COLOR 0F");
            pesquisaing();
        }else{
            uI.SN = fgetc(aq);
            printf("\n\n");
            while(!feof(aq)){
                if(uI.SN== '\0'){
                    printf("\t\t");
                }
                putchar(uI.SN);
                uI.SN = fgetc(aq);
            }
            fclose(aq);
            FILE*aq;
            strncpy(txt, uI.nome, 20);
            strcat(txt, "-historico.txt");
            aq = fopen(txt,"a");
            time_t t = time(NULL);
            struct tm tm = *localtime(&t);
            fprintf(aq,"\t\tOn %d �s %d:%d, you searched for: %s\n", tm.tm_mday, tm.tm_hour, tm.tm_min, uI.pesquisa);
            fclose(aq);
            printf("\n\n\n\tPress the Enter key to go back and the 'f' key to add to your favorites ...\n");
            gets(uI.letra);
            if(strcmpi(uI.letra,"f")==0){
                FILE*aq;
                strncpy(txt, uI.nome, 20);
                strcat(txt, "-favoritos.txt");
                aq = fopen(txt,"a");
                fprintf(aq,"\t\t-> %s\n", fav);
                fclose(aq);
                printf("\n\n\n\tAdded! Press Enter to continue ... %s\n",fav);
                textcolor(BLACK);
                system("pause");
                system("cls");
                opcoesing();
            }else{
                system("cls");
                pesquisaing();
            }
        }
    }
}
historicoing(){
    char txt[50];
    FILE*aq;
    strncpy(txt, uI.nome, 20);
    strcat(txt, "-historico.txt");
    aq = fopen(txt,"r");
    if(!aq){
        fclose(aq);
        gotoxy(30,15);
        system("COLOR F4");
        printf("There is no history yet ...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoesing();
    }else{
        textcolor(YELLOW);
        printf("\n\n");
        printf("\t\t _______________ \n");
        printf("\t\t|               |\n");
        printf("\t\t|    History    |\n");
        printf("\t\t|_______________|\n\n");
        textcolor(WHITE);
        uI.SN = fgetc(aq);
        printf("\n\n");
        while(!feof(aq)){
            putchar(uI.SN);
            uI.SN = fgetc(aq);
        }
        fclose(aq);
        printf("\n\n\n\tPress the Enter key\n");
        textcolor(BLACK);
        system("pause");
        textcolor(WHITE);
        system("cls");
        opcoesing();
    }
}
favoritosing(){
    char txt[50];
    FILE*aq;
    strncpy(txt, uI.nome, 20);
    strcat(txt, "-favoritos.txt");
    aq = fopen(txt,"r");
    if(!aq){
        fclose(aq);
        gotoxy(30,15);
        system("COLOR F4");
        printf("No favorites ...");
        gotoxy(30,20);
        printf("Press any key to perform a search ... \n");
        textcolor(WHITE);
        system("pause");
        system("cls");
        system("COLOR 0F");
        pesquisaing();
    }else{
        textcolor(YELLOW);
        printf("\n\n");
        printf("\t\t _______________ \n");
        printf("\t\t|               |\n");
        printf("\t\t|   Favorites   |\n");
        printf("\t\t|_______________|\n\n");
        textcolor(WHITE);
        uI.SN = fgetc(aq);
        printf("\n\n");
        while(!feof(aq)){
            putchar(uI.SN);
            uI.SN = fgetc(aq);
        }
        fclose(aq);
        printf("\n\n\n\tPress Enter\n");
        textcolor(BLACK);
        system("pause");
        textcolor(WHITE);
        system("cls");
        opcoesing();
    }
}
adicionaring(){
    char nome[50];
    char descricao[500];
    printf("\n\n");
    printf("\t\t ____________________________________________________________________________\n");
    printf("\t\t|  G| 1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18 |\n");
    printf("\t\t|_P_|________________________________________________________________________|\n");
    printf("\t\t| 1 | H                                                                   He |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 2 | Li  Be                                          B   C   N   O   F   Ne |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 3 | Na  Mg                                          Al  Si  P   S   Cl  Ar |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 4 | K   Ca  Sc  Ti  V   Cr  Mn  Fe  Co  Ni  Cu  Zn  Ga  Ge  As  Se  Br  Kr |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 5 | Rb  Sr  Y   Zr  Nb  Mo  Tc  Ru  Rh  Pd  Ag  Cd  In  Sn  Sb  Te  I   Xe |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 6 | Cs  Ba  *   Hf  Ta  W   Re  Os  Ir  Pt  Au  Hg  Tl  Pb  Bi  Po  At  Rn |\n");
    printf("\t\t|   |                                                                        |\n");
    printf("\t\t| 7 | Fr  Ra  **  Rf  Db  Sg  Bh  Hs  Mt  Ds  Rg  Cn  Nh  Fl  Mc  Lv  Ts  Og |\n");
    printf("\t\t|___|________________________________________________________________________|\n\n");
    gotoxy(0,22);
    printf("\t\tEnter the name and description of the element you'd like to add\n");
    textcolor(YELLOW);
    gotoxy(33,25);
    printf("Nome: ");
    textcolor(WHITE);
    gets(nome);
    FILE*aq;
    strlwr(nome);
    strcat(nome, "-ing.txt");
    aq = fopen(nome,"r");
    if(aq){
        fclose(aq);
        system("cls");
        gotoxy(30,15);
        system("COLOR F4");
        printf("This element already exists! Wait 3s ...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoesing();
    }else{
        fclose(aq);
        aq = fopen(nome,"w");
        textcolor(YELLOW);
        gotoxy(33,26);
        printf("Description: ");
        textcolor(WHITE);
        gets(descricao);
        fprintf(aq,"%s",descricao);
        fclose(aq);
        system("cls");
        gotoxy(30,15);
        system("COLOR F1");
        printf("Element added! Wait 3s ...");
        Sleep(3000);
        system("cls");
        system("COLOR 0F");
        opcoesing();
    }
}
